<?php
$page = "Dashboard";
include('top_navbar.php');
include('core/dashboard_curl.php');

?>

            
<div class="row">
    <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <div id="x3main" class="logotypeX3">
                    <img src="assets/Decentralized/img/x3.svg" alt="">
                </div>
                <div class="ternary-wrapper">
                                        <div class="ternary">
                        <a href="/page/x3/1/123/" class="ternary-root matrix-root__active ">
                                                        <span class="matrix-level matrix-level__active ">
                                1                            </span>
                            <span class="matrix-price">
                                0.025                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                        <div class="matrix_partners__count">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/2/123/" class="ternary-root matrix-root__active ">
                                                        <span class="matrix-level matrix-level__active ">
                                2                            </span>
                            <span class="matrix-price">
                                0.05                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                        <div class="matrix_partners__count">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/3/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big " 
                                data-matrix="1" 
                                data-level="3" 
                                data-matrix_price="0.1"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                3                            </span>
                            <span class="matrix-price">
                                0.1                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/4/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="4" 
                                data-matrix_price="0.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                4                            </span>
                            <span class="matrix-price">
                                0.2                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/5/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="5" 
                                data-matrix_price="0.4"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                5                            </span>
                            <span class="matrix-price">
                                0.4                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/6/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="6" 
                                data-matrix_price="0.8"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                6                            </span>
                            <span class="matrix-price">
                                0.8                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/7/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="7" 
                                data-matrix_price="1.6"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                7                            </span>
                            <span class="matrix-price">
                                1.6                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/8/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="8" 
                                data-matrix_price="3.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                8                            </span>
                            <span class="matrix-price">
                                3.2                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/9/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="9" 
                                data-matrix_price="6.4"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                9                            </span>
                            <span class="matrix-price">
                                6.4                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/10/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="10" 
                                data-matrix_price="12.8"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                10                            </span>
                            <span class="matrix-price">
                                12.8                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/11/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="11" 
                                data-matrix_price="25.6"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                11                            </span>
                            <span class="matrix-price">
                                25.6                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="ternary">
                        <a href="/page/x3/12/123/" class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="1" 
                                data-level="12" 
                                data-matrix_price="51.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                12                            </span>
                            <span class="matrix-price">
                                51.2                            </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                    </div><!-- end: ternary-wrapper -->
            </div><!-- end: border-gradient_content -->
        </div><!-- end: border-gradient -->
    </div><!-- end: col -->
</div><!-- end: row -->

<div class="row mt-2 mb-5">
    <div class="col">
        <div class="icon-tips">
            <div class="matrix_currency">
                <strong style="color:var(--color-lightblue);font-weight: bold">eth</strong> <span>THE COST OF SLOTS IN ETH (ETHEREUM)</span>
            </div>
            <div class="matrix_reinvest">
                <i class="matrix-icon_sync"></i> <span>NUMBER OF REINVESTS</span>
            </div>
            <div class="matrix_partners__count">
                <i class="matrix-icon_users"></i> <span>PARTNERS ON THE SLOT</span>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <div id="x4main" class="logotypeX4">
                    <img src="assets/Decentralized/img/x4.svg" alt="">
                </div>
                <div class="binary-wrapper">
                                        <div class="binary">
                        <a href="/page/x2/1/123/" class="binary-root matrix-root__active ">
                                                        <span class="matrix-level matrix-level__active ">
                                1                            </span>
                            <span class="matrix-price">
                                0.025                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__overflow ">
                                                                <a 
                                    href="/page/x2/1/139/?tx=0xcf4ff910666fd7205a94800de43b4bfeb0e06140490f1154f6d5786a9fd977a1" 
                                    title="UID: 139                                ">
                                    &nbsp;
                                </a>
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                        <div class="matrix_partners__count">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/2/123/" class="binary-root matrix-root__active ">
                                                        <span class="matrix-level matrix-level__active ">
                                2                            </span>
                            <span class="matrix-price">
                                0.05                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                        <div class="matrix_partners__count">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/3/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__big " 
                                data-matrix="2" 
                                data-level="3" 
                                data-matrix_price="0.1"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                3                            </span>
                            <span class="matrix-price">
                                0.1                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/4/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="4" 
                                data-matrix_price="0.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                4                            </span>
                            <span class="matrix-price">
                                0.2                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/5/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="5" 
                                data-matrix_price="0.4"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                5                            </span>
                            <span class="matrix-price">
                                0.4                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/6/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="6" 
                                data-matrix_price="0.8"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                6                            </span>
                            <span class="matrix-price">
                                0.8                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/7/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="7" 
                                data-matrix_price="1.6"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                7                            </span>
                            <span class="matrix-price">
                                1.6                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/8/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="8" 
                                data-matrix_price="3.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                8                            </span>
                            <span class="matrix-price">
                                3.2                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/9/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="9" 
                                data-matrix_price="6.4"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                9                            </span>
                            <span class="matrix-price">
                                6.4                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/10/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="10" 
                                data-matrix_price="12.8"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                10                            </span>
                            <span class="matrix-price">
                                12.8                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/11/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="11" 
                                data-matrix_price="25.6"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                11                            </span>
                            <span class="matrix-price">
                                25.6                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                        <div class="binary">
                        <a href="/page/x2/12/123/" class="binary-root matrix-root__nonactive ">
                                                        <i 
                                class="matrix-icon_cart matrix-icon_cart__small " 
                                data-matrix="2" 
                                data-level="12" 
                                data-matrix_price="51.2"
                                onclick="return false"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                12                            </span>
                            <span class="matrix-price">
                                51.2                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
                                    </div><!-- end: ternary-wrapper -->
            </div><!-- end: border-gradient_content -->
        </div><!-- end: border-gradient -->
    </div><!-- end: col -->
</div><!-- end: row -->


<div class="row icon-tips text-left mt-3">
    <div class="col-md-5">
        <div>
            <i class="matrix-single matrix-children__active"></i>
            <span class="icon-tips_text">PARTNER INVITED BY YOU</span>
        </div>
        <div>
            <i class="matrix-single matrix-children__overflow"></i>
            <span class="icon-tips_text">OVERFLOW FROM UP</span>
        </div>
    </div>
    <div class="col-md-6">
        <div>
            <i class="matrix-single matrix-children__overflow_partner"></i>
            <span class="icon-tips_text">BOTTOM OVERFLOW</span>
        </div>
        <div>
            <i class="matrix-single matrix-children__advance"></i>
            <span class="icon-tips_text">PARTNER WHO IS AHEAD OF HIS INVITER</span>
        </div>
    </div>
</div>            
        </div>
    </div>
</div>

<div class="text-center mb-3">
    <!-- Toggle button -->
    <div class="button-con">
      <label for='cb1'>
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="dayIcon" x="0px" y="0px" viewBox="0 0 35 35" style="enable-background:new 0 0 35 35;" xml:space="preserve">
          <g id="Sun">
            <g>
              <path style="fill-rule:evenodd;clip-rule:evenodd;" d="M6,17.5C6,16.672,5.328,16,4.5,16h-3C0.672,16,0,16.672,0,17.5    S0.672,19,1.5,19h3C5.328,19,6,18.328,6,17.5z M7.5,26c-0.414,0-0.789,0.168-1.061,0.439l-2,2C4.168,28.711,4,29.086,4,29.5    C4,30.328,4.671,31,5.5,31c0.414,0,0.789-0.168,1.06-0.44l2-2C8.832,28.289,9,27.914,9,27.5C9,26.672,8.329,26,7.5,26z M17.5,6    C18.329,6,19,5.328,19,4.5v-3C19,0.672,18.329,0,17.5,0S16,0.672,16,1.5v3C16,5.328,16.671,6,17.5,6z M27.5,9    c0.414,0,0.789-0.168,1.06-0.439l2-2C30.832,6.289,31,5.914,31,5.5C31,4.672,30.329,4,29.5,4c-0.414,0-0.789,0.168-1.061,0.44    l-2,2C26.168,6.711,26,7.086,26,7.5C26,8.328,26.671,9,27.5,9z M6.439,8.561C6.711,8.832,7.086,9,7.5,9C8.328,9,9,8.328,9,7.5    c0-0.414-0.168-0.789-0.439-1.061l-2-2C6.289,4.168,5.914,4,5.5,4C4.672,4,4,4.672,4,5.5c0,0.414,0.168,0.789,0.439,1.06    L6.439,8.561z M33.5,16h-3c-0.828,0-1.5,0.672-1.5,1.5s0.672,1.5,1.5,1.5h3c0.828,0,1.5-0.672,1.5-1.5S34.328,16,33.5,16z     M28.561,26.439C28.289,26.168,27.914,26,27.5,26c-0.828,0-1.5,0.672-1.5,1.5c0,0.414,0.168,0.789,0.439,1.06l2,2    C28.711,30.832,29.086,31,29.5,31c0.828,0,1.5-0.672,1.5-1.5c0-0.414-0.168-0.789-0.439-1.061L28.561,26.439z M17.5,29    c-0.829,0-1.5,0.672-1.5,1.5v3c0,0.828,0.671,1.5,1.5,1.5s1.5-0.672,1.5-1.5v-3C19,29.672,18.329,29,17.5,29z M17.5,7    C11.71,7,7,11.71,7,17.5S11.71,28,17.5,28S28,23.29,28,17.5S23.29,7,17.5,7z M17.5,25c-4.136,0-7.5-3.364-7.5-7.5    c0-4.136,3.364-7.5,7.5-7.5c4.136,0,7.5,3.364,7.5,7.5C25,21.636,21.636,25,17.5,25z" />
            </g>
          </g>
        </svg>
      </label>
      <input class='toggle' id='cb1' type='checkbox' >
      <label class='toggle-button' for='cb1'></label>
      <label for='cb1'>
        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="nightIcon" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve">
          <path d="M96.76,66.458c-0.853-0.852-2.15-1.064-3.23-0.534c-6.063,2.991-12.858,4.571-19.655,4.571  C62.022,70.495,50.88,65.88,42.5,57.5C29.043,44.043,25.658,23.536,34.076,6.47c0.532-1.08,0.318-2.379-0.534-3.23  c-0.851-0.852-2.15-1.064-3.23-0.534c-4.918,2.427-9.375,5.619-13.246,9.491c-9.447,9.447-14.65,22.008-14.65,35.369  c0,13.36,5.203,25.921,14.65,35.368s22.008,14.65,35.368,14.65c13.361,0,25.921-5.203,35.369-14.65  c3.872-3.871,7.064-8.328,9.491-13.246C97.826,68.608,97.611,67.309,96.76,66.458z" />
        </svg>
      </label>
    </div>
    <script>
        // Enable Dark Theme
        window.addEventListener('DOMContentLoaded', function () {
            $('#cb1').click(function () {
                if($(this).prop('checked')) {
                    location.href = '?theme=dark';
                } else {
                    location.href = '?theme=default';
                }
            })
        });
    </script>
    <!-- end toggle button -->
</div>

<div id="Notice"></div>
<script>
var config = {
    site: {
        domain:   location.hostname,
        protocol: location.protocol + '//',
        hostname: location.hostname,
        link: 'https://lk.forsage.io/',
        course: {
            value: `ETH_USD`,
            symbol: `$`,
        },
    },
    user: {
        refkey: 'vpat19',
        address: '0x948e5f339942f9f6cf417c5fe6de73ef6059bd8b',
        isAuthSecure: false,
        sid: '2b2fd7148b32c82b6c700573550e5ffe',
    },
    lang: {
        /* contract.js */
        buyLevel                 : `Confirm the purchase`,
        notDetectedWallet        : `The Ethereum wallet is Not detected on your browser.`,
        unblockWallet            : `Unlock the wallet for a transaction`,
        notActiveWallet          : `Ethereum wallet is not active`,
        errorSendingTransaction  : `Error sending transaction: `,
        transactionSend          : `The transaction has been sent! Please wait for confirmation of the network.`,
        confirmTransaction       : `Confirm the transaction in your Ethereum wallet`,
        errorReadSmartContract   : `Read error SmartContract`,
        uplineNotRegistered      : `Your upline is not registered`,
        userNotExists            : `The user is not registered`,
        authError                : `Authorization error`,
        
        /* common.js */
        copied                   : `Copied`,

        // Сокеты события
        'ws-regLevel_0'          : `Joined ID:{user_id}`,
        'ws-regLevel_1'          : `Joined ID:{user_id}. You are on the right way!`,
        'ws-regLevel_2'          : `Meet the new member ID:{user_id}.`,
        'ws-regLevel_3'          : `New user ID:{user_id}. Welcome to Forsage!`,
        'ws-newUserPlace'        : `ID:{user_id} earned {price_level} {crypto_name} (\${currency_usd}) in the {matrix}`,
        'ws-upgrade'             : `ID:{user_id} buy {level} slot in {matrix} from ID:{ref_id}.`,
        'ws-reinvest'            : `ID:{user_id} was auto-reinvested in slot {level} ({matrix})`,
        'ws-missedEthReceive'    : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}). You must perform the upgrade in ({matrix})`,
        'ws-sentExtraEthDividends':`ID:{user_id} received a bonus {price_level} {crypto_name} (\${currency_usd})`,
        'ws-cannotSendMoneyEvent': `ID:{user_id} error getting translation`,
        'ws-leadingPartner'      : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}) from (ID:{u_id}) for area # {level} ({matrix})`,
        'ws-leadingPartnerToUpline':`ID:{u_id} overtook its parent ID is:{user_id} in the matrix {matrix} with area # {level}`,
        'ws-leadingPlacePurchase': `ID:{user_id} ahead of your inviter (ID:{up_id}) for area # {level} ({matrix})`,

        // Скрипт с выводом даты отсчета времени
        'elt-years_0'            : `year`,
        'elt-years_1'            : `year`,
        'elt-years_2'            : `years`,
        'elt-months_0'           : `a month`,
        'elt-months_1'           : `months`,
        'elt-months_2'           : `months`,
        'elt-days_0'             : `day`,
        'elt-days_1'             : `day`,
        'elt-days_2'             : `days`,
        'elt-hours_0'            : `hour`,
        'elt-hours_1'            : `hours`,
        'elt-hours_2'            : `hours`,
        'elt-minutes_0'          : `min`,
        'elt-minutes_1'          : `min`,
        'elt-minutes_2'          : `min`,
        'elt-minutes_3'          : `a minute`,
        'elt-seconds_0'          : `second`,
        'elt-seconds_1'          : `seconds`,
        'elt-seconds_2'          : `seconds`,
        'elt-seconds_3'          : `second`,
        'elt-end'                : ` ago`,
        'elt-freshly'            : `just`,
        'elt-deadline'           : `time left`,
        'elt-after'              : `through `,
    },
    locked: {
        buyLevel      : ``,
        authorization : ``,
        registration  : ``,
    },
    permissions: {
        buyLevel      : `0`,
    },
    isFramed: null,
    isMobile: false,
    haveWallet: window.ethereum || window.web3,
};

// Получить основной домен
let arr = config.site.domain.split('.');
if(arr.length > 2) {
    config.site.domain = arr.slice(arr.length - 2).join('.')
}

// Запущен ли сайт в теге iframe
try {
  config.isFramed = window != window.top || document != top.document || self.location != top.location;
} catch (e) {
  config.isFramed = true;
}
</script>
<script src="assets/Decentralized/js/jquery.min.js"></script>
<script src="assets/Decentralized/js/vue.min.js"></script>
<script src="assets/Decentralized/js/socket.io.js"></script>
<script src="assets/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets/Decentralized/js/common.js"></script>
<script src="assets/Decentralized/js/contract.js"></script>
<script src="assets/Decentralized/js/cabinet.js"></script><div class="require-auth">
    Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
    <br>
    <div>
                    <button class="btn btn-success" id="reauth">
                Authorization            </button>
            </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
<script type="text/javascript">

var web3 = new Web3(Web3.givenProvider || "<?=$infuraAPI; ?>");

var arrayABI = <?=$mainContractABI; ?>;

var mainContractAddress = "<?=$mainContractAddress; ?>";

var myAccountAddress = "<?=$userWallet;?>";

if (typeof web3 !== 'undefined'){

var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
	from: myAccountAddress, // default from address
	});






// fetching user level
fetchRemainingTime(myAccountAddress);
async function fetchRemainingTime(myAccountAddress){

	var remainingDay = await myContract.methods.viewTimestampSinceJoined(myAccountAddress).call({from: myAccountAddress});

	for (var i = 0; i < remainingDay.length; i++) {

	var priceOfLevel = await myContract.methods.priceOfLevel(i+1).call({from: myAccountAddress});
    document.getElementById("buyAmountData"+[i]).textContent = (priceOfLevel / 1000000000000000000)+" ETH";
		
		if(remainingDay[i] > 0){

			
			//change ribbon color
			document.getElementById("ribbonColor"+[i]).classList.add('ribbon-success');
			document.getElementById("ribbonColor"+[i]).classList.remove('ribbon-danger');	


			//change the ribbon name
			document.getElementById("ribbonName"+[i]).textContent="<?=$$lang['Active'];?>";


			//change $ amount color
			document.getElementById("buyAmountData"+[i]).classList.add('text-success');
			document.getElementById("buyAmountData"+[i]).classList.remove('text-danger');
			document.getElementById("buyAmountData"+[i]).classList.remove('pb-30');


			


			//remaining days
			document.getElementById("remainingDays"+[i]).textContent="Remain Days: "+ (remainingDay[i] / 86400).toFixed(0);

			//button change
			document.getElementById("levelButton"+[i]).classList.add('btn-success');
			document.getElementById("levelButton"+[i]).classList.remove('btn-danger');
			document.getElementById("levelButton"+[i]).textContent="EXTEND 100 DAYS";
			
		}
	}
}

}	//web3 check




</script>


<script type="text/javascript" src="core/js/dashboard.footer.js">

	
</script>
</body>
</html>