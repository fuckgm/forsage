<?php
   $page = 'Partners';
   //include('core/common_code.php');
    include('top_navbar.php');
    include('sidebar.php');
    include('s_top_navbar.php');
   // include('s_sidebar.php');
   ?>
    <link rel="stylesheet" href="global/vendor/datatables.net-bs4/dataTables.bootstrap4.minfd53.css?v4.0.1">

<style>
   div#example_length ,div#example_filter {
   display:none
   }
</style>
<!-- <div class="col-lg-12"> -->
   <!-- Всплывающие окошки с последними событиями -->
  
   <div class="row margin-bottom-70">
      <div class="col">
         <div class="border-gradient">
            <div class="border-gradient_content">
               <h3 class="head">Partners</h3>
               <form class="bg-black_transparent filter-partners" method="POST" action="<?php echo SITE_URL.'dashboard/?s_partners'?>">
                  <h4 class="text-center">Filter: </h4>
                  <div class="row">
                     <div class="col-md-3 form-group">
                        <label for="level">Slot</label>
                        <select name="level" id="level" class="form-control">
                           <option value="">---</option>
                           <option value="1" <?php if($_POST){ if($_POST['level']=='1') { echo 'selected=selected';} }?>>
                              1
                           </option>
                           <option value="2" <?php if($_POST){ if($_POST['level']=='2') { echo 'selected=selected';} }?>>
                              2
                           </option>
                           <option value="3" <?php if($_POST){ if($_POST['level']=='3') { echo 'selected=selected';} }?>>
                              3
                           </option>
                           <option value="4" <?php if($_POST){ if($_POST['level']=='4') { echo 'selected=selected';} }?>>
                              4
                           </option>
                           <option value="5" <?php if($_POST){ if($_POST['level']=='5') { echo 'selected=selected';} }?>>
                              5
                           </option>
                           <option value="6" <?php if($_POST){ if($_POST['level']=='6') { echo 'selected=selected';} }?>>
                              6
                           </option>
                           <option value="7" <?php if($_POST){ if($_POST['level']=='7') { echo 'selected=selected';} }?>>
                              7
                           </option>
                           <option value="8" <?php if($_POST){ if($_POST['level']=='8') { echo 'selected=selected';} }?>>
                              8
                           </option>
                           <option value="9" <?php if($_POST){ if($_POST['level']=='9') { echo 'selected=selected';} }?>>
                              9
                           </option>
                           <option value="10" <?php if($_POST){ if($_POST['level']=='10') { echo 'selected=selected';} }?>>
                              10
                           </option>
                           <option value="11" <?php if($_POST){ if($_POST['level']=='11') { echo 'selected=selected';} }?>>
                              11
                           </option>
                           <option value="12" <?php if($_POST){ if($_POST['level']=='12') { echo 'selected=selected';} }?>>
                              12
                           </option>
                        </select>
                     </div>
                     <div class="col-md-3 form-group">
                        <label for="matrix">Program</label>
                        <select name="plan" id="plan" class="form-control">
                           <option value="">---</option>
                           <option value="x3" <?php if($_POST){ if($_POST['plan']=='x3') { echo 'selected=selected';} }?>  >
                              x3
                           </option>
                           <option value="x6" <?php if($_POST){ if($_POST['plan']=='x6') { echo 'selected=selected';} }?>>
                              x6
                           </option>
                        </select>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <!--<label for="search">Search by ID | Wallet</label>-->
						   <label for="search">Search by Wallet ID</label>
                           <input type="text" name="search" value="<?php if($_POST){ if($_POST['search']!='') { echo $_POST['search'];} }?>" placeholder="Enter..." id="search" class="form-control">
                        </div>
                     </div>
                  </div>
                  <input type="hidden" name="user" value="123">
                  <input type="hidden" name="sid" value="">
                  <button type="submit" class="btn btn-primary">
                  Apply                    </button>
                  <a href="<?php echo SITE_URL.'dashboard/?partners';?>" class="btn btn-secondary">
                  Reset filter                    </a>
               </form>
               <div class="row bg-black_transparent partners-group">
                  <div class="col-6">
                     <div class="partners-group__tip">
                        <div class="row">
                           <div class="col-8">Clicks:</div>
                           <div class="col-4">1</div>
                        </div>
                        <div class="row">
                           <div class="col-8">Number of registrations:</div>
                           <div class="col-4">0</div>
                        </div>
                        <div class="row">
                           <div class="col-8">Registrations for the week:</div>
                           <div class="col-4">0</div>
                        </div>
                        <div class="row">
                           <div class="col-8">Registrations for 24 hours:</div>
                           <div class="col-4">0</div>
                        </div>
                        <div class="row">
                           <div class="col-8">Partners in the structure:</div>
                           <div class="col-4">0</div>
                        </div>
                     </div>
                  </div>
                  <div class="col-6 text-right">
                     <!-- <div class="partners-group__tip">
                        <i class="fas fa-info"></i> &nbsp;To receive referral links to partners, you need to invite<br> else "5" member to the structure                        </div> -->
                  </div>
               </div>
			   <!-- Plugins For This Page -->

               <h4 class="head">Your Downline Partners</h4>
               <div class="mycls table-responsive" id="myid">
                  <table class="tablePartners table-hover table-striped table tablePartners" id="example">
                     <thead>
                        <tr>
                           <td style="">
                              <a >
                              User ID                                                                            </a>
                           </td>
                           <td style="">
                              <a >
                              Level                                                                            </a>
                           </td>
                           <td style="">
                              Wallet Address
                           </td>
                           <td style="">
                              <a >
                              Date                                                                            </a>
                           </td>
						   <td>Plan</td>
                        </tr>
                     </thead>
                     <tbody>


<?php

if($_POST){
	$levels= $_POST['level'];
    $search= $_POST['search'];
    $plan= $_POST['plan'];

    define('LEVELS',$levels);
    define('SEARCH',$search);
	define('PLAN',$plan);

	function fetchDownlines($userID, $conn, $level=0){

	$query = "SELECT * FROM forsage_event_reglevel where referrerID='".clean($userID)."'";
	$result = mysqli_query($conn,$query);
	$row = mysqli_num_rows($result);
	$tempArray = array();
	if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
			array_push($tempArray,$row1['userID']);
			$levels = LEVELS;
            $search = SEARCH;
			$plan = PLAN;
              
if($levels=='' && $search=='' && $plan=="")
{
	echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>
								</tr>
							';
}elseif($levels=='' && $search=='' && $plan!="")
{
	if($plan==$row1['plan']){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}
elseif($levels=='' && $search!='' && $plan=="")
{
	if($search==$row1['userWallet']){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}elseif($levels=='' && $search!='' && $plan!="")
{
	if($search==$row1['userWallet'] && $row1['plan']==$plan){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}elseif($levels!='' && $search=='' && $plan=="")
{
	if($levels==$level){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}
elseif($levels!='' && $search=='' && $plan!="")
{
	if($levels==$level && $row1['plan']==$plan){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}elseif($levels!='' && $search!='' && $plan=="")
{
	if($levels==$level && $search==$row1['userWallet']){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}elseif($levels!='' && $search!='' && $plan!="")
{
	if($levels==$level && $search==$row1['userWallet'] && $row1['plan']==$plan){
		echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
	}
}else{
	echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';
}



		}
	}
	return $tempArray;
	}
}else{
	function fetchDownlines($userID, $conn, $level=0){

	$query = "SELECT * FROM forsage_event_reglevel where referrerID='".clean($userID)."' ";
	$result = mysqli_query($conn,$query);
	$row = mysqli_num_rows($result);
	$tempArray = array();
	if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
			array_push($tempArray,$row1['userID']);


						echo'

								<tr role="row" class="odd">

									<td>'.$row1['userID'].'</td>
									<td>'.$level.'</td>
									<td>
									<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
									</td>
									<td>'.date('m/d/Y', $row1['timestamp']).'</td>
									<td>'.$row1['plan'].'</td>

								</tr>

							';


		}
	}
	return $tempArray;
	}
}





//Toal partners - all levels

$mainArray = array();
$level1Array = array();

//level 1 referrals
$tempArray2 = fetchDownlines($userID, $conn, 1);

if(count($tempArray2) > 0){
	$mainArray = array_merge($mainArray, $tempArray2);
	$level1Array = $tempArray2;

		//These are level 1 refs
		foreach ($tempArray2 as $key) {

			//level 2 referrals
			$tempArray2 = fetchDownlines($key, $conn, 2);

			if(count($tempArray2) > 0){

				$mainArray = array_merge($mainArray, $tempArray2);
				//These are level 2 refs
				foreach ($tempArray2 as $key) {

					//level 2 referrals
					$tempArray2 = fetchDownlines($key, $conn, 3);

					//level 3 referrals
					if(count($tempArray2) > 0){

						$mainArray = array_merge($mainArray, $tempArray2);

							//level 4
							foreach ($tempArray2 as $key) {

								$tempArray2 = fetchDownlines($key, $conn, 4);

								//level 4 referrals
								if(count($tempArray2) > 0){

									$mainArray = array_merge($mainArray, $tempArray2);


										//level 5
										foreach ($tempArray2 as $key) {

										$tempArray2 = fetchDownlines($key, $conn, 5);

										//level 5 referrals
										if(count($tempArray2) > 0){

											$mainArray = array_merge($mainArray, $tempArray2);



//level 6
foreach ($tempArray2 as $key) {

$tempArray2 = fetchDownlines($key, $conn, 6);

//level 6 referrals
if(count($tempArray2) > 0){

	$mainArray = array_merge($mainArray, $tempArray2);

	//level 7
	foreach ($tempArray2 as $key) {

	$tempArray2 = fetchDownlines($key, $conn, 7);

	//level 7 referrals
	if(count($tempArray2) > 0){

		$mainArray = array_merge($mainArray, $tempArray2);


		//level 8
		foreach ($tempArray2 as $key) {

		$tempArray2 = fetchDownlines($key, $conn, 8);

		//level 8 referrals
		if(count($tempArray2) > 0){

			$mainArray = array_merge($mainArray, $tempArray2);


			//level 9
			foreach ($tempArray2 as $key) {

			$tempArray2 = fetchDownlines($key, $conn, 9);

			//level 9 referrals
			if(count($tempArray2) > 0){

				$mainArray = array_merge($mainArray, $tempArray2);


				//level 10
				foreach ($tempArray2 as $key) {

				$tempArray2 = fetchDownlines($key, $conn, 10);

				//level 10 referrals
				if(count($tempArray2) > 0){

					$mainArray = array_merge($mainArray, $tempArray2);






				}//level 10 if condition


				}	//level 10 foreach



			}//level 9 if condition


			}	//level 9 foreach



		}//level 8 if condition


		}	//level 8 foreach



	}//level 7 if condition


	}	//level 7 foreach




}//level 6 if condition


}	//level 6 foreach




										}//level 5 if condition


									}	//level 5 foreach


								}//level 4 if condition


							}	//level 4 foreach


					}//level 3 if condition


				}	//level 3 foreach


			}//level 2 if condition


		}	//level 2 foreach



}	// level 1 if condition
$totalPartners = count($mainArray);
$level1Partners = count($level1Array);


?>

  </tbody>
                  </table>
                  <div class="pagination_wrapper">
                  </div>
               </div>
               <!-- end: border-gradient_content -->
            </div>
            <!-- end: border-gradient -->
         </div>
      </div>
   </div>
</div>
</div>
<!-- </div> -->



<!-- <?php
include('information_ethbullx3.php');
?> -->

<div id="Notice"></div>
<script>
   var config = {
       site: {
           domain:   location.hostname,
           protocol: location.protocol + '//',
           hostname: location.hostname,
		//link: 'https://lk.forsage.io/',
        link: '<?php echo SITE_URL;?>',
           course: {
               value: `ETH_USD`,
               symbol: `$`,
           },
       },
       user: {
           refkey: 'vpat19',
           address: '0x948e5f339942f9f6cf417c5fe6de73ef6059bd8b',
           isAuthSecure: false,
           sid: '2b2fd7148b32c82b6c700573550e5ffe',
       },
       lang: {
           /* contract.js */
           buyLevel                 : `Confirm the purchase`,
           notDetectedWallet        : `The Ethereum wallet is Not detected on your browser.`,
           unblockWallet            : `Unlock the wallet for a transaction`,
           notActiveWallet          : `Ethereum wallet is not active`,
           errorSendingTransaction  : `Error sending transaction: `,
           transactionSend          : `The transaction has been sent! Please wait for confirmation of the network.`,
           confirmTransaction       : `Confirm the transaction in your Ethereum wallet`,
           errorReadSmartContract   : `Read error SmartContract`,
           uplineNotRegistered      : `Your upline is not registered`,
           userNotExists            : `The user is not registered`,
           authError                : `Authorization error`,

           /* common.js */
           copied                   : `Copied`,

           // Сокеты события
           'ws-regLevel_0'          : `Joined ID:{user_id}`,
           'ws-regLevel_1'          : `Joined ID:{user_id}. You are on the right way!`,
           'ws-regLevel_2'          : `Meet the new member ID:{user_id}.`,
           'ws-regLevel_3'          : `New user ID:{user_id}. Welcome to Forsage!`,
           'ws-newUserPlace'        : `ID:{user_id} earned {price_level} {crypto_name} (\${currency_usd}) in the {matrix}`,
           'ws-upgrade'             : `ID:{user_id} buy {level} slot in {matrix} from ID:{ref_id}.`,
           'ws-reinvest'            : `ID:{user_id} was auto-reinvested in slot {level} ({matrix})`,
           'ws-missedEthReceive'    : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}). You must perform the upgrade in ({matrix})`,
           'ws-sentExtraEthDividends':`ID:{user_id} received a bonus {price_level} {crypto_name} (\${currency_usd})`,
           'ws-cannotSendMoneyEvent': `ID:{user_id} error getting translation`,
           'ws-leadingPartner'      : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}) from (ID:{u_id}) for area # {level} ({matrix})`,
           'ws-leadingPartnerToUpline':`ID:{u_id} overtook its parent ID is:{user_id} in the matrix {matrix} with area # {level}`,
           'ws-leadingPlacePurchase': `ID:{user_id} ahead of your inviter (ID:{up_id}) for area # {level} ({matrix})`,

           // Скрипт с выводом даты отсчета времени
           'elt-years_0'            : `year`,
           'elt-years_1'            : `year`,
           'elt-years_2'            : `years`,
           'elt-months_0'           : `a month`,
           'elt-months_1'           : `months`,
           'elt-months_2'           : `months`,
           'elt-days_0'             : `day`,
           'elt-days_1'             : `day`,
           'elt-days_2'             : `days`,
           'elt-hours_0'            : `hour`,
           'elt-hours_1'            : `hours`,
           'elt-hours_2'            : `hours`,
           'elt-minutes_0'          : `min`,
           'elt-minutes_1'          : `min`,
           'elt-minutes_2'          : `min`,
           'elt-minutes_3'          : `a minute`,
           'elt-seconds_0'          : `second`,
           'elt-seconds_1'          : `seconds`,
           'elt-seconds_2'          : `seconds`,
           'elt-seconds_3'          : `second`,
           'elt-end'                : ` ago`,
           'elt-freshly'            : `just`,
           'elt-deadline'           : `time left`,
           'elt-after'              : `through `,
       },
       locked: {
           buyLevel      : ``,
           authorization : ``,
           registration  : ``,
       },
       permissions: {
           buyLevel      : `0`,
       },
       isFramed: null,
       isMobile: false,
       haveWallet: window.ethereum || window.web3,
   };

   // Получить основной домен
   let arr = config.site.domain.split('.');
   if(arr.length > 2) {
       config.site.domain = arr.slice(arr.length - 2).join('.')
   }

   // Запущен ли сайт в теге iframe
   try {
     config.isFramed = window != window.top || document != top.document || self.location != top.location;
   } catch (e) {
     config.isFramed = true;
   }
</script>
  <script type="text/javascript" src="assets_s/js/jquery-3.5.1.js" ></script>

  <script src="global/vendor/datatables.net/jquery.dataTablesfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-bs4/dataTables.bootstrap4fd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive/dataTables.responsive.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.minfd53.js?v4.0.1"></script>
               <script>$(document).ready(function() {
                  $.noConflict();
                  var table = $('#example').DataTable( {
                     responsive: true
                  } );

                  new $.fn.dataTable.FixedHeader( table );
                  } );
               </script>


<script src="assets_s/Decentralized/js/jquery.min.js"></script>
<script src="assets_s/Decentralized/js/vue.min.js"></script>
<script src="assets_s/Decentralized/js/socket.io.js"></script>
<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets_s/Decentralized/js/common.js"></script>
<script src="assets_s/Decentralized/js/contract.js"></script>
<script src="assets_s/Decentralized/js/cabinet.js"></script>
<div class="require-auth">
   Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
   <br>
   <div>
      <button class="btn btn-success" id="reauth">
      Authorization            </button>
   </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript>
   <div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div>
</noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>

<?php
include('footer.php');
?>
