  <!-- Footer -->
   <footer class="site-footer">
    <div class="site-footer-legal">Contract Address: <a class="text-white" style="word-break: break-all;" href="https://etherscan.io/0xbe1f94f08db7db10baa4858411d8fb5c9279b3d9" target="_blank">0xbe1f94f08db7db10baa4858411d8fb5c9279b3d9</a></div>
    <div class="site-footer-right">
      © 2020 <i class="red-600 icon md-favorite"></i> by <a href="<?php echo SITE_URL;?>" style="color: #ffffff;"> Ethbull.io</a>
    </div>
  </footer>
<style type="text/css">
    .ajs-message.ajs-green { color:  #fff;  background-color: #66bb6a;  border: 1px solid rgba(0,0,0,.1); border-top-left-radius: 20px;
	border-top-right-radius: 30px;
    border-bottom-right-radius: 0px;
    border-bottom-left-radius: 20px; }
	.ajs-message.ajs-sky { color:  #fff;  background-color: #26c6da; border: 1px solid rgba(0,0,0,.1); border-top-left-radius: 20px;
    border-top-right-radius: 30px;
    border-bottom-right-radius: 0px;
    border-bottom-left-radius: 20px;}
	.ajs-message.ajs-yellow { color:  #000;  background-color: #ffa726;  border: 1px solid rgba(0,0,0,.1); border-top-left-radius: 20px;
    border-top-right-radius: 30px;
    border-bottom-right-radius: 0px;
    border-bottom-left-radius: 20px;}
    .ajs-message.ajs-red { color:  #000;  background-color: #ef5350;  border: 1px solid rgba(0,0,0,.1); border-top-left-radius: 20px;
    border-top-right-radius: 30px;
    border-bottom-right-radius: 0px;
    border-bottom-left-radius: 20px;}

</style>

  <!-- Core  -->
  <script data-cfasync="false" src="../../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="global/vendor/babel-external-helpers/babel-external-helpersfd53.js?v4.0.1"></script>
  <script src="global/vendor/jquery/jquery.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/popper-js/umd/popper.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/bootstrap/bootstrap.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/animsition/animsition.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/mousewheel/jquery.mousewheel.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/asscrollbar/jquery-asScrollbar.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/asscrollable/jquery-asScrollable.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/ashoverscroll/jquery-asHoverScroll.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/waves/waves.minfd53.js?v4.0.1"></script>

  <!-- Plugins -->
  <script src="global/vendor/switchery/switchery.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/intro-js/intro.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/screenfull/screenfull.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/slidepanel/jquery-slidePanel.minfd53.js?v4.0.1"></script>

  <!-- Plugins For This Page -->
  <script src="global/vendor/chartist/chartist.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/jvectormap/jquery-jvectormap.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/jvectormap/maps/jquery-jvectormap-world-mill-enfd53.js?v4.0.1"></script>
  <script src="global/vendor/matchheight/jquery.matchHeight-minfd53.js?v4.0.1"></script>
  <script src="global/vendor/peity/jquery.peity.minfd53.js?v4.0.1"></script>

    <script src="global/vendor/datatables.net/jquery.dataTablesfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-bs4/dataTables.bootstrap4fd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive/dataTables.responsive.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.minfd53.js?v4.0.1"></script>

  <!-- Scripts -->
  <script src="global/js/State.minfd53.js?v4.0.1"></script>
  <script src="global/js/Component.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin.minfd53.js?v4.0.1"></script>
  <script src="global/js/Base.minfd53.js?v4.0.1"></script>
  <script src="global/js/Config.minfd53.js?v4.0.1"></script>

  <script src="assets/js/Section/Menubar.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Section/Sidebar.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Section/PageAside.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Plugin/menu.minfd53.js?v4.0.1"></script>

  <!-- Config -->
  <script src="global/js/config/colors.minfd53.js?v4.0.1"></script>
  <script src="assets/js/config/tour.minfd53.js?v4.0.1"></script>
  <script>
    Config.set('assets', 'assets');
  </script>

  <!-- Page -->
  <script src="assets/js/Site.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/asscrollable.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/slidepanel.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/switchery.minfd53.js?v4.0.1"></script>

  <script src="global/js/Plugin/matchheight.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/jvectormap.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/peity.minfd53.js?v4.0.1"></script>


  <script src="assets/examples/js/dashboard/v1.minfd53.js?v4.0.1"></script>
  <script src="../alertify/socket.io.js" type="text/javascript"></script>
  <script>
  	$(document).ready(function() {
		var socket = io.connect( 'https://socket.ethbull.io:8081');
         		 socket.on('newEvent',async function(data){
                	if(data.type=='join'){
                    	alertify.notify(data.message, 'sky', 10, function(){});
                	}
                 	if(data.type=='earn'){
                    	alertify.notify(data.message, 'yellow', 10, function(){});
                	}
                 	if(data.type=='withdraw'){
                    	alertify.notify(data.message, 'green', 10, function(){});
                	}
                 	if(data.type=='lost'){
                    	alertify.notify(data.message, 'red', 10, function(){});
                	}

                });
        	});
</script>

  <!-- Google Analytics -->

<span class="language-block"> <span style="padding: 5px 15px; background-color: #111; color: #fff; font-size: 24px;float: left;"> <i class="fa fa-language" aria-hidden="true"></i> </span> <ul class="list-unstyled lang-list" style="float: left;padding: 0;"> <div id="google_translate_element"></div> </ul> </span>

<script type="text/javascript"> function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); } </script>

<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
 <script type="text/javascript">

    // $(document).ready(function($) {
    //   $(".toggle").click(function() {
    //     $(".toggle").toggleClass("active");
    //     $(".page").toggleClass("night");
    //     $('#myLink_33').attr('href','dashboard/?s_dashboard')
    //     $.cookie("toggle", $(".toggle").hasClass('active'));
    //     location.reload('dashboard/?s_dashboard');
    //     window.location.href='/s_dashboard';
    //   });

    //   if ($.cookie("toggle") == "true") {
    //     $(".toggle").addClass("active");
    //     $(".page").addClass("night");
    //   }
    // });


   // function toggleDashboard(){
   //    if($(".switch_dashboard").is(":visible")){
   //       window.location.href='http://localhost/ethbull-forsage/dashboard/?s_dashboard';
   //    }
   //    else{
   //       window.location.href='http://localhost/ethbull-forsage/dashboard/';
   //    }
   //  }


   $('input[type="checkbox"]').click(function(){
      if($(this).prop("checked") == true){
         console.log("true");
         window.location.href='<?php echo SITE_URL ?>dashboard/?s_dashboard';
         // $.cookie("togglechecked", "true");
         localStorage.setItem("checkbox", "true");

      }

      else if($(this).prop("checked") == false){
         console.log("false");
         window.location.href='<?php echo SITE_URL ?>dashboard/';
      }
  });

 </script>
</body>


<!-- Mirrored from getbootstrapadmin.com/remark/material/iconbar/tables/datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Feb 2020 16:11:51 GMT -->
</html>
