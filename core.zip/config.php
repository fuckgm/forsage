<?php


//system default localhost server
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
//define('DB_NAME','ethbull-forsage-new');
define('DB_NAME','ef1');



$conn = mysqli_connect(DB_HOST,DB_USER, DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno()){
  	echo "Failed to connect to MySQL: " . mysqli_connect_error();
 }




//getting admin setting data
$query = "SELECT * FROM adminsetting  ";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);
if($row != NULL){
	$mainContractAddress = $row['mainContractAddress'];
	$mainContractABI = $row['mainContractABI'];
	$ethPrice = $row['ethPiceInUsd'];
	$gasPriceAverage = $row['gasPriceAverage'];
	$gasPriceFast = $row['gasPriceFast'];
	$siteurl = $row['siteURL'];
	
	define('SITE_URL', $siteurl);
}



 function clean($string) {
   $string = str_replace(' ', '', $string); // Remove all spaces.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}


