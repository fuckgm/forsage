<?php
$page = "Swap";
include('top_navbar.php');
include('sidebar.php');

?>
 

  <!-- Page -->
  <div class="page">
	<div class="page-content container-fluid">
		<div class="row" data-plugin="matchHeight" data-by-row="true">
		<div class="col-xxl-12 col-lg-12 col-sm-12 text-center" style="">
			<div class="page-content  vertical-align-middle">
			  <i class="icon md-settings icon-spin page-maintenance-icon font-size-70" aria-hidden="true"></i>
			  <h2><?=$$lang['We Are Comming Soon']; ?></h2>
			  <p><?=$$lang['PLEASE GIVE US A MOMENT TO SORT THINGS OUT']; ?></p>

			  <footer class="page-copyright">
				<div class="social">
				  <a class="btn btn-icon btn-pure waves-effect waves-classic" href="javascript:void(0)">
				  <i class="icon bd-twitter" aria-hidden="true"></i>
				</a>
				  <a class="btn btn-icon btn-pure waves-effect waves-classic" href="javascript:void(0)">
				  <i class="icon bd-facebook" aria-hidden="true"></i>
				</a>
				  <a class="btn btn-icon btn-pure waves-effect waves-classic" href="javascript:void(0)">
				  <i class="icon bd-google-plus" aria-hidden="true"></i>
				</a>
				</div>
			  </footer>
			</div>
		</div>

        </div>
    </div>
	
  </div>
  <!-- End Page -->

<?php
include('footer.php');
?>