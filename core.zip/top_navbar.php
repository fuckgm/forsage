<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">

<!-- Mirrored from getbootstrapadmin.com/remark/material/iconbar/tables/datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Feb 2020 16:11:44 GMT -->
<head>
<?php
  require_once('lang.php');
  if(isset($_COOKIE['country']) && $_COOKIE['country'] != ""){
    $lang = "language_".$_COOKIE['country'];
  }else{
    $lang = "language_en";
  }


//-- switch forsage dashboard or ethbull -----
$forsage_url = SITE_URL.'dashboard/?s_dashboard';
$ethbull_url = SITE_URL.'dashboard/';
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if($forsage_url==$url){
$_SESSION["webpath"] = '1';
}else{
$_SESSION["webpath"] = '2';
}
//--------end code----------------------------
?>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap material admin template">
  <meta name="author" content="">

  <title> <?php echo $page; ?> | Ethbull.io</title>

  <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
  <link rel="shortcut icon" href="assets/images/favicon.png">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="global/css/bootstrap.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/css/bootstrap-extend.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="assets/css/site.minfd53.css?<?php echo time() ?>">



  <!-- Plugins -->
  <link rel="stylesheet" href="global/vendor/animsition/animsition.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/asscrollable/asScrollable.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/switchery/switchery.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/intro-js/introjs.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/slidepanel/slidePanel.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/flag-icon-css/flag-icon.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/waves/waves.minfd53.css?v4.0.1">

  <!-- Plugins For This Page -->
  <link rel="stylesheet" href="assets/examples/css/dashboard/v1.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-bs4/dataTables.bootstrap4.minfd53.css?v4.0.1">
 <link rel="stylesheet" href="global/vendor/datatables.net-select-bs4/dataTables.select.bootstrap4.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-responsive-bs4/dataTables.responsive.bootstrap4.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.minfd53.css?v4.0.1">
  <!-- Page -->
  <link rel="stylesheet" href="assets/examples/css/tables/datatable.minfd53.css?v4.0.1">
  <!-- Fonts -->
  <link rel="stylesheet" href="global/fonts/material-design/material-design.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/fonts/brand-icons/brand-icons.minfd53.css?v4.0.1">
  <link rel='stylesheet' href="https://fonts.googleapis.com/css?family=Roboto:400,400italic,700">
  <link rel="stylesheet" href="global/fonts/font-awesome/font-awesome.minfd53.css?v4.0.1">
  <script src="https://kit.fontawesome.com/ee18e7efa7.js" crossorigin="anonymous"></script>

  <!--[if lt IE 9]>
    <script src="../../global/vendor/html5shiv/html5shiv.min.js?v4.0.1"></script>
    <![endif]-->

  <!--[if lt IE 10]>
    <script src="../../global/vendor/media-match/media.match.min.js?v4.0.1"></script>
    <script src="../../global/vendor/respond/respond.min.js?v4.0.1"></script>
    <![endif]-->

  <!-- Scripts -->
  <script src="global/vendor/breakpoints/breakpoints.minfd53.js?v4.0.1"></script>
  <script>
    Breakpoints();
  </script>
 <style>
.dropbtn {
  background-color: #000;
  color: white;
  /*padding: 16px;*/
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #000;}

/*toggle buttons*/

.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

/*.night{
  background-color: red!important;
}*/
</style>
<style type="text/css">
    .language-block {	position: fixed;	right: 0px;	top: 60px;	z-index: 111;	display: none;}	.language-block:hover .lang-list {	width: 160px;	padding: 10px 15px;	font-size: 14px;	background-color: #fff;	box-shadow: -3px 2px 5px rgba(117, 105, 105, 0.6);	}	.lang-list {	width: 0;	overflow: hidden;	transition: 0.5s;	}
</style>

</head>
<body class="animsition ">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

  <nav class="site-navbar navbar navbar-default navbar-inverse navbar-fixed-top navbar-mega"
    role="navigation">

    <div class="navbar-header">
      <button type="button" class="navbar-toggler hamburger hamburger-close navbar-toggler-left hided"
        data-toggle="menubar">
        <span class="sr-only">Toggle navigation</span>
        <span class="hamburger-bar"></span>
      </button>
      <button type="button" class="navbar-toggler collapsed" data-target="#site-navbar-collapse"
        data-toggle="collapse">
        <i class="icon md-more" aria-hidden="true"></i>
      </button>
      <div class="navbar-brand navbar-brand-center">
        <!--img class="navbar-brand-logo" src="assets_s/Decentralized/img/logo-03.svg"-->
        <img class="navbar-brand-logo" src="assets/images/logo.png">
      </div>

    </div>

    <div class="navbar-container container-fluid">
      <!-- Navbar Collapse -->
      <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
        <!-- Navbar Toolbar -->
        <ul class="nav col-xl-6 col-lg-6 col-md-2 navbar-toolbar">
          <li class="nav-item hidden-float" id="toggleMenubar">
            <a class="nav-link" data-toggle="menubar" href="#" role="button">
                <i class="icon hamburger hamburger-arrow-left">
                  <span class="sr-only">Toggle menubar</span>
                  <span class="hamburger-bar"></span>
                </i>
              </a>
          </li>
		  <div class=" text-center">
		  <li class="nav-item hide-add">
            <a class="nav-link px-0"  href="https://etherscan.io/address/<?php echo $userWallet; ?>" target="_blank" aria-expanded="false" data-animation="fade" role="button"><i class="fab fa-ethereum"></i> ETH Address: <?php echo $userWallet; ?> <i class="icon fa-external-link-square" aria-hidden="true" target="new"></i></a>
          </li>
		  </div>


        </ul>
        <!-- End Navbar Toolbar -->
        <!-- Navbar Toolbar Right -->
        <ul class="nav col-xl-6 col-lg-6 col-md-10 navbar-toolbar px-2 ">
    		<div class="" style="width:100%">
    		  <li class="nav-item px-1 navbar" >
            <span class="text-white px-2 mr-3" style="font-size: 18px;font-weight: 900;color:#f4de06 !important">ETHBULL</span>
            <label class="switch mb-0">
              <?php
			  error_reporting(0);
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
 $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$e=explode("/?",$url);
$k=explode("/",$e[1]); 
//or ($k[0]=='page')
              $vChecked='';
              if(isset($_GET['s_dashboard'])  or isset($_GET['statistics']) or isset($_GET['information']) or isset($_GET['s_partners']) or isset($_GET['s_uplines'])){
                $vChecked='checked';
                $_SESSION["webpath"] = '1';
              }

               ?>
              <input type="checkbox" <?php echo $vChecked ?>>
              <span class="slider switch_dashboard round"></span>
            </label>
            <span class="text-white px-2 ml-3" style="font-size: 18px;font-weight: 900;color:#f4de06 !important">ETHBULL X3 / X6</span>
          </li>
          <!--li class="nav-item pl-5 navbar" >
            <div class="dropdown">
              <button class="dropbtn">Dashboard</button>
              <div class="dropdown-content">
                <a href="<?php echo SITE_URL.'dashboard/';?>">Ethbull.io</a>
                <a href="<?php echo SITE_URL.'dashboard/?s_dashboard';?>">Forsage.io</a>
              </div>
            </div>
          </li>
		   <li class="nav-item px-1" style="float: right;">
          </li-->
		   <li class="nav-item pl-5" style="float: right;">
            <a class="nav-link"  href="#" aria-expanded="false" data-animation="fade" role="button"><i class="icon fa-user-circle-o font-size-22" aria-hidden="true"> </i>  USER ID: <?php echo $userID; ?> </a>
          </li>
		</div>
		<div class="navbar-right navbar-toolbar-right">
          <li class="nav-item dropdown" style="display: none;">
            <a class="nav-link" data-toggle="dropdown" href="javascript:void(0)" data-animation="scale-up"
              aria-expanded="false" role="button">
	     <script>
			var c = document.cookie.split(';');
			if(c[0] === 'country=ru'){
			    document.write('<span class="flag-icon flag-icon-ru"></span>');
			}else{
			    document.write('<span class="flag-icon flag-icon-us"></span>');
			}
              </script>
            </a>
            <div class="dropdown-menu" role="menu">
              <a class="dropdown-item" onClick="document.cookie='country=en';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-us"></span> English</a>
              <a class="dropdown-item"
              onClick="document.cookie='country=ru';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-ru"></span> Russian</a>
              <!--
              <a class="dropdown-item" onClick="document.cookie='country=fr';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-fr"></span> French</a>
              <a class="dropdown-item" onClick="document.cookie='country=cn';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-cn"></span> Chinese</a>
              <a class="dropdown-item" onClick="document.cookie='country=de';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-de"></span> German</a>
              <a class="dropdown-item" onClick="document.cookie='country=nl';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-nl"></span> Dutch</a>
              -->
            </div>
          </li>
          <li class="nav-item dropdown" style="display: none;">
            <a class="nav-link" data-toggle="dropdown" href="javascript:void(0)" title="Notifications"
              aria-expanded="false" data-animation="scale-up" role="button">
                <i class="icon md-notifications" aria-hidden="true"></i>
                <span class="badge badge-pill badge-danger up">5</span>
              </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-media" role="menu">
              <div class="dropdown-menu-header">
                <h5>NOTIFICATIONS</h5>
                <span class="badge badge-round badge-danger">New 5</span>
              </div>

              <div class="list-group">
                <div data-role="container">
                  <div data-role="content">
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-receipt bg-red-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">A new order has been placed</h6>
                          <time class="media-meta" datetime="2017-06-12T20:50:48+08:00">5 hours ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-account bg-green-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Completed the task</h6>
                          <time class="media-meta" datetime="2017-06-11T18:29:20+08:00">2 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-settings bg-red-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Settings updated</h6>
                          <time class="media-meta" datetime="2017-06-11T14:05:00+08:00">2 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-calendar bg-blue-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Event started</h6>
                          <time class="media-meta" datetime="2017-06-10T13:50:18+08:00">3 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-comment bg-orange-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Message received</h6>
                          <time class="media-meta" datetime="2017-06-10T12:34:48+08:00">3 days ago</time>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div class="dropdown-menu-footer">
                <a class="dropdown-menu-footer-btn" href="javascript:void(0)" role="button">
                    <i class="icon md-settings" aria-hidden="true"></i>
                  </a>
                <a class="dropdown-item" href="javascript:void(0)" role="menuitem">
                    All notifications
                  </a>
              </div>
            </div>
          </li>
		  </div>
        </ul>
        <!-- End Navbar Toolbar Right -->
      </div>
      <!-- End Navbar Collapse -->
