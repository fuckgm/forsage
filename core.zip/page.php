<?php

$page = "Page";?><!DOCTYPE html>
<html class="no-js css-menubar" lang="en">

<!-- Mirrored from getbootstrapadmin.com/remark/material/iconbar/tables/datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Feb 2020 16:11:44 GMT -->
<head>
<?php
  require_once('lang.php');
  if(isset($_COOKIE['country']) && $_COOKIE['country'] != ""){
    $lang = "language_".$_COOKIE['country'];
  }else{
    $lang = "language_en";
  }


//-- switch forsage dashboard or ethbull -----
$forsage_url = SITE_URL.'dashboard/?s_dashboard';
$ethbull_url = SITE_URL.'dashboard/';
$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

if($forsage_url==$url){
$_SESSION["webpath"] = '1';
}else{
$_SESSION["webpath"] = '2';
}
//--------end code----------------------------
?>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap material admin template">
  <meta name="author" content="">

  <title> <?php echo $page; ?> | Ethbull.io</title>

  <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
  <link rel="shortcut icon" href="assets/images/favicon.png">
  <!-- Stylesheets -->
  
  <link rel="stylesheet" href="global/css/bootstrap.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/css/bootstrap-extend.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="assets/css/site.minfd53.css?<?php echo time() ?>">



  <!-- Plugins -->
  <link rel="stylesheet" href="global/vendor/animsition/animsition.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/asscrollable/asScrollable.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/switchery/switchery.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/intro-js/introjs.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/slidepanel/slidePanel.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/flag-icon-css/flag-icon.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/waves/waves.minfd53.css?v4.0.1">

  <!-- Plugins For This Page -->
  <link rel="stylesheet" href="assets/examples/css/dashboard/v1.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-bs4/dataTables.bootstrap4.minfd53.css?v4.0.1">
 <link rel="stylesheet" href="global/vendor/datatables.net-select-bs4/dataTables.select.bootstrap4.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-responsive-bs4/dataTables.responsive.bootstrap4.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/datatables.net-buttons-bs4/dataTables.buttons.bootstrap4.minfd53.css?v4.0.1">
  <!-- Page -->
  <link rel="stylesheet" href="assets/examples/css/tables/datatable.minfd53.css?v4.0.1">
  <!-- Fonts -->
  <link rel="stylesheet" href="global/fonts/material-design/material-design.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/fonts/brand-icons/brand-icons.minfd53.css?v4.0.1">
  <link rel='stylesheet' href="https://fonts.googleapis.com/css?family=Roboto:400,400italic,700">
  <link rel="stylesheet" href="global/fonts/font-awesome/font-awesome.minfd53.css?v4.0.1">
  <script src="https://kit.fontawesome.com/ee18e7efa7.js" crossorigin="anonymous"></script>

  <!--[if lt IE 9]>
    <script src="../../global/vendor/html5shiv/html5shiv.min.js?v4.0.1"></script>
    <![endif]-->

  <!--[if lt IE 10]>
    <script src="../../global/vendor/media-match/media.match.min.js?v4.0.1"></script>
    <script src="../../global/vendor/respond/respond.min.js?v4.0.1"></script>
    <![endif]-->

  <!-- Scripts -->
  <script src="global/vendor/breakpoints/breakpoints.minfd53.js?v4.0.1"></script>
  <script>
    Breakpoints();
  </script>
 <style>
.dropbtn {
  background-color: #000;
  color: white;
  /*padding: 16px;*/
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #000;}

/*toggle buttons*/

.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}

/*.night{
  background-color: red!important;
}*/
</style>
<style type="text/css">
    .language-block {	position: fixed;	right: 0px;	top: 60px;	z-index: 111;	display: none;}	.language-block:hover .lang-list {	width: 160px;	padding: 10px 15px;	font-size: 14px;	background-color: #fff;	box-shadow: -3px 2px 5px rgba(117, 105, 105, 0.6);	}	.lang-list {	width: 0;	overflow: hidden;	transition: 0.5s;	}
</style>

</head>
<body class="animsition ">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->

  <nav class="site-navbar navbar navbar-default navbar-inverse navbar-fixed-top navbar-mega"
    role="navigation">

    <div class="navbar-header">
      <button type="button" class="navbar-toggler hamburger hamburger-close navbar-toggler-left hided"
        data-toggle="menubar">
        <span class="sr-only">Toggle navigation</span>
        <span class="hamburger-bar"></span>
      </button>
      <button type="button" class="navbar-toggler collapsed" data-target="#site-navbar-collapse"
        data-toggle="collapse">
        <i class="icon md-more" aria-hidden="true"></i>
      </button>
      <div class="navbar-brand navbar-brand-center">
        <!--img class="navbar-brand-logo" src="assets_s/Decentralized/img/logo-03.svg"-->
        <img class="navbar-brand-logo" src="assets/images/logo.png">
      </div>

    </div>

    <div class="navbar-container container-fluid">
      <!-- Navbar Collapse -->
      <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
        <!-- Navbar Toolbar -->
        <ul class="nav col-xl-6 col-lg-6 col-md-2 navbar-toolbar">
          <li class="nav-item hidden-float" id="toggleMenubar">
            <a class="nav-link" data-toggle="menubar" href="#" role="button">
                <i class="icon hamburger hamburger-arrow-left">
                  <span class="sr-only">Toggle menubar</span>
                  <span class="hamburger-bar"></span>
                </i>
              </a>
          </li>
		  <div class=" text-center">
		  <li class="nav-item hide-add">
            <a class="nav-link px-0"  href="https://etherscan.io/address/<?php echo $userWallet; ?>" target="_blank" aria-expanded="false" data-animation="fade" role="button"><i class="fab fa-ethereum"></i> ETH Address: <?php echo $userWallet; ?> <i class="icon fa-external-link-square" aria-hidden="true" target="new"></i></a>
          </li>
		  </div>


        </ul>
        <!-- End Navbar Toolbar -->
        <!-- Navbar Toolbar Right -->
        <ul class="nav col-xl-6 col-lg-6 col-md-10 navbar-toolbar px-2 ">
    		<div class="" style="width:100%">
    		  <li class="nav-item px-1 navbar" >
            <span class="text-white px-2 mr-3" style="font-size: 18px;font-weight: 900;color:#f4de06 !important">ETHBULL</span>
            <label class="switch mb-0">
              <?php
			  //error_reporting(0);
$e=explode("/?",$url);
$k=explode("/",$e[1]); $j=explode("=",$e[1]);
			  if($k[0]=='page' || $j[0]=='user' || $k[0]=='pagex6'){
				$vChecked='checked';
                $_SESSION["webpath"] = '1';  
			  }

               ?>
              <input type="checkbox" <?php echo $vChecked ?>>
              <span class="slider switch_dashboard round"></span>
            </label>
            <span class="text-white px-2 ml-3" style="font-size: 18px;font-weight: 900;color:#f4de06 !important">ETHBULL X3 / X6</span>
          </li>
          <!--li class="nav-item pl-5 navbar" >
            <div class="dropdown">
              <button class="dropbtn">Dashboard</button>
              <div class="dropdown-content">
                <a href="<?php echo SITE_URL.'dashboard/';?>">Ethbull.io</a>
                <a href="<?php echo SITE_URL.'dashboard/?s_dashboard';?>">Forsage.io</a>
              </div>
            </div>
          </li>
		   <li class="nav-item px-1" style="float: right;">
          </li-->
		   <li class="nav-item pl-5" style="float: right;">
            <a class="nav-link"  href="#" aria-expanded="false" data-animation="fade" role="button"><i class="icon fa-user-circle-o font-size-22" aria-hidden="true"> </i>  USER ID: <?php echo $userID; ?> </a>
          </li>
		</div>
		<div class="navbar-right navbar-toolbar-right">
          <li class="nav-item dropdown" style="display: none;">
            <a class="nav-link" data-toggle="dropdown" href="javascript:void(0)" data-animation="scale-up"
              aria-expanded="false" role="button">
	     <script>
			var c = document.cookie.split(';');
			if(c[0] === 'country=ru'){
			    document.write('<span class="flag-icon flag-icon-ru"></span>');
			}else{
			    document.write('<span class="flag-icon flag-icon-us"></span>');
			}
              </script>
            </a>
            <div class="dropdown-menu" role="menu">
              <a class="dropdown-item" onClick="document.cookie='country=en';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-us"></span> English</a>
              <a class="dropdown-item"
              onClick="document.cookie='country=ru';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-ru"></span> Russian</a>
              <!--
              <a class="dropdown-item" onClick="document.cookie='country=fr';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-fr"></span> French</a>
              <a class="dropdown-item" onClick="document.cookie='country=cn';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-cn"></span> Chinese</a>
              <a class="dropdown-item" onClick="document.cookie='country=de';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-de"></span> German</a>
              <a class="dropdown-item" onClick="document.cookie='country=nl';location.reload();" role="menuitem">
                <span class="flag-icon flag-icon-nl"></span> Dutch</a>
              -->
            </div>
          </li>
          <li class="nav-item dropdown" style="display: none;">
            <a class="nav-link" data-toggle="dropdown" href="javascript:void(0)" title="Notifications"
              aria-expanded="false" data-animation="scale-up" role="button">
                <i class="icon md-notifications" aria-hidden="true"></i>
                <span class="badge badge-pill badge-danger up">5</span>
              </a>
            <div class="dropdown-menu dropdown-menu-right dropdown-menu-media" role="menu">
              <div class="dropdown-menu-header">
                <h5>NOTIFICATIONS</h5>
                <span class="badge badge-round badge-danger">New 5</span>
              </div>

              <div class="list-group">
                <div data-role="container">
                  <div data-role="content">
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-receipt bg-red-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">A new order has been placed</h6>
                          <time class="media-meta" datetime="2017-06-12T20:50:48+08:00">5 hours ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-account bg-green-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Completed the task</h6>
                          <time class="media-meta" datetime="2017-06-11T18:29:20+08:00">2 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-settings bg-red-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Settings updated</h6>
                          <time class="media-meta" datetime="2017-06-11T14:05:00+08:00">2 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-calendar bg-blue-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Event started</h6>
                          <time class="media-meta" datetime="2017-06-10T13:50:18+08:00">3 days ago</time>
                        </div>
                      </div>
                    </a>
                    <a class="list-group-item dropdown-item" href="javascript:void(0)" role="menuitem">
                      <div class="media">
                        <div class="pr-10">
                          <i class="icon md-comment bg-orange-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">Message received</h6>
                          <time class="media-meta" datetime="2017-06-10T12:34:48+08:00">3 days ago</time>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div class="dropdown-menu-footer">
                <a class="dropdown-menu-footer-btn" href="javascript:void(0)" role="button">
                    <i class="icon md-settings" aria-hidden="true"></i>
                  </a>
                <a class="dropdown-item" href="javascript:void(0)" role="menuitem">
                    All notifications
                  </a>
              </div>
            </div>
          </li>
		  </div>
        </ul>
        <!-- End Navbar Toolbar Right -->
      </div>
      <!-- End Navbar Collapse -->

<?php

//include('top_navbar.php');
 include('sidebar.php');
include('s_top_navbar.php');
include('core/dashboard_curl.php');

include('core/plan_code.php');
//$userID=$useri
   
?>


<div class="row">
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
//error_reporting(0);

$page = "X3";

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$e = explode("/?", $url);
$txn = '';
if (isset($e[1])) {
   $k = explode("/", $e[1]);

   if (!empty($k)) {
      $plan = $k[1];
      $level = $k[2];
      $userid = $k[3];

      if (!empty($k[4])) {
         $txn = $k[4];
      }

      if($userid != ''){
        $userID = $userid;
      }

   } else {
      $plan = '';
      $level = '';
      $userid = '';
      $txn = '';
   }
}

if($txn!='') {
   $loginuserID = $userid;
} else {
   $loginuserID = $userID;
}

$u = 12;
if($level != 1) {
   $u = $level-1;
} else {
   $u='12';
}

$v = 1;
if($level != 12) {
   $v = $level+1;
}

//Toal partners - all levels
$globalLevelSum = 0;
$globalReinvestSum = 0;
$globalGetAllMembers = [];
$level_Array = fetchDownlinesData($userID, $conn, $level);

$level_position_fill = ($level_Array['globalLevelSum'] % 3);
$level_member_count = $level_Array['globalLevelSum'];
$level_reinvest_count = $level_Array['globalReinvestSum'];
$level_amount_sum = $level_Array['globalAmountSum'];
$level_all_members = $level_Array['globalGetAllMembers'];
if(!empty($level_all_members)){
   sort($level_all_members);
}

$query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='" . $level . "' ";

 $result = mysqli_query($conn, $query);
 $first_level_count = mysqli_num_rows($result);
 
$get_user_ids = [];
if ($first_level_count > 0) {
   while ($fl_row = mysqli_fetch_assoc($result)) {
      $get_user_ids[] = $fl_row['userID'];
   }
}


$level_amount_sum_eth = $level_amount_sum;
$level_amount_sum_dollar = ($level_amount_sum * $ethPrice);
?>
   

<style>
.matrix-children__overflow{
	background-color: #007bff !important;
}
.matrix-children__nonactive {
    background-color: transparent;
    border: 1px solid #007bff;
    box-shadow: inset 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__active {
    background-color: lightblue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__overflow {
    background-color: whiteblue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__overflow_partner {
    background-color: blue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__advance {
    background-color: lilac;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.pagebox {
    border: 2px solid #007bff;
    width: 91%;
    margin: 6px;
    border-radius: 5px;
    padding: 6px;
    color: black;
}
.pageboxblank {
    border: 2px solid #007bff;
    margin: 6px;
    padding: 18px 29px;
    border-radius: 5px;
	color:black;
}
.totalern {
    border: 2px solid black;
    color: black;
    border-radius: 7px;
}
h2.levelxpre {
    width: 9%;
    border: 2px solid #ff6cc5;
    padding: 1px;
    text-align: center;
    border-radius: 5px;
}

h2.levelnxt {
    border: 2px solid #ff6cc5;
    text-align: center;
    width: 9%;
	 padding: 1px;
    border-radius: 5px;
    float: right;
    margin-top: -6%;
}
</style>
  <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <div id="x3main" class="logotypeX3">
                    <!-- <img src="assets_s/Decentralized/img/x3.svg" alt=""> -->
                    <h1>ETH BULL <?php echo $plan;?></h1>
					<h2 class="levelxpre"><?php if($level != 1){  $u=$level-1; }else{ $u='12';} ?><a href="<?php echo SITE_URL.'dashboard/?page/x3/'.$u.'/'.$loginuserID;?>"><?php echo $u;?></a></h2>
					
					<h2 class="levelnxt"><?php if($level != 12) { $v=$level+1;} ;  ?>
					<a href="<?php echo SITE_URL.'dashboard/?page/x3/'.$v.'/'.$loginuserID;?>"><?php echo $v;?></a></h2>
                </div>
                <div class="ternary-wrapper">

				
                                        <div class="ternary"> 
								 <div class="user_id">
                        <?php //echo $userID;die;
						$txn='';
                           if($txn != ''){
                              
                              echo '<a href="'.SITE_URL.'dashboard?user='.$userID.'">';
                              echo '<i class="fa fa-arrow-up"></i>';
                              echo ' ID <span>' . $userID . '</span>';
                              echo '</a>';

                           } else {

                              $query = "SELECT * FROM forsage_event_reglevel where userID='".clean($userID)."' limit 1 ";
                              $result = mysqli_query($conn,$query);
                              $row = mysqli_num_rows($result);
                              $res= mysqli_fetch_array($result);
                              $referrerID = $res['referrerID'];

                              if($referrerID != '0'){

                                 echo '<a href="'.SITE_URL.'dashboard?user='.$referrerID.'">';
                                 echo '<i class="fa fa-arrow-up"></i>';
                                 echo ' ID <span>' . $referrerID . '</span>';
                                 echo '</a>';

                              } else {
                                 echo '<a href="javascript:;">';
                                 echo '&nbsp;';
                                 echo '</a>';
                              }
                           }
                        ?>
                        </span>
                        </a>
                     </div>


                     <div class="user-matrix_ternary">
                        <div class="user-matrix_root user-matrix_root__active">
                           <div class="user-matrix__active">
                              <div class="user-matrix_level" title="Platform">
                                 <?php echo $level;?>
                              </div>
                              <div class="user-matrix_id">
                                 <a href="<?php echo SITE_URL; ?>dashboard/?user=<?php echo $userID; ?>" class="trigger_value__user-id">
                                    ID 
                                    <span>
                                       <?php if($txn!=''){ echo $userid; } else { echo $userID; } ?>
                                    </span>
                                 </a>
                              </div>
                              <div class="user-matrix_price">
                                 <div class="user-matrix_price__dollars">
                                    $<?php echo number_format($level_amount_sum_dollar, 2);?><br>
                                 </div>
                                 <div class="user-matrix_price__eth">
                                    <?php echo number_format($level_amount_sum_eth, 2);?>
                                 </div>
                              </div>
                           </div>
                           <div class="user-matrix__nonactive">
                              <div class="user-matrix_level" title="Platform">
                                 1 
                              </div>
                              <div class="user-matrix_cart" data-matrix="1" data-level="1" data-matrix_price="0.025">
                                 <img src="<?php echo $siteURL; ?>img/cartbig.svg" alt="">
                              </div>
                              <div class="user-matrix_price">
                                 0.025 
                              </div>
                           </div>
                           <div class="user-matrix_reinvest" title="Реинвест уровня">
                              <span class="user-matrix_reinvest__nav">
                              <a href="?reinvest=0" class="user-matrix_reinvest__nav-next" title="A higher level">
                              <i class="fa fa-chevron-up"></i>
                              </a>
                              <a href="?reinvest=329" class="user-matrix_reinvest__nav-prev" title="Lower level">
                              <i class="fa fa-chevron-down"></i>
                              </a>
                              </span>
                              <span data-spoiler=".user-matrix_reinvest__popup">
                              <span class="user-matrix_reinvest__tip">
                              HISTORY <i class="fas fa-database"></i>
                              </span>

                              <i class="matrix-icon_sync"></i> <?php echo $level_reinvest_count; ?></span>
                              <div class="user-matrix_reinvest__popup">
                                 <select name="" id="changeCurrentReinvest" class="form-control" style="">
                                    <?php if($level_reinvest_count > 0){
                                       for ($ri=1; $ri <= $level_reinvest_count; $ri++) { 
                                          if($ri == $level_reinvest_count){
                                             $selected = 'selected="selected"';
                                          } else {
                                             $selected = '';
                                          }
                                          echo '<option '.$selected.' value="'.$ri.'"> '.$ri.' </option>';
                                       }
                                    }
                                    ?>
                                 </select>
                              </div>
                           </div><?php
														   
								 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$loginuserID."' and l.plan='".$plan."' and level='".$level."' order by l.id DESC";
								$result = mysqli_query($conn,$query);
																																																				
								$row = mysqli_num_rows($result);
						   ?>
                           <div class="user-matrix_partners" title="Партнеров на уровне">
                              <a><i class="matrix-icon_users"></i> <?php echo $row ; ?></a>
                              <a href="javascript:;" class="user-profit__gift" title="Number of transactions: 0">
                              <i class="fas fa-gift" title="Gift transactions"></i>
                              0.275 </a>
                           </div>
                        </div>
                        <div class="user-matrix__branchs">
                           <div></div>
                           <div></div>
                           <div></div>
                        </div>
                        <div class="user-matrix_children">

                           <?php
                           
                           $remain_last_users = 3;
                           if(count($get_user_ids) > 0){

                              $remain_last_users = ($remain_last_users - count($get_user_ids));
                              foreach ($get_user_ids as $key => $last_user_id) {


                                 $globalLevelSum = 0;
                                 $globalReinvestSum = 0;
                                 $globalGetAllMembers = [];
                                 $level_Array = fetchDownlinesData($last_user_id, $conn, $level);

                                 $level_position_fill = ($level_Array['globalLevelSum'] % 3);
                                 $level_member_count = $level_Array['globalLevelSum'];
                                 $level_reinvest_count = $level_Array['globalReinvestSum'];
                                 $level_amount_sum = $level_Array['globalAmountSum'];
                                 $level_all_members = $level_Array['globalGetAllMembers'];
								 $tx = "0xd03ee99f4b3363bb0a396310ce56ae16aa8d1672";
                                 //user-matrix_wrapper_popup matrix-children__overflow
                                 ?>
                                 <div class="user-matrix_wrapper_popup matrix-children__active matrix-children__overflow" title="">
									 <a href="<?php echo SITE_URL.'dashboard/?page/x3/'.$level.'/'.$last_user_id.'/tx=0xd03ee99f4b3363bb0a396310ce56ae16aa8d1672'; ?>">
                                       <span class="user-matrix_children_count">
                                          <?php echo $last_user_id; ?>
                                       </span>
                                    </a>
                                    
                                    <span class="user-matrix_partners__count">
                                       <i class="matrix-icon_users"></i>
                                       <span><?php echo count($level_all_members); ?></span>
                                    </span>
                                    <span class="user-matrix_popup">
                                       <span>
                                          <i class="matrix-icon_users"></i>
                                          <span><?php echo count($level_all_members); ?></span>
                                       </span>
                                       <span>
                                          <i class="matrix-icon_sync"></i>
                                          <span><?php echo $level_reinvest_count; ?></span>
                                       </span>
                                    </span>
                                 </div>
                              <?php
                              } 
                           }

                           if($remain_last_users > 0){
                              for ($i=0; $i < $remain_last_users ; $i++) { 
                                 ?>
                                 <div class="user-matrix_wrapper_popup matrix-children__nonactive " title="">
                                    <span class="user-matrix_children_count"></span>
                                    <span class="user-matrix_partners__count">
                                       <i class="matrix-icon_users"></i>
                                       <span>0</span>
                                    </span>
                                    <span class="user-matrix_popup">
                                       <span>
                                          <i class="matrix-icon_users"></i>
                                          <span>0</span>
                                       </span>
                                       <span>
                                          <i class="matrix-icon_sync"></i>
                                          <span>0</span>
                                       </span>
                                    </span>
                                 </div>
                                 <?php
                              }
                           }
                        ?>
                        </div>
                     </div>
 </div>
								   </div><!-- end: ternary-wrapper -->
            </div><!-- end: border-gradient_content -->
        </div><!-- end: border-gradient -->
    </div><!-- end: col -->
</div><!-- end: row -->

<div class="row my-4">
    <div class="col">
        <div class="icon-tips">
            <div class="matrix_currency">
                <strong style="color:#000000;font-weight: bold">eth</strong> <span>THE COST OF SLOTS IN ETH (ETHEREUM)</span>
            </div>
            <div class="matrix_reinvest">
                <i class="matrix-icon_sync"></i> <span>NUMBER OF REINVESTS</span>
            </div>
            <div class="matrix_partners__count">
                <i class="matrix-icon_users"></i> <span>PARTNERS ON THE SLOT</span>
            </div>
        </div>
    </div>
</div>


<div class="border-gradient">
	<div class="border-gradient_content">
               <div class="mycls table-responsive" id="myid">
                  <table class="tablePartners table-hover table-striped table tablePartners" id="example">
                     <thead>
                        <tr>
                           <td style="">
                              <a>
Date                                                                           </a>
                           </td>
                           <td style="">
                              <a >
                              Id                                                                            </a>
                           </td>
                           <td style="">
                              Wallet Address
                           </td>
                           <td style="">
                              <a >
                              Eth/$                                                                            </a>
                           </td>
						  
                        </tr>
                     </thead>
                     <tbody>

<?php

//echo $loginuserID;




 $query = "SELECT * FROM forsage_event_reglevel where userID='".clean($loginuserID)."' limit 1 ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$res= mysqli_fetch_array($result);
 $usWallet = $res['userWallet'];

$query = "SELECT * FROM forsage_event_paidforlevel where referrer='".clean($usWallet)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
//echo $ethPrice;;die;
if($row != NULL && $row > 0){
$row1 = $result -> fetch_all();

	foreach($row1 as $row2) {

		//find user id of this user
		$query = "SELECT * FROM forsage_event_reglevel where userWallet='".$row2[1]."' ";
		$result = mysqli_query($conn,$query);
		$referralID = $result -> fetch_assoc();

$levelProfit_x3 = $row2[4] / 1000000000000000000;
$doller=number_format((float)($levelProfit_x3*$ethPrice), 2, '.', ''); 
echo '
							<tr role="row" class="odd">
								<td>'.date('m/d/Y', $row2[5]).'</td>
								<td>'.$referralID['userID'].'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row2[1].'" target="new"> '.$row2[1].' </a>
								</td>
								<td>'.($row2[4] / 1000000000000000000).' eth / $'.$doller.'</td>
								
								
								
								
							</tr>
';
}
}


?>							

  </tbody>
                  </table>
                  <div class="pagination_wrapper">
                  </div>
               </div>
              
	</div>

</div>

</div>
</div>
</div>


<script>
var config = {
    site: {
        domain:   location.hostname,
        protocol: location.protocol + '//',
        hostname: location.hostname,
        //link: 'https://lk.forsage.io/',
        link: '<?php echo SITE_URL;?>',
        course: {
            value: `ETH_USD`,
            symbol: `$`,
        },
    },
    user: {
        refkey: 'vpat19',
        address: '0x948e5f339942f9f6cf417c5fe6de73ef6059bd8b',
        isAuthSecure: false,
        sid: '2b2fd7148b32c82b6c700573550e5ffe',
    },
    lang: {
        /* contract.js */
        buyLevel                 : `Confirm the purchase`,
        notDetectedWallet        : `The Ethereum wallet is Not detected on your browser.`,
        unblockWallet            : `Unlock the wallet for a transaction`,
        notActiveWallet          : `Ethereum wallet is not active`,
        errorSendingTransaction  : `Error sending transaction: `,
        transactionSend          : `The transaction has been sent! Please wait for confirmation of the network.`,
        confirmTransaction       : `Confirm the transaction in your Ethereum wallet`,
        errorReadSmartContract   : `Read error SmartContract`,
        uplineNotRegistered      : `Your upline is not registered`,
        userNotExists            : `The user is not registered`,
        authError                : `Authorization error`,

        /* common.js */
        copied                   : `Copied`,

        // Сокеты события
        'ws-regLevel_0'          : `Joined ID:{user_id}`,
        'ws-regLevel_1'          : `Joined ID:{user_id}. You are on the right way!`,
        'ws-regLevel_2'          : `Meet the new member ID:{user_id}.`,
        'ws-regLevel_3'          : `New user ID:{user_id}. Welcome to Forsage!`,
        'ws-newUserPlace'        : `ID:{user_id} earned {price_level} {crypto_name} (\${currency_usd}) in the {matrix}`,
        'ws-upgrade'             : `ID:{user_id} buy {level} slot in {matrix} from ID:{ref_id}.`,
        'ws-reinvest'            : `ID:{user_id} was auto-reinvested in slot {level} ({matrix})`,
        'ws-missedEthReceive'    : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}). You must perform the upgrade in ({matrix})`,
        'ws-sentExtraEthDividends':`ID:{user_id} received a bonus {price_level} {crypto_name} (\${currency_usd})`,
        'ws-cannotSendMoneyEvent': `ID:{user_id} error getting translation`,
        'ws-leadingPartner'      : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}) from (ID:{u_id}) for area # {level} ({matrix})`,
        'ws-leadingPartnerToUpline':`ID:{u_id} overtook its parent ID is:{user_id} in the matrix {matrix} with area # {level}`,
        'ws-leadingPlacePurchase': `ID:{user_id} ahead of your inviter (ID:{up_id}) for area # {level} ({matrix})`,

        // Скрипт с выводом даты отсчета времени
        'elt-years_0'            : `year`,
        'elt-years_1'            : `year`,
        'elt-years_2'            : `years`,
        'elt-months_0'           : `a month`,
        'elt-months_1'           : `months`,
        'elt-months_2'           : `months`,
        'elt-days_0'             : `day`,
        'elt-days_1'             : `day`,
        'elt-days_2'             : `days`,
        'elt-hours_0'            : `hour`,
        'elt-hours_1'            : `hours`,
        'elt-hours_2'            : `hours`,
        'elt-minutes_0'          : `min`,
        'elt-minutes_1'          : `min`,
        'elt-minutes_2'          : `min`,
        'elt-minutes_3'          : `a minute`,
        'elt-seconds_0'          : `second`,
        'elt-seconds_1'          : `seconds`,
        'elt-seconds_2'          : `seconds`,
        'elt-seconds_3'          : `second`,
        'elt-end'                : ` ago`,
        'elt-freshly'            : `just`,
        'elt-deadline'           : `time left`,
        'elt-after'              : `through `,
    },
    locked: {
        buyLevel      : ``,
        authorization : ``,
        registration  : ``,
    },
    permissions: {
        buyLevel      : `0`,
    },
    isFramed: null,
    isMobile: false,
    haveWallet: window.ethereum || window.web3,
};

// Получить основной домен
let arr = config.site.domain.split('.');
if(arr.length > 2) {
    config.site.domain = arr.slice(arr.length - 2).join('.')
}

// Запущен ли сайт в теге iframe
try {
  config.isFramed = window != window.top || document != top.document || self.location != top.location;
} catch (e) {
  config.isFramed = true;
}
</script>
<script src="assets_s/Decentralized/js/jquery.min.js"></script>
<script src="assets_s/Decentralized/js/vue.min.js"></script>
<script src="assets_s/Decentralized/js/socket.io.js"></script>
<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets_s/Decentralized/js/common.js"></script>
<script src="assets_s/Decentralized/js/contract.js"></script>
<script src="assets_s/Decentralized/js/cabinet.js"></script><div class="require-auth">
    Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
    <br>
    <div>
                    <button class="btn btn-success" id="reauth">
                Authorization            </button>
            </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
<script type="text/javascript">

var web3 = new Web3(Web3.givenProvider || "<?=$infuraAPI; ?>");

var arrayABI = <?=$mainContractABI; ?>;

var mainContractAddress = "<?=$mainContractAddress; ?>";

var myAccountAddress = "<?=$userWallet;?>";

if (typeof web3 !== 'undefined'){

var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
    from: myAccountAddress, // default from address
    });






// fetching user level
fetchRemainingTime(myAccountAddress);
async function fetchRemainingTime(myAccountAddress){

    var remainingDay = await myContract.methods.viewTimestampSinceJoined(myAccountAddress).call({from: myAccountAddress});

    for (var i = 0; i < remainingDay.length; i++) {

    var priceOfLevel = await myContract.methods.priceOfLevel(i+1).call({from: myAccountAddress});
    document.getElementById("buyAmountData"+[i]).textContent = (priceOfLevel / 1000000000000000000)+" ETH";

        if(remainingDay[i] > 0){


            //change ribbon color
            document.getElementById("ribbonColor"+[i]).classList.add('ribbon-success');
            document.getElementById("ribbonColor"+[i]).classList.remove('ribbon-danger');


            //change the ribbon name
            document.getElementById("ribbonName"+[i]).textContent="Active";


            //change $ amount color
            document.getElementById("buyAmountData"+[i]).classList.add('text-success');
            document.getElementById("buyAmountData"+[i]).classList.remove('text-danger');
            document.getElementById("buyAmountData"+[i]).classList.remove('pb-30');





            //remaining days
            document.getElementById("remainingDays"+[i]).textContent="Remain Days: "+ (remainingDay[i] / 86400).toFixed(0);

            //button change
            document.getElementById("levelButton"+[i]).classList.add('btn-success');
            document.getElementById("levelButton"+[i]).classList.remove('btn-danger');
            document.getElementById("levelButton"+[i]).textContent="EXTEND 100 DAYS";

        }
    }
}

}   //web3 check




</script>


<script type="text/javascript">
       $('input[type="checkbox"]').click(function(){
          if($(this).prop("checked") == true){
             console.log("true");
             window.location.href='<?php SITE_URL?>dashboard/';
             // $.cookie("togglechecked", "true");
             localStorage.setItem("checkbox", "true");

          }

          else if($(this).prop("checked") == false){
             window.location.href='<?php SITE_URL?>dashboard/?s_dashboard';
             console.log("false");
          }
      });

</script>





</script>

<?php
//include('information_ethbullx3.php');
?>

</body>
</html>
<?php
include('footer.php');
?>
