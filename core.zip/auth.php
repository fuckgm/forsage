<?php
//include('config.php');
?>
<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap material admin template">
  <meta name="author" content="">

  <title>Ethbull Dashboard</title>

  <link rel="apple-touch-icon" href="assets/images/apple-touch-icon.png">
  <link rel="shortcut icon" href="../source_file/favicon.png">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="global/css/bootstrap.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/css/bootstrap-extend.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="assets/css/site.minfd53.css?v4.0.1">

  <!-- Plugins -->
  <link rel="stylesheet" href="global/vendor/animsition/animsition.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/asscrollable/asScrollable.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/switchery/switchery.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/intro-js/introjs.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/slidepanel/slidePanel.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/flag-icon-css/flag-icon.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/vendor/waves/waves.minfd53.css?v4.0.1">

  <!-- Page -->
  <link rel="stylesheet" href="assets/examples/css/pages/login-v3.minfd53.css?v4.0.1">

  <!-- Fonts -->
  <link rel="stylesheet" href="global/fonts/material-design/material-design.minfd53.css?v4.0.1">
  <link rel="stylesheet" href="global/fonts/font-awesome/font-awesome.minfd53.css?v4.0.1">
  <link rel='stylesheet' href="https://fonts.googleapis.com/css?family=Roboto:400,400italic,700">
  <script src="https://kit.fontawesome.com/ee18e7efa7.js" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="assets/css/alertify.min.css">

<style type="text/css">
    .language-block {	position: fixed;	right: 0px;	top: 60px;	z-index: 111;	}	.language-block:hover .lang-list {	width: 160px;	padding: 10px 15px;	font-size: 14px;	background-color: #fff;	box-shadow: -3px 2px 5px rgba(117, 105, 105, 0.6);	}	.lang-list {	width: 0;	overflow: hidden;	transition: 0.5s;	} 
</style>

  <!-- Scripts -->
  <script src="global/vendor/breakpoints/breakpoints.minfd53.js?v4.0.1"></script>
  <script>
    Breakpoints();
  </script>
</head>
<body class="animsition page-login-v3 layout-full">
  <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->


  <!-- Page -->
  <div class="page vertical-align text-center" data-animsition-in="fade-in" data-animsition-out="fade-out">>
    <div class="page-content vertical-align-middle">
  <div class="col-xxl-12 col-sm-12">
  <div class="row">
      <div class="login-panel mb-1">
        <div class="panel-body mx-20">
          <div class="brand">
            <h2 class="brand-text font-size-22">Login</h2>
      <p class="brand-text font-size-14">Automatic login if you have one of the following wallets:</p>
      <div>
      <a href="https://metamask.io/" title="Metamask wallet" target="new"><img class="brand-img wallet mx-1" src="assets/images/metamask.png" alt="Ethbull"></a>
      <a href="https://trustwallet.com/" title="Trust wallet" target="new"><img class="brand-img wallet mx-1" src="assets/images/trust.png" alt="Ethbull"></a>
      
      <a href="https://wallet.coinbase.com/" title="Coinbase wallet" target="new"><img class="brand-img wallet mx-1" src="assets/images/coinbase.png" alt="Ethbull"></a>
      </div>
          </div>
      <div class="mx-20">
      <button type="submit" id="loginAutomaticallyButton" class="btn btn-success btn-block mt-20">Login Automatically</button>
      </div>

      <?php if (isset($errorMsg)) {
        echo'
      <p style="font-size: 15px; color:red; " id="invalidLoginDataMsg">
        <br>
        Unfortunately, this wallet is not an active member of the platform. You can join the program below:


<div class="form-group form-material floating mx-20" data-plugin="formMaterial">
<input type="text"  class="form-control" value="1" id="regReferralID"></input>
<label class="floating-label">Enter Your Referrer ID</label>
<button type="submit" id="regUserButton" class="btn btn-warning btn-block mt-20">Join Ethbull <span id="approvingLoader" style="display:none;">  Approving <img src="assets/images/loader.gif" /></span></button>
</div>

This can be done manually by creating a transaction with the following parameters:
<br>
The address of the Recipient: 
<br>
Amount of transfer: 0.03 ETH
<br>
Limit gas: 400.000
      </p>
       <script>
       //fetching referral details from local storage if exist
      if(!(localStorage.getItem("referrerID") === null || localStorage.getItem("referrerID") === "undefined" || localStorage.getItem("referrerID") == "")){
        document.getElementById("regReferralID").value = localStorage.getItem("referrerID");
      }


         document.cookie.split(";").forEach(function(c) { document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); });
           window.location="#";
     </script>
      ';
    }
      ?>
      <br><br>
      <p class="brand-text font-size-14"><b>Or you can enter manually, Your ether address or User ID</b></p>

            <div class="form-group form-material floating mx-20" data-plugin="formMaterial">
              <input id="manualEntryInput" type="text" class="form-control"  />
              <label class="floating-label">Enter User ID or Ether Address</label>
      
      <p style="font-size: 15px;color:red;" id="manualErrorMsg"></p>
      
            <button id="manualEntryButton"  class="btn btn-primary btn-block mt-10 mb-50">Login Manually</button>
      
            </div>
        
          
        </div>
       </div>
    
    
    <div class="login-panel bg-blue-grey-800 mb-1">
    <div class="panel-body mx-20">
    
    <div class="mx-20 pt-20">
    <img class="brand-img login-logo " src="../source_file/ethbull-logo.png" alt="...">
      <p class="brand-text font-size-14 grey-200">Please watch following video on How to Join Ethbull</p>
    <p class="brand-text font-size-14 grey-200" ><a  style="color:#95a2ff" href="https://www.youtube.com/watch?v=UUwCvLM3gPY" target="_blank">Desktop: Using Metamask</a></p>
    <p class="brand-text font-size-14 grey-200" ><a  style="color:#95a2ff" href="https://www.youtube.com/watch?v=2tRu2UgU5uI" target="_blank">Mobile: Using Trust Wallet</a></p>
      </div>
    
    
          <div class="brand">
            <br>
            <h2 class="brand-text font-size-14 white">Follow us on social networks</h2>
      <a type="button" class="btn btn-icon social-facebook waves-effect waves-classic mx-1" href="https://www.facebook.com/Ethbull-103673021328767/" target="_blank"><i class="icon fa-facebook" aria-hidden="true"></i></a>
      <a type="button" class="btn btn-icon social-twitter waves-effect waves-classic mx-1" target="_blank" href="https://twitter.com/EthbullOfficial"><i class="icon fa-twitter" aria-hidden="true"></i></a>
      <a type="button" class="btn btn-icon social-github waves-effect waves-classic mx-1" target="_blank" href="https://t.me/Ethbull_official"><i class="icon fa-paper-plane" aria-hidden="true"></i></a>
      <a type="button" class="btn btn-icon social-youtube waves-effect waves-classic mx-1 " target="_blank" href="https://www.youtube.com/channel/UCp6vR7UiXRzb-46lQqmvxpg"><i class="icon fa-youtube-play" aria-hidden="true"></i></a>
      
          </div>
      
      <div class="mx-40 pt-20 white">
      <p class="brand-text font-size-14">Ethbull smart-contract:</p>
      <p class="brand-text font-size-14 mb-1"><i class="fab fa-ethereum"></i> ETH Address:</p>
      </div>
    
      <a href="https://etherscan.io/address/<?=$mainContractAddress; ?>" target="_blank" class="white font-size-12">
      <?=$mainContractAddress; ?> <i class="icon fa-external-link-square" aria-hidden="true" target="new"></i></a>
     
        </div>
    
    
      </div>
      </div>
      </div>
      </div>
      <footer class="page-copyright page-copyright-inverse mt-0 mb-40">
        <p>© 2020. All RIGHT RESERVED <i class="red-600 icon md-favorite"></i> by EthBull</p>
      </footer>
    </div>
  </div>
  <!-- End Page -->


  <!-- Core  -->
  <script src="global/vendor/babel-external-helpers/babel-external-helpersfd53.js?v4.0.1"></script>
  <script src="global/vendor/jquery/jquery.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/popper-js/umd/popper.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/bootstrap/bootstrap.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/animsition/animsition.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/mousewheel/jquery.mousewheel.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/asscrollbar/jquery-asScrollbar.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/asscrollable/jquery-asScrollable.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/ashoverscroll/jquery-asHoverScroll.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/waves/waves.minfd53.js?v4.0.1"></script>

  <!-- Plugins -->
  <script src="global/vendor/switchery/switchery.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/intro-js/intro.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/screenfull/screenfull.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/slidepanel/jquery-slidePanel.minfd53.js?v4.0.1"></script>

  <!-- Plugins For This Page -->
  <script src="global/vendor/jquery-placeholder/jquery.placeholder.minfd53.js?v4.0.1"></script>

  <!-- Scripts -->
  <script src="global/js/State.minfd53.js?v4.0.1"></script>
  <script src="global/js/Component.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin.minfd53.js?v4.0.1"></script>
  <script src="global/js/Base.minfd53.js?v4.0.1"></script>
  <script src="global/js/Config.minfd53.js?v4.0.1"></script>

  <script src="assets/js/Section/Menubar.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Section/Sidebar.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Section/PageAside.minfd53.js?v4.0.1"></script>
  <script src="assets/js/Plugin/menu.minfd53.js?v4.0.1"></script>

  <!-- Config -->
  <script src="global/js/config/colors.minfd53.js?v4.0.1"></script>
  <script src="assets/js/config/tour.minfd53.js?v4.0.1"></script>
  <script>
    Config.set('assets', '../assets');
  </script>

  <!-- Page -->
  <script src="assets/js/Site.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/asscrollable.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/slidepanel.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/switchery.minfd53.js?v4.0.1"></script>

  <script src="global/js/Plugin/jquery-placeholder.minfd53.js?v4.0.1"></script>
  <script src="global/js/Plugin/material.minfd53.js?v4.0.1"></script>

  <script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
  <script src="assets/js/alertify.min.js" type="text/javascript"></script>

<script>

window.addEventListener('load', async () => {
$(document).ready(function(){


  $("#loginAutomaticallyButton").click(async function(){
      
      // Modern dapp browsers...
    if (window.ethereum) {
        window.web3 = new Web3(ethereum);
        try {
            // Request account access if needed
            await ethereum.enable();
            // Acccounts now exposed
            web3.eth.getAccounts(function(error, result) {
          if(!error && typeof(result[0]) !== 'undefined')
              {
              var metaMaskAddress=""+result[0];
              var now = new Date();
              now.setTime(now.getTime() + 1 * 3600 * 1000);
              document.cookie = "userWallet="+metaMaskAddress+"; expires=" + now.toUTCString() + "; path=/";
              
              window.location.href = "<?php echo SITE_URL.'dashboard'; ?>";
            }
          });
        } catch (error) {
            // User denied account access...
        }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
        window.web3 = new Web3(web3.currentProvider);
        // Acccounts always exposed
        web3.eth.getAccounts(function(error, result) {
          if(!error && typeof(result[0]) !== 'undefined')
          {
          var metaMaskAddress=""+result[0];
          var now = new Date();
          now.setTime(now.getTime() + 1 * 3600 * 1000);
          document.cookie = "userWallet="+metaMaskAddress+"; expires=" + now.toUTCString() + "; path=/";
          
          window.location.href = "<?php echo SITE_URL.'dashboard';?>";
        }
      });
        
    }
    // Non-dapp browsers...
    else {

        console.log('Non-Ethereum browser detected. You should consider trying MetaMask!');
    }
  });

  $("#manualEntryButton").click(function(){
      
      var str = $("#manualEntryInput"). val();
      str = str.replace(/\s/g,'');    //removing spaces

      if (typeof str !== 'undefined' && str != '') {
        //now chekcing if it is user ID, which should be 10 digit long and should be only numbers
        if(str.match(/^[0-9]+$/) != null){

          var now = new Date();
          now.setTime(now.getTime() + 1 * 3600 * 1000);
          document.cookie = "userID="+str+"; expires=" + now.toUTCString() + "; path=/";
          window.location.href = "<?php echo SITE_URL.'dashboard';?>";

        }
        else if(str.length == 42){
          var now = new Date();
          now.setTime(now.getTime() + 1 * 3600 * 1000);
          document.cookie = "userWallet="+str+"; expires=" + now.toUTCString() + "; path=/";
          window.location.href = "<?php echo SITE_URL.'dashboard';?>";
        }
        else{
          $('#manualErrorMsg').text('Invalid User ID or Wallet Address');
        }

      }
      else{
        
        $('#manualErrorMsg').text('Enter User ID or Wallet Address');
      }
  });







});
});





window.addEventListener('load', async () => {
$(document).ready(function(){

$("#regUserButton").click(async function(){


// Modern dapp browsers...
    if (window.ethereum) {

        window.web3 = new Web3(ethereum);
        try {
            // Request account access if needed
            await ethereum.enable();
            // Acccounts now exposed
            web3.eth.getAccounts( function(error, result) {
          if(!error && typeof(result[0]) !== 'undefined')
              {
              var myAccountAddress=""+result[0];

      

var arrayABI = <?=$mainContractABI; ?>;
var mainContractAddress = "<?=$mainContractAddress; ?>";
var referrerID = document.getElementById("regReferralID").value;



var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
  from: myAccountAddress, // default from address
  });




var data = myContract.methods.regUser(referrerID).encodeABI();
          web3.eth.sendTransaction({
          from: myAccountAddress,
          to: mainContractAddress,
          gasLimit: 900000,
          value:70000000000000000,
          data: data, // deploying a contracrt
          }).on('transactionHash', function(hash){
            alertify.alert("Transacton Recorded","Thanks for joining EthBull. You can check the status at <a href='https://etherscan.io/tx/"+hash+"' target='_blank'>Etherscan</a><br><br> Once transaction is confirmed in Blockchain, you can come back to this page and login into your account.", function(){});

          }).on('receipt', function(receipt){
        console.log(receipt)
       

        });









            }
          });
        } catch (error) {
            // User denied account access...
        }
    }
   
// Legacy dapp browsers...
    else if (window.web3) {
    alert('legacy');
    }
    // Non-dapp browsers...
    else {

        alert("System is not connecting to the user wallet. Please try again later!");
    }




});
})
});
</script>


  <script>
    (function(document, window, $) {
      'use strict';

      var Site = window.Site;
      $(document).ready(function() {
        Site.run();
      });
    })(document, window, jQuery);
  </script>



<span class="language-block"> <span style="padding: 5px 15px; background-color: #111; color: #fff; font-size: 24px;float: left;"> <i class="fa fa-language" aria-hidden="true"></i> </span> <ul class="list-unstyled lang-list" style="float: left;padding: 0;"> <div id="google_translate_element"></div> </ul> </span> 

<script type="text/javascript"> function googleTranslateElementInit() { new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element'); } </script>

<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>


</body>


<!-- Mirrored from getbootstrapadmin.com/remark/material/iconbar/pages/login-v3.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 06 Feb 2020 16:09:48 GMT -->
</html>