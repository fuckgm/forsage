<?php
$page = "Statistics";

//include('core/common_code.php');
include('top_navbar.php');
include('sidebar.php');
include('s_top_navbar.php');
// include('s_sidebar.php');

?>
  <link rel="stylesheet" href="global/vendor/datatables.net-bs4/dataTables.bootstrap4.minfd53.css?v4.0.1">

            <style>
			.row.min-width_structure{ width:75% }
			</style>
<div class="row min-width_structure-delete margin-bottom-70">
    <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <h3>Financial statistics</h3>
                <br>
                <h4 class="text-center" style="cursor: pointer;" data-spoiler=".filter-wrapper">
                    Filter                </h4>
                <form class="filter-wrapper" method="POST" action="<?php echo SITE_URL.'dashboard/?statistics';?>" style="display: block">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="matrix">Program</label>
                           <select name="plan" id="plan" class="form-control">
                           <option value="">---</option>
                           <option value="x3" <?php if($_POST){ if($_POST['plan']=='x3') { echo 'selected=selected';} }?>  >
                              x3
                           </option>
                           <option value="x6" <?php if($_POST){ if($_POST['plan']=='x6') { echo 'selected=selected';} }?>>
                              x6
                           </option>
                        </select>
                    
                        </div>
                        <div class="col-md-6">
                            <label for="level">Slot</label>
                            <select name="level" id="level" class="form-control">
                                <option value="">---</option>
                                                             <option value="1" <?php if($_POST){ if($_POST['level']=='1') { echo 'selected=selected';} }?>>
                              1
                           </option>
                           <option value="2" <?php if($_POST){ if($_POST['level']=='2') { echo 'selected=selected';} }?>>
                              2
                           </option>
                           <option value="3" <?php if($_POST){ if($_POST['level']=='3') { echo 'selected=selected';} }?>>
                              3
                           </option>
                           <option value="4" <?php if($_POST){ if($_POST['level']=='4') { echo 'selected=selected';} }?>>
                              4
                           </option>
                           <option value="5" <?php if($_POST){ if($_POST['level']=='5') { echo 'selected=selected';} }?>>
                              5
                           </option>
                           <option value="6" <?php if($_POST){ if($_POST['level']=='6') { echo 'selected=selected';} }?>>
                              6
                           </option>
                           <option value="7" <?php if($_POST){ if($_POST['level']=='7') { echo 'selected=selected';} }?>>
                              7
                           </option>
                           <option value="8" <?php if($_POST){ if($_POST['level']=='8') { echo 'selected=selected';} }?>>
                              8
                           </option>
                           <option value="9" <?php if($_POST){ if($_POST['level']=='9') { echo 'selected=selected';} }?>>
                              9
                           </option>
                           <option value="10" <?php if($_POST){ if($_POST['level']=='10') { echo 'selected=selected';} }?>>
                              10
                           </option>
                           <option value="11" <?php if($_POST){ if($_POST['level']=='11') { echo 'selected=selected';} }?>>
                              11
                           </option>
                           <option value="12" <?php if($_POST){ if($_POST['level']=='12') { echo 'selected=selected';} }?>>
                              12
                           </option>
                                                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="direction">Direction</label>
                            <select name="direction" id="direction" class="form-control">
                                <option value="">---</option>
                                <option value="0" >
                                    Incoming                                </option>
                                <option value="1" >
                                    Outgoing                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="type">Type of transaction</label>
                            <select name="type" id="type" class="form-control">
                                <option value="">---</option>
                                                                <option value="newUserPlaceEvent" >
                                    Sold places                                </option>
                                                                <option value="upgrageEvent" >
                                    Upgrades                                </option>
                                                                <option value="reinvestEvent" >
                                    Reinvest                                </option>
                                                                <option value="missedEthReceive" >
                                    Lost profits                                </option>
                                                                <option value="leadingPartnerToUpline" >
                                    Overtaking                                </option>
                                                                <option value="sentExtraEthDividends" >
                                    Gifts                                </option>
                                                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group mt-2">
                                <label for="tx">Search by hash</label>
                                <input type="text" name="wallet" value="<?php if($_POST){ if($_POST['wallet']!='') { echo $_POST['wallet'];} }?>" placeholder="Enter..." id="tx" class="form-control">
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="user" value="123">
                    <input type="hidden" name="sid" value="">
                    <button type="submit" class="btn btn-primary">
                        Apply                    </button>
                    <a href="<?php echo SITE_URL.'dashboard/?statistics';?>" class="btn btn-secondary">
                        Reset filter                    </a>
                </form>
                <br>
				<?php
				$count = 0;
				$query = "SELECT * FROM forsage_event_lostforlevel where referrer='".clean($userWallet)."' ";
				$result = mysqli_query($conn,$query);
				$row = mysqli_num_rows($result);

				if($row != NULL && $row > 0){
					while ($row1 = $result -> fetch_assoc()) {


				//find user id
				$query = "SELECT * FROM forsage_event_reglevel where userWallet='".$row1['buyer']."' limit 1 ";
				$result = mysqli_query($conn,$query);
				$row = mysqli_num_rows($result);
				$buyerID;
				if($row != NULL && $row > 0){
					$row2 = $result -> fetch_assoc();
					$buyerID = $row2['userID'];
					$count = $count +1;
				}
				}
				}
				?>
                <p>
                    The last transaction                    <span style="float: right" title="The number of transactions">(Total: <?php echo $count;?>)</span>
                </p>
				<?php
				if($_POST){
				$plan= $_POST['plan'];
				$levels = $_POST['level'];
				//$direction= $_POST['direction'];
				//$type= $_POST['type'];
				$search = $_POST['wallet'];
				}
					?>
                <div class="page-stats table-responsive">
                    <table class="table tableStyle page-stats_table">
                        <thead>
							<tr role="row">
								<th >Date</th>
								<th>ETH Amount</th>
								<th>Wallet Address</th>
								<th>User ID</th>
								<th >Levels</th>
								<th>Plan</th>
							</tr>
						</thead>
						<tbody>


<?php

 $query = "SELECT * FROM forsage_event_lostforlevel where referrer='".clean($userWallet)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
if($row != NULL && $row > 0){
	while ($row1 = $result -> fetch_assoc()) {


//find user id
 $query = "SELECT * FROM forsage_event_reglevel where userWallet='".$row1['buyer']."' limit 1 ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$buyerID;
if($row != NULL && $row > 0){
	$row2 = $result -> fetch_assoc();
	$buyerID = $row2['userID'];
}

			if($_POST){
if($levels=='' && $search=='' && $plan=="")
{
	echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
}elseif($levels=='' && $search=='' && $plan!="")
{
	if($plan==$row1['plan']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}
elseif($levels=='' && $search!='' && $plan=="")
{
	if($search==$row1['buyer']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}elseif($levels=='' && $search!='' && $plan!="")
{
	if($search==$row1['buyer'] && $plan==$row1['plan']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}elseif($levels!='' && $search=='' && $plan=="")
{
	if($levels==$row1['level']){

	}
}
elseif($levels!='' && $search=='' && $plan!="")
{
	if($levels==$row1['level'] && $plan==$row1['plan']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}elseif($levels!='' && $search!='' && $plan=="")
{
	if($levels==$row1['level'] && $search==$row1['buyer']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}elseif($levels!='' && $search!='' && $plan!="")
{
	if($levels==$row1['level'] && $search==$row1['buyer'] && $plan==$row1['plan']){
echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
	}
}else{
	echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';
}
			}else{


				echo'			<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
								<td>'.$row1['plan'].'</td>
							</tr>
				';

			}
	}
}






?>
						</tbody>

                    </table>
                </div>
                <div class="pagination_wrapper">
                                    </div>
            </div>
        </div>
    </div>
</div>
</div>


<script>
window.addEventListener('DOMContentLoaded', function () {
    let displayFilter = storage('page.stats');
    if(displayFilter == '1' || displayFilter == null) {
        $('.filter-wrapper').show();
    } else {
        $('.filter-wrapper').hide();
    }
    $('[data-spoiler=".filter-wrapper"]').click(function () {
        storageTrigger('page.stats');
    })
});
</script>
        </div>
    </div>
</div>



<!--   <?php
include('information_ethbullx3.php');
?>
 -->
<script>
var config = {
    site: {
        domain:   location.hostname,
        protocol: location.protocol + '//',
        hostname: location.hostname,
		//link: 'https://lk.forsage.io/',
        link: '<?php echo SITE_URL;?>',
        course: {
            value: `ETH_USD`,
            symbol: `$`,
        },
    },
    user: {
        refkey: 'vpat19',
        address: '0x948e5f339942f9f6cf417c5fe6de73ef6059bd8b',
        isAuthSecure: false,
        sid: '2b2fd7148b32c82b6c700573550e5ffe',
    },
    lang: {
        /* contract.js */
        buyLevel                 : `Confirm the purchase`,
        notDetectedWallet        : `The Ethereum wallet is Not detected on your browser.`,
        unblockWallet            : `Unlock the wallet for a transaction`,
        notActiveWallet          : `Ethereum wallet is not active`,
        errorSendingTransaction  : `Error sending transaction: `,
        transactionSend          : `The transaction has been sent! Please wait for confirmation of the network.`,
        confirmTransaction       : `Confirm the transaction in your Ethereum wallet`,
        errorReadSmartContract   : `Read error SmartContract`,
        uplineNotRegistered      : `Your upline is not registered`,
        userNotExists            : `The user is not registered`,
        authError                : `Authorization error`,

        /* common.js */
        copied                   : `Copied`,

        // Сокеты события
        'ws-regLevel_0'          : `Joined ID:{user_id}`,
        'ws-regLevel_1'          : `Joined ID:{user_id}. You are on the right way!`,
        'ws-regLevel_2'          : `Meet the new member ID:{user_id}.`,
        'ws-regLevel_3'          : `New user ID:{user_id}. Welcome to Forsage!`,
        'ws-newUserPlace'        : `ID:{user_id} earned {price_level} {crypto_name} (\${currency_usd}) in the {matrix}`,
        'ws-upgrade'             : `ID:{user_id} buy {level} slot in {matrix} from ID:{ref_id}.`,
        'ws-reinvest'            : `ID:{user_id} was auto-reinvested in slot {level} ({matrix})`,
        'ws-missedEthReceive'    : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}). You must perform the upgrade in ({matrix})`,
        'ws-sentExtraEthDividends':`ID:{user_id} received a bonus {price_level} {crypto_name} (\${currency_usd})`,
        'ws-cannotSendMoneyEvent': `ID:{user_id} error getting translation`,
        'ws-leadingPartner'      : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}) from (ID:{u_id}) for area # {level} ({matrix})`,
        'ws-leadingPartnerToUpline':`ID:{u_id} overtook its parent ID is:{user_id} in the matrix {matrix} with area # {level}`,
        'ws-leadingPlacePurchase': `ID:{user_id} ahead of your inviter (ID:{up_id}) for area # {level} ({matrix})`,

        // Скрипт с выводом даты отсчета времени
        'elt-years_0'            : `year`,
        'elt-years_1'            : `year`,
        'elt-years_2'            : `years`,
        'elt-months_0'           : `a month`,
        'elt-months_1'           : `months`,
        'elt-months_2'           : `months`,
        'elt-days_0'             : `day`,
        'elt-days_1'             : `day`,
        'elt-days_2'             : `days`,
        'elt-hours_0'            : `hour`,
        'elt-hours_1'            : `hours`,
        'elt-hours_2'            : `hours`,
        'elt-minutes_0'          : `min`,
        'elt-minutes_1'          : `min`,
        'elt-minutes_2'          : `min`,
        'elt-minutes_3'          : `a minute`,
        'elt-seconds_0'          : `second`,
        'elt-seconds_1'          : `seconds`,
        'elt-seconds_2'          : `seconds`,
        'elt-seconds_3'          : `second`,
        'elt-end'                : ` ago`,
        'elt-freshly'            : `just`,
        'elt-deadline'           : `time left`,
        'elt-after'              : `through `,
    },
    locked: {
        buyLevel      : ``,
        authorization : ``,
        registration  : ``,
    },
    permissions: {
        buyLevel      : `0`,
    },
    isFramed: null,
    isMobile: false,
    haveWallet: window.ethereum || window.web3,
};

// Получить основной домен
let arr = config.site.domain.split('.');
if(arr.length > 2) {
    config.site.domain = arr.slice(arr.length - 2).join('.')
}

// Запущен ли сайт в теге iframe
try {
  config.isFramed = window != window.top || document != top.document || self.location != top.location;
} catch (e) {
  config.isFramed = true;
}
</script>




  <script type="text/javascript" src="assets_s/js/jquery-3.5.1.js" ></script>

  <script src="global/vendor/datatables.net/jquery.dataTablesfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-bs4/dataTables.bootstrap4fd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive/dataTables.responsive.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.minfd53.js?v4.0.1"></script>
               <script>$(document).ready(function() {
                  $.noConflict();
                  var table = $('#example').DataTable( {
                     responsive: true
                  } );

                  new $.fn.dataTable.FixedHeader( table );
                  } );
               </script>
<script src="assets_s/Decentralized/js/jquery.min.js"></script>
<script src="assets_s/Decentralized/js/vue.min.js"></script>
<script src="assets_s/Decentralized/js/socket.io.js"></script>
<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets_s/Decentralized/js/common.js"></script>
<script src="assets_s/Decentralized/js/contract.js"></script>
<script src="assets_s/Decentralized/js/cabinet.js"></script>
<div class="require-auth">
    Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
    <br>
    <div>
                    <button class="btn btn-success" id="reauth">
                Authorization            </button>
            </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>

<?php
include('footer.php');
?>
