<div class="Container margin-bottom-70">
    <div class="stats-top row">
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 no-gutters align-items-center">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-6 stats-top_sum" style="color: #DD74C8">
                    <?php echo $totalPartners; ?>             
                </div>
                <div class="col-xl-8 col-lg-8 col-md-6 col-sm-6 col-6 stats-top_subject text-dark" >
                    ALL<br>PARTICIPANTS                    
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 no-gutters align-items-center">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 stats-top_sum" style="color: #1EA4C1">
                +8688                    
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 stats-top_subject text-dark">
                JOINED<br>IN 24 HOURS                    
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 no-gutters align-items-center">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-6 stats-top_sum" style="color: #A2A1F2">
                <?php echo $levelProfit; ?>                    
                </div>
                <div class="col-xl-8 col-lg-8 col-md-6 col-sm-6 col-6 stats-top_subject text-dark">
                PARTICIPANTS<br>have EARNED ETH                    
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12 no-gutters align-items-center">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 stats-top_sum" style="color: #A2A1F2;">
                    <?php echo number_format((float)($totalEarned*$ethPrice), 2, '.', ''); ?>  
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 stats-top_subject text-dark">
                    PARTICIPANTS<br>have EARNED USD                    
                </div>
            </div>
        </div>
    </div>
</div>