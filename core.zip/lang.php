<?php
    //RUSSIAN
    $language_ru['Billion Money Office'] = 'Биллиард Офис';
    $language_ru['We Are Comming Soon'] = 'Мы скоро приедем';
    $language_ru['PLEASE GIVE US A MOMENT TO SORT THINGS OUT'] = 'ПОЖАЛУЙСТА, ДАЙТЕ НАМ МОМЕНТ, ЧТОБЫ РАССМОТРЕТЬ';

    $language_ru['Dashboard'] = 'Приборная доска';
    $language_ru['Swap'] = 'обмен';
    $language_ru['Partners'] = 'партнеры';
    $language_ru['Uplines'] = 'Uplines';
    $language_ru['Lost Profits'] = 'Потерянная прибыль';
    $language_ru['Promo'] = 'рекламный';
    $language_ru['Exit'] = 'Выход';
    $language_ru['Total Earned'] = 'Всего заработано';
    $language_ru['Level Profits'] = 'Уровень Прибыль';
    $language_ru['Uni Level'] = 'Uni Level';
    $language_ru['Pools Profits'] = 'Прибыль Бассейны';
    $language_ru['Global Dividend'] = 'Глобальный Дивиденд';
    $language_ru['Available Fund'] = 'Доступный фонд';
    $language_ru['The growth of structure'] = 'Рост структуры';
    $language_ru['Your Affiliate Link'] = 'Ваша партнерская ссылка';
    $language_ru['Link for redirect to the Trust Wallet Dapp Browser'] = 'Подробности о вашем партнере';

    //ENGLISH
    $language_en['Billion Money Office'] = 'Billion Money Office';
    $language_en['We Are Comming Soon'] = 'We Are Comming Soon';
    $language_en['PLEASE GIVE US A MOMENT TO SORT THINGS OUT'] = 'PLEASE GIVE US A MOMENT TO SORT THINGS OUT';
    $language_en['Dashboard'] = 'Dashboard';
    $language_en['Swap'] = 'Swap';
    $language_en['Partners'] = 'Partners';
    $language_en['Uplines'] = 'Uplines';
    $language_en['Lost Profits'] = 'Lost Profits';
    $language_en['Promo'] = 'Promo';
    $language_en['Exit'] = 'Exit';
    $language_en['Total Earned'] = 'Total Dollars';
    $language_en['Level Profits'] = 'Total Ethereum';
    $language_en['Uni Level'] = 'Partners';
    $language_en['Pools Profits'] = 'Level Profits';
    $language_en['Global Dividend'] = 'Global Dividend';
    $language_en['Available Fund'] = 'Available Fund';
    $language_en['The growth of structure'] = 'The Growth of Network';
    $language_en['Your Affiliate Link'] = 'Your Affiliate Link';
    $language_en['Link for redirect to the Trust Wallet Dapp Browser'] = 'Link for redirect to the Trust Wallet Dapp Browser';

?>