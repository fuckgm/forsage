<!-- Site Navbar Seach -->
 
<?php 
//session_start();
 // Accessing session data
    
   ?>
     <div class="collapse navbar-search-overlap" id="site-navbar-search">
        <form role="search">
          <div class="form-group">
            <div class="input-search">
              <i class="input-search-icon md-search" aria-hidden="true"></i>
              <input type="text" class="form-control" name="site-search" placeholder="Search...">
              <button type="button" class="input-search-close icon md-close" data-target="#site-navbar-search"
                data-toggle="collapse" aria-label="Close"></button>
            </div>
          </div>
        </form>
      </div>
      <!-- End Site Navbar Seach -->
    </div>
  </nav>
    <div class="site-menubar site-menubar-light">
    <div class="site-menubar-body">
      <div>
        <div>
         <?php if($_SESSION["webpath"]=='1'){ ?>
				
          <ul class="site-menu site-menu-sub" data-plugin="menu">
            <li class="site-menu-item <?php if($page == 'Dashboard'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard/?s_dashboard';?>">
                  <i class="site-menu-icon md-home" aria-hidden="true"></i>
                  <span class="site-menu-title">Dashboard</span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'Partners'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?s_partners">
                  <i class=" site-menu-icon icon fa-handshake-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Partners</span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'SUplines'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?s_uplines">
                  <i class="site-menu-icon icon fa-address-book-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Uplines</span>
              </a>
            </li>


			<li class="site-menu-item has-sub <?php if($page == 'Statistics'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?statistics">
                  <i class="site-menu-icon icon fa-frown-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Statistics </span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'Information'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?information">
                  <i class="site-menu-icon icon fa-thumbs-o-up" aria-hidden="true"></i>
                  <span class="site-menu-title">Promo</span>
              </a>
            </li>
			<li class="site-menu-item has-sub">
              <a href="<?php echo SITE_URL.'dashboard';?>/logoutRedirect.php">
                  <i class="site-menu-icon icon fa-power-off" aria-hidden="true"></i>
                  <span class="site-menu-title">Exit</span>
              </a>
            </li>

          </ul>
       
				<?php }?>
				
				<?php if($_SESSION["webpath"]=='2'){ ?>
          <ul class="site-menu site-menu-sub" data-plugin="menu">
            <li class="site-menu-item <?php if($page == 'Dashboard'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>">
                  <i class="site-menu-icon md-home" aria-hidden="true"></i>
                  <span class="site-menu-title">Dashboard</span>
              </a>
            </li>
			<!-- <li class="site-menu-item has-sub <?php if($page == 'Swap'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard?swap';  ?>">
                  <i class="site-menu-icon icon md-swap" aria-hidden="true"></i>
                  <span class="site-menu-title"><?=$$lang['Swap']; ?></span>
              </a>
            </li> -->
			<li class="site-menu-item has-sub <?php if($page == 'Partner'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?partner">
                  <i class=" site-menu-icon icon fa-handshake-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Partners</span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'Uplines'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?uplines">
                  <i class="site-menu-icon icon fa-address-book-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Uplines</span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'Lost'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?lost">
                  <i class="site-menu-icon icon fa-frown-o" aria-hidden="true"></i>
                  <span class="site-menu-title">Lost Profits</span>
              </a>
            </li>
			<li class="site-menu-item has-sub <?php if($page == 'Promo'){echo "active";} ?>">
              <a href="<?php echo SITE_URL.'dashboard';?>?promo">
                  <i class="site-menu-icon icon fa-thumbs-o-up" aria-hidden="true"></i>
                  <span class="site-menu-title">Promo</span>
              </a>
            </li>
			<li class="site-menu-item has-sub">
              <a href="<?php echo SITE_URL.'dashboard';?>/logoutRedirect.php">
                  <i class="site-menu-icon icon fa-power-off" aria-hidden="true"></i>
                  <span class="site-menu-title">Exit</span>
              </a>
            </li>

          </ul>
       
	
				
				<?php }?>




		</div>
      </div>
    </div>
  </div>