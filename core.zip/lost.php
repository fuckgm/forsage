
<?php
$page = "Lost";
include('top_navbar.php');
include('sidebar.php');

?>
 

  <!-- Page -->
  <div class="page">
	<div class="page-content container-fluid">
		<div class="row" data-plugin="matchHeight" data-by-row="true">
		<div class="col-xxl-12 col-lg-12 pb-10" style="">
			<!-- TradingView Widget BEGIN -->
				<div class="tradingview-widget-container">
				  <div class="tradingview-widget-container__widget"></div>
				  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
				  {
				  "symbols": [
					{
					  "proName": "BITSTAMP:BTCUSD",
					  "title": "BTC/USD"
					},
					{
					  "proName": "BITSTAMP:ETHUSD",
					  "title": "ETH/USD"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHPAX"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHBTC"
					}
				  ],
				  "colorTheme": "light",
				  "isTransparent": false,
				  "displayMode": "adaptive",
				  "locale": "in"
				}
				  </script>
				</div>
<!-- TradingView Widget END -->
			  
			</div>
		
        </div>

	<div class="panel">
	<header class="panel-heading">
		<div class="panel-actions"></div>
		<h3 class="panel-title">Lost Profit</h3>
	</header>
	<div class="panel-body">
	<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
			<div class="row">
				<div class="col-sm-12">
					<table class="table table-hover dataTable table-striped w-full dtr-inline" data-plugin="dataTable" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="width: 1014px;">
						<thead>
							<tr role="row">
								<th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Date</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-label="Position: activate to sort column ascending">ETH Amount</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 184.992px;" aria-label="Office: activate to sort column ascending">Wallet Address</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 73.992px;" aria-label="Salary: activate to sort column ascending">User ID</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 73.992px;" aria-label="Salary: activate to sort column ascending">Levels</th>
							</tr>
						</thead>
						<tbody>


<?php


$query = "SELECT * FROM event_lostforlevelev where referrer='".clean($userWallet)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
if($row != NULL && $row > 0){
	while ($row1 = $result -> fetch_assoc()) {


//find user id
$query = "SELECT * FROM event_reglevelev where userWallet='".$row1['buyer']."' limit 1 ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$buyerID;
if($row != NULL && $row > 0){
	$row2 = $result -> fetch_assoc();
	$buyerID = $row2['userID'];
}
		

echo'							<tr role="row">
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								<td>'.($row1['amount'] / 1000000000000000000).'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['buyer'].'" target="new"> '.$row1['buyer'].' </a>
								</td>
								<td>'.$buyerID.'</td>
								<td>'.$row1['level'].'</td>
							</tr>
';	


	}
}



				


?>					
						</tbody>
					</table>
				</div>
			</div>
		
	</div>
	
	
	
		
		
	</div>
</div>
    </div>
	
  </div>
  <!-- End Page -->

<?php
include('footer.php');
?>