<?php
   $page = 'SUplines';
   //include('core/common_code.php');
   include('top_navbar.php');
    include('sidebar.php');
    include('s_top_navbar.php');
   // include('s_sidebar.php');
   ?>
    <link rel="stylesheet" href="global/vendor/datatables.net-bs4/dataTables.bootstrap4.minfd53.css?v4.0.1">

<style>
   div#example_length ,div#example_filter {
   display:none
   }
</style>
<!-- <div class="col-lg-12"> -->
   <!-- Всплывающие окошки с последними событиями -->
   
   <div class="row margin-bottom-70">
      <div class="col">
         <div class="border-gradient">
            <div class="border-gradient_content">
               <h3 class="head">Uplines</h3>
               <form class="bg-black_transparent filter-partners" method="POST" action="<?php echo SITE_URL.'dashboard/?s_uplines'?>">
                  <h4 class="text-center">Filter: </h4>
                  <div class="row">
                     <div class="col-md-3 form-group">
                        <label for="level">Slot</label>
                        <select name="level" id="level" class="form-control">
                           <option value="">---</option>
                           <option value="1" <?php if($_POST){ if($_POST['level']=='1') { echo 'selected=selected';} }?>>
                              1
                           </option>
                           <option value="2" <?php if($_POST){ if($_POST['level']=='2') { echo 'selected=selected';} }?>>
                              2
                           </option>
                           <option value="3" <?php if($_POST){ if($_POST['level']=='3') { echo 'selected=selected';} }?>>
                              3
                           </option>
                           <option value="4" <?php if($_POST){ if($_POST['level']=='4') { echo 'selected=selected';} }?>>
                              4
                           </option>
                           <option value="5" <?php if($_POST){ if($_POST['level']=='5') { echo 'selected=selected';} }?>>
                              5
                           </option>
                           <option value="6" <?php if($_POST){ if($_POST['level']=='6') { echo 'selected=selected';} }?>>
                              6
                           </option>
                           <option value="7" <?php if($_POST){ if($_POST['level']=='7') { echo 'selected=selected';} }?>>
                              7
                           </option>
                           <option value="8" <?php if($_POST){ if($_POST['level']=='8') { echo 'selected=selected';} }?>>
                              8
                           </option>
                           <option value="9" <?php if($_POST){ if($_POST['level']=='9') { echo 'selected=selected';} }?>>
                              9
                           </option>
                           <option value="10" <?php if($_POST){ if($_POST['level']=='10') { echo 'selected=selected';} }?>>
                              10
                           </option>
                           <option value="11" <?php if($_POST){ if($_POST['level']=='11') { echo 'selected=selected';} }?>>
                              11
                           </option>
                           <option value="12" <?php if($_POST){ if($_POST['level']=='12') { echo 'selected=selected';} }?>>
                              12
                           </option>
                        </select>
                     </div>
                     <div class="col-md-3 form-group">
                        <label for="matrix">Program</label>
                        <select name="plan" id="plan" class="form-control">
                           <option value="">---</option>
                           <option value="x3" <?php if($_POST){ if($_POST['plan']=='x3') { echo 'selected=selected';} }?>  >
                              x3
                           </option>
                           <option value="x6" <?php if($_POST){ if($_POST['plan']=='x6') { echo 'selected=selected';} }?>>
                              x6
                           </option>
                        </select>
                     </div>
                     <div class="col-md-6">
                        <div class="form-group">
                           <label for="search">Search by Wallet ID</label>
                           <input type="text" name="search" value="<?php if($_POST){ if($_POST['search']!='') { echo $_POST['search'];} }?>" placeholder="Enter..." id="search" class="form-control">
                        </div>
                     </div>
                  </div>
                  <input type="hidden" name="user" value="123">
                  <input type="hidden" name="sid" value="">
                  <button type="submit" class="btn btn-primary">
                  Apply                    </button>
                  <a href="<?php echo SITE_URL.'dashboard/?s_uplines';?>" class="btn btn-secondary">
                  Reset filter                    </a>
               </form>

			   <!-- Plugins For This Page -->

               <h4 class="head">Your Downline Partners</h4>
               <div class="mycls table-responsive" id="myid">
                  <table class="table_mini tablePartners" id="example">
                     <thead>
                        <tr class="mk">
                    <td>Line</td>
                    <td>User ID</td>
                    <td>Wallet Address</td>
                    <td class="mk1" style="display:block">Buy Level</td>
					<td>Plan</td>
                  </tr>
                     </thead>
                     <tbody>



<?php
if($_POST){
	$levels= $_POST['level'];
    $search= $_POST['search'];
    $plan= $_POST['plan'];

}


//find first level upline referrer
$query = "SELECT * FROM forsage_event_reglevel where userID='".clean($userID)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$uplineID;
if($row != NULL && $row > 0){
	$row1 = $result -> fetch_assoc();
	$uplineID = $row1['referrerID'];
}

for($i=0; $i<10; $i++){


$query = "SELECT * FROM forsage_event_reglevel where userID='".$uplineID."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
if($row != NULL && $row > 0){
	$row1 = $result -> fetch_assoc();

//find buy level of upline
$query = "SELECT level FROM forsage_event_levelbuy where buyer='".$row1['userWallet']."' order by level desc limit 0,1 ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$buyLevel=0;
if($row != NULL && $row > 0){
	$row2 = $result -> fetch_assoc();
	$buyLevel = $row2['level'];
}
if($_POST){ $levels= $_POST['level'];
    $search= $_POST['search'];
    $plan=$_POST['plan'];

if($levels=='' && $search=='' && $plan=="")
{
	echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
}elseif($levels=='' && $search=='' && $plan!="")
{
	if($plan==$row1['plan']){
echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}
elseif($levels=='' && $search!='' && $plan=="")
{
    if($search==$row1['userWallet']){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}	
}elseif($levels=='' && $search!='' && $plan!="")
{
	if($search==$row1['userWallet']&& $plan==$row1['plan']){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}elseif($levels!='' && $search=='' && $plan=="")
{
	if($levels==$buyLevel){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}
elseif($levels!='' && $search=='' && $plan!="")
{
	if($levels==$buyLevel && $plan==$row1['plan']){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}elseif($levels!='' && $search!='' && $plan=="")
{
	if($levels==$buyLevel && $search==$row1['userWallet']){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}elseif($levels!='' && $search!='' && $plan!="")
{
	if($levels==$buyLevel && $search==$row1['userWallet']&& $plan==$row1['plan']){
		echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
	}
}else{
	echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
							<td>'.$row1['plan'].'</td>
						</tr>

';
}

}else{

echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>
						</tr>

';

}
}else{


echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td><td>'.$row1['plan'].'</td>
						</tr>

';

}
$uplineID = $row1['referrerID'];



}
?>


  </tbody>
                  </table>
                  <div class="pagination_wrapper">
                  </div>
               </div>
               <!-- end: border-gradient_content -->
            </div>
            <!-- end: border-gradient -->
         </div>
      </div>
   </div>
</div>
</div>
<!-- </div> -->

<!-- <?php
include('information_ethbullx3.php');
?> -->

  <script type="text/javascript" src="assets_s/js/jquery-3.5.1.js" ></script>

  <script src="global/vendor/datatables.net/jquery.dataTablesfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-bs4/dataTables.bootstrap4fd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive/dataTables.responsive.minfd53.js?v4.0.1"></script>
  <script src="global/vendor/datatables.net-responsive-bs4/responsive.bootstrap4.minfd53.js?v4.0.1"></script>
               <script>$(document).ready(function() {
                  $.noConflict();
                  var table = $('#example').DataTable( {
                     responsive: true
                  } );

                  new $.fn.dataTable.FixedHeader( table );
                  } );
               </script>


<script src="assets_s/Decentralized/js/jquery.min.js"></script>
<script src="assets_s/Decentralized/js/vue.min.js"></script>
<script src="assets_s/Decentralized/js/socket.io.js"></script>
<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets_s/Decentralized/js/common.js"></script>
<script src="assets_s/Decentralized/js/contract.js"></script>
<script src="assets_s/Decentralized/js/cabinet.js"></script>
<div class="require-auth">
   Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
   <br>
   <div>
      <button class="btn btn-success" id="reauth">
      Authorization            </button>
   </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript>
   <div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div>
</noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
<?php
include('footer.php');
?>
