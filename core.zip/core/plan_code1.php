<?php

global $mainContractAddress;
global $mainContractABI;
global $hookContractAddress;
global $hookContractABI;
global $tokenContractAddress;
global $tokenContractABI;
global $ethPrice;
global $gasPriceAverage;
global $gasPriceFast;
global $siteName;
global $siteURL;
global $etherscanAddress;
global $etherscanTx;
global $infuraAPI;
global $ethPriceBtc;
global $project_year;
global $ethPiceInUsd;
global $siteNetworkId;

require_once('lang.php');

global $lang;
$lang = array();

if(isset($_COOKIE['country']) && $_COOKIE['country'] != ""){
   $lang = "language_".$_COOKIE['country'];
} else {
   $lang = "language_en";
}

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$e = explode("/?", $url);
$txn = '';
if (isset($e[1])) {
   $k = explode("/", $e[1]);

   if (!empty($k)) {
      $plan = $k[1];
      $level = $k[2];
      $userid = $k[3];

      if (!empty($k[4])) {
         $txn = $k[4];
      }

     /* if($userid != ''){
        $userID = $userid;
      }*/

   } else {
      $plan = '';
      $level = '';
      $userid = '';
      $txn = '';
   }
}

if($txn!='') {
   $loginuserID = $userid;
} else {
   $loginuserID = $userID;
}

$u = 12;
if($level != 1) {
   $u = $level-1;
} else {
   $u='12';
}

$v = 1;
if($level != 12) {
   $v = $level+1;
}

/* Lalji New logic for get count and last position fill in al 12 Levels - start */
global $globalLevelSum;
global $globalReinvestSum;
global $globalAmountSum;
global $globalGetAllMembers;

$globalLevelSum = 0;
$globalReinvestSum = 0;
$globalAmountSum = 0;
$globalGetAllMembers = [];

function fetchDownlinesData($userID, $conn, $level) {

    global $globalLevelSum;
    global $globalReinvestSum;
    global $globalAmountSum;
    global $globalGetAllMembers;

     $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevelev r left join forsage_event_levelbuyev l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='" . $level . "' ";

    //echo '<br/>';
    //echo '<br/>';

    $result = mysqli_query($conn, $query);
    $row_count = mysqli_num_rows($result);
    $tempArray = array();
    $reinvestTempArray = array();
    $amountTemp = 0; 

    if ($row_count > 0) {

        while ($row = mysqli_fetch_assoc($result)) {

            array_push($tempArray, $row['userID']);
            $globalGetAllMembers[] = $row['userID'];
            if($row['reinvest'] == 1){
              array_push($reinvestTempArray, $row['userID']);
            }

            $amount = ($row['amount'] / 1e18);
            $amountTemp += $amount;
            
        }

        $globalLevelSum += count($tempArray);
        $globalReinvestSum += count($reinvestTempArray);
        $globalAmountSum += $amountTemp;
        
    }

    $response = [];
    if (!empty($tempArray)) {
      foreach ($tempArray as $key => $user) {
        if ($user != '' && $user > 0) {
          $response = fetchDownlinesData($user, $conn, $level);
        }
      }
    }

    return ['tempArray' => $tempArray, 'globalLevelSum' => $globalLevelSum, 'globalReinvestSum' => $globalReinvestSum, 'globalAmountSum' => $globalAmountSum, 'globalGetAllMembers' => $globalGetAllMembers];
}

$total_level_member_count = 0;
$total_reinvest_member_count = 0;
$total_amount_sum = 0;

for($totalLevelNumber = 1; $totalLevelNumber <= 12; $totalLevelNumber++){

    $globalLevelSum = 0;
    $globalReinvestSum = 0;
    $globalAmountSum = 0;

    $total_level_Array = fetchDownlinesData($userID, $conn, $totalLevelNumber);
    //$level_position_fill = ($total_level_Array['globalLevelSum'] % 3);
    $member_count = $total_level_Array['globalLevelSum'];
    $total_level_member_count += $member_count;

    $reinvest_count = $total_level_Array['globalReinvestSum'];
    $total_reinvest_member_count += $reinvest_count;

    $amount_count = $total_level_Array['globalAmountSum'];
    $total_amount_sum += $amount_count;
}


/* Fetching Data for X4 - Start */

$x4_globalLevelSum = 0;
$x4_globalReinvestSum = 0;
$x4_globalAmountSum = 0;

function fetchX4DownlinesData($userID, $conn, $level)
{

    global $x4_globalLevelSum;
    global $x4_globalReinvestSum;
    global $x4_globalAmountSum;

    $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevelev r left join forsage_event_levelbuyev l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x4' and l.level='" . $level . "' ";

    $result = mysqli_query($conn, $query);
    $row_count = mysqli_num_rows($result);
    $x4_tempArray = array();
    $x4_reinvestTempArray = array();
    $x4_amountTemp = 0; 

    if ($row_count > 0) {

        while ($row = mysqli_fetch_assoc($result)) {

            array_push($x4_tempArray, $row['userID']);
            if($row['reinvest'] == 1){
              array_push($x4_reinvestTempArray, $row['userID']);
            }

            $amount = ($row['amount'] / 1e18);
            $x4_amountTemp += $amount;
            
        }

        $x4_globalLevelSum += count($x4_tempArray);
        $x4_globalReinvestSum += count($x4_reinvestTempArray);
        $x4_globalAmountSum += $x4_amountTemp;
        
    }

    if (!empty($x4_tempArray))
    {
        foreach ($x4_tempArray as $key => $user)
        {
            if ($user != '' && $user > 0)
            {
                fetchX4DownlinesData($user, $conn, $level);
            }
        }
    }

    return ['x4_tempArray' => $x4_tempArray, 'x4_globalLevelSum' => $x4_globalLevelSum, 'x4_globalReinvestSum' => $x4_globalReinvestSum, 'x4_globalAmountSum' => $x4_globalAmountSum];
}

$x4_total_level_member_count = 0;
$x4_total_reinvest_member_count = 0;
$x4_total_amount_sum = 0;

for($x4_totalLevelNumber = 1; $x4_totalLevelNumber <= 12; $x4_totalLevelNumber++){

    $x4_globalLevelSum = 0;
    $x4_globalReinvestSum = 0;
    $x4_lobalAmountSum = 0;

    $x4_total_level_Array = fetchX4DownlinesData($userID, $conn, $x4_totalLevelNumber);
    //$level_position_fill = ($total_level_Array['globalLevelSum'] % 3);
    $x4_member_count = $x4_total_level_Array['x4_globalLevelSum'];
    $x4_total_level_member_count += $x4_member_count;

    $x4_reinvest_count = $x4_total_level_Array['x4_globalReinvestSum'];
    $x4_total_reinvest_member_count += $x4_reinvest_count;

    $x4_amount_count = $x4_total_level_Array['x4_globalAmountSum'];
    $x4_total_amount_sum += $x4_amount_count;
}

/* Fetching Data for X4 - End */


/*
$globalLevelSum = 0;
$level_1_Array = fetchDownlinesData($userID, $conn, 1);
$level_1_PositionFill = ($level_1_Array['globalLevelSum'] % 3);
$level_1_member_count = $level_1_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_2_Array = fetchDownlinesData($userID, $conn, 2);
$level_2_PositionFill = ($level_2_Array['globalLevelSum'] % 3);
$level_2_member_count = $level_2_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_3_Array = fetchDownlinesData($userID, $conn, 3);
$level_3_PositionFill = ($level_3_Array['globalLevelSum'] % 3);
$level_3_member_count = $level_3_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_4_Array = fetchDownlinesData($userID, $conn, 4);
$level_4_PositionFill = ($level_4_Array['globalLevelSum'] % 4);
$level_4_member_count = $level_4_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_5_Array = fetchDownlinesData($userID, $conn, 5);
$level_5_PositionFill = ($level_5_Array['globalLevelSum'] % 5);
$level_5_member_count = $level_5_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_6_Array = fetchDownlinesData($userID, $conn, 6);
$level_6_PositionFill = ($level_6_Array['globalLevelSum'] % 3);
$level_6_member_count = $level_6_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_7_Array = fetchDownlinesData($userID, $conn, 7);
$level_7_PositionFill = ($level_7_Array['globalLevelSum'] % 3);
$level_7_member_count = $level_7_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_8_Array = fetchDownlinesData($userID, $conn, 8);
$level_8_PositionFill = ($level_8_Array['globalLevelSum'] % 3);
$level_8_member_count = $level_8_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_9_Array = fetchDownlinesData($userID, $conn, 9);
$level_9_PositionFill = ($level_9_Array['globalLevelSum'] % 3);
$level_9_member_count = $level_9_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_10_Array = fetchDownlinesData($userID, $conn, 10);
$level_10_PositionFill = ($level_10_Array['globalLevelSum'] % 3);
$level_10_member_count = $level_10_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_11_Array = fetchDownlinesData($userID, $conn, 11);
$level_11_PositionFill = ($level_11_Array['globalLevelSum'] % 3);
$level_11_member_count = $level_11_Array['globalLevelSum'];

$globalLevelSum = 0;
$level_12_Array = fetchDownlinesData($userID, $conn, 12);
$level_12_PositionFill = ($level_12_Array['globalLevelSum'] % 3);
$level_12_member_count = $level_12_Array['globalLevelSum'];
*/
/* Lalji New logic for get count and last position fill in al 12 Levels - End */

 $tmpuserID = $userID;
$user = '';
if(isset($_GET['user']) && $_GET['user'] != ''){
  $user = $_GET['user'];
  
  if($userID == $user){
    $user = "";
  } else {
    $userID = $user;
  }
}

//fetching data for Level Profit
$query = "SELECT SUM(amount) AS totalProfit FROM forsage_event_paidforlevelev where referrer='" . clean($userWallet) . "' ";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);
$levelProfit = 0;
if ($row != NULL)
{
    $levelProfit = $row['totalProfit'] / 1000000000000000000;
}
//Total earned:
$totalEarned = $levelProfit;

//fetching data for x3 plan profit
$query = "SELECT SUM(amount) AS totalProfit FROM forsage_event_paidforlevelev where referrer='" . clean($userWallet) . "' and plan='x3'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);
$levelProfit_x3 = 0;
if ($row != NULL)
{
    $levelProfit_x3 = $row['totalProfit'] / 1000000000000000000;
}
//Total earned:
$totalEarned_x3 = $levelProfit_x3;

//fetching data for x4 plan profit
$query = "SELECT SUM(amount) AS totalProfit FROM forsage_event_paidforlevelev where referrer='" . clean($userWallet) . "' and plan='x4'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_array($result);
$levelProfit_x4 = 0;
if ($row != NULL)
{
    $levelProfit_x4 = $row['totalProfit'] / 1000000000000000000;
}
//Total earned:
$totalEarned_x4 = $levelProfit_x4;

//total x3 and x4 calculation
$x3 = number_format((float)($totalEarned_x3 * $ethPrice) , 2, '.', '');
$x4 = number_format((float)($totalEarned_x4 * $ethPrice) , 2, '.', '');
$total_x = $x3 + $x4;

$levelProfit_x = $levelProfit_x4 + $levelProfit_x3;
