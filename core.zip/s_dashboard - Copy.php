<?php
/*
0 EMPTY
1 PARTNER INVITED BY YOU
2 OVERFLOW FROM UP
3 BOTTOM OVERFLOW
4 PARTNER WHO IS AHEAD OF HIS INVITER*/

$page = "Dashboard";
include('top_navbar.php');
include('sidebar.php');
include('s_top_navbar.php');
include('core/dashboard_curl.php');
include('core/plan_code.php');

   function fetchDownlines_1($userID, $conn, $level=0){

   $query = "SELECT * FROM forsage_event_reglevel where referrerID='".clean($userID)."' and plan='x3' ";
   $result = mysqli_query($conn,$query);
   $row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
   while ($row1 = $result -> fetch_assoc()) {
   array_push($tempArray,$row1['userID']);


   }
   }
   return $tempArray;
   }





   //Toal partners - all levels

   $mainArray_1 = array();
   $level1Array_1 = array();

   $first_array=array();
   $second_array=array();
   $third_array=array();
   $four_array=array();
   $fiv_array=array();
   $six_array=array();
   $seven_array=array();
   $eight_array=array();
   $nine_array=array();
   $ten_array=array();
   $eleven_array=array();
   $twelve_array=array();

   $first_levelID='';
   $second_levelID='';
   $third_levelID='';
   $four_levelID='';
   $fiv_levelID='';
   $six_levelID='';
   $seven_levelID='';
   $eight_levelID='';
   $nine_levelID='';
   $ten_levelID='';
   $eleven_levelID='';
   $twelve_levelID='';
   
   $first_levelID1='';
   $second_levelID1='';
   $third_levelID1='';
   $four_levelID1='';
   $fiv_levelID1='';
   $six_levelID1='';
   $seven_levelID1='';
   $eight_levelID1='';
   $nine_levelID1='';
   $ten_levelID1='';
   $eleven_levelID1='';
   $twelve_levelID1='';
   
   
//level 1 for x3 plan
 
 //echo $query = "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=1 ";
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=1 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$first_array[] = $row1['id'];
		$first_array_all[] = $row1;

		
		}
   }
   if(!empty($first_array)){
	   $countRow=count($first_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($first_array_all[$i]['reinvest']=='1'){
		   $first_levelID = $first_array[0];
		   }else{
			   $first_levelID = $first_array[0];
		   }
		    //$first_levelID1 = $first_array[1];
			$first_levelID1 ='';
	   }
   }
   
  //level 2 for x3 plan
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=2 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$second_array[] = $row1['id'];
		$second_array_all[] = $row1;

		
		}
   }
   if(!empty($second_array)){
	   $countRow=count($second_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($second_array_all[$i]['reinvest']=='1'){
		   $second_levelID = $second_array[0];
		   }else{
			   $second_levelID = $second_array[0];
		   }
		    //$second_levelID1 = $second_array[1];
			$second_levelID1 ='';
	   }
   }
   

 //level 3 for x3
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=3 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$third_array[] = $row1['id'];
		$third_array_all[] = $row1;

		
		}
   }
   if(!empty($third_array)){
	   $countRow=count($third_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($third_array_all[$i]['reinvest']=='1'){
		   $third_levelID = $third_array[0];
		   }else{
			   $third_levelID = $third_array[0];
		   }
		    //$third_levelID1 = $third_array[1];
			$third_levelID1 ='';
	   }
   }
   

//level 4
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=4 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$four_array[] = $row1['id'];
		$four_array_all[] = $row1;

		
		}
   }
   if(!empty($four_array)){
	   $countRow=count($four_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($four_array_all[$i]['reinvest']=='1'){
		   $four_levelID = $four_array[0];
		   }else{
			   $four_levelID = $four_array[0];
		   }
		    //$four_levelID1 = $four_array[1];
			$four_levelID1 ='';
	   }
   }
     
   //level 5
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=5 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$fiv_array[] = $row1['id'];
		$fiv_array_all[] = $row1;

		
		}
   }
   if(!empty($fiv_array)){
	   $countRow=count($fiv_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($fiv_array_all[$i]['reinvest']=='1'){
		   $fiv_levelID = $fiv_array[0];
		   }else{
			   $fiv_levelID = $fiv_array[0];
		   }
		    //$fiv_levelID1 = $fiv_array[1];
			$fiv_levelID1 ='';
	   }
   }
    
   
   //level 6
 

 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=6 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$six_array[] = $row1['id'];
		$six_array_all[] = $row1;

		
		}
   }
   if(!empty($six_array)){
	   $countRow=count($six_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($six_array_all[$i]['reinvest']=='1'){
		   $six_levelID = $six_array[0];
		   }else{
			   $six_levelID = $six_array[0];
		   }
		    //$six_levelID1 = $six_array[1];
			$six_levelID1 ='';
	   }
   }
    
   
   
   //level 7
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=7 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$seven_array[] = $row1['id'];
		$seven_array_all[] = $row1;

		
		}
   }
   if(!empty($seven_array)){
	   $countRow=count($seven_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($seven_array_all[$i]['reinvest']=='1'){
		   $seven_levelID = $seven_array[0];
		   }else{
			   $seven_levelID = $seven_array[0];
		   }
		    //$seven_levelID1 = $seven_array[1];
			$seven_levelID1 ='';
	   }
   }
   
   //level 8
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=8 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$eight_array[] = $row1['id'];
		$eight_array_all[] = $row1;

		
		}
   }
   if(!empty($eight_array)){
	   $countRow=count($eight_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($eight_array_all[$i]['reinvest']=='1'){
		   $eight_levelID = $eight_array[0];
		   }else{
			   $eight_levelID = $eight_array[0];
		   }
		    //$eight_levelID1 = $eight_array[1];
			$eight_levelID1 ='';
	   }
   }
     
   //level 9
 

 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=9 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$nine_array[] = $row1['id'];
		$nine_array_all[] = $row1;

		
		}
   }
   if(!empty($nine_array)){
	   $countRow=count($nine_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($nine_array_all[$i]['reinvest']=='1'){
		   $nine_levelID = $nine_array[0];
		   }else{
			   $nine_levelID = $nine_array[0];
		   }
		    //$nine_levelID1 = $nine_array[1];
			$nine_levelID1 ='';
	   }
   }
   
   
   //level 10
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=10 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$ten_array[] = $row1['id'];
		$ten_array_all[] = $row1;

		
		}
   }
   if(!empty($ten_array)){
	   $countRow=count($ten_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($ten_array_all[$i]['reinvest']=='1'){
		   $ten_levelID = $ten_array[0];
		   }else{
			   $ten_levelID = $ten_array[0];
		   }
		    //$ten_levelID1 = $ten_array[1];
			$ten_levelID1 ='';
	   }
   }
   
   
   //level 11
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=11 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$eleven_array[] = $row1['id'];
		$eleven_array_all[] = $row1;

		
		}
   }
   if(!empty($eleven_array)){
	   $countRow=count($eleven_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($eleven_array_all[$i]['reinvest']=='1'){
		   $eleven_levelID = $eleven_array[0];
		   }else{
			   $eleven_levelID = $eleven_array[0];
		   }
		    //$eleven_levelID1 = $eleven_array[1];
			$eleven_levelID1 ='';
	   }
   }
     
   //level 12
 
 $query= "SELECT * FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID='".$userID."' and l.plan='x3' and level=12 order by l.id DESC";
$result = mysqli_query($conn,$query);
																																												
$row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
		while ($row1 = $result -> fetch_assoc()) {
		$twelve_array[] = $row1['id'];
		$twelve_array_all[] = $row1;

		
		}
   }
   if(!empty($twelve_array)){
	   $countRow=count($twelve_array);
	   
	   for($i=0;$i<$countRow;$i++){
		   if($twelve_array_all[$i]['reinvest']=='1'){
		   $twelve_levelID = $twelve_array[0];
		   }else{
			   $twelve_levelID = $twelve_array[0];
		   }
		    //$twelve_levelID1 = $twelve_array[1];
			$twelve_levelID1 ='';
	   }
   }
     ?>


<div class="row">

<style>
.matrix-children__overflow{
	background-color: #007bff !important;
}
.matrix-children__nonactive {
    background-color: transparent;
    border: 1px solid #007bff;
    box-shadow: inset 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__active {
    background-color: lightblue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__overflow {
    background-color: whiteblue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__overflow_partner {
    background-color: blue;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
.matrix-children__advance {
    background-color: lilac;
    box-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
}
</style>
  <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <div id="x3main" class="logotypeX3">
                    <!-- <img src="assets_s/Decentralized/img/x3.svg" alt=""> -->
                    <h1>ETH BULL X3</h1>
                </div>
                <div class="ternary-wrapper">
					<?php if(!empty($first_array)){ ?>
						                    <div class="ternary">
									<a href="<?php echo SITE_URL.'dashboard/?page/x3/1/'.$userID;?>" class="ternary-root matrix-root__active ">
                                                        <span class='matrix-level matrix-level__active '> 1                             </span>
																		<span class="matrix-price">0.03   </span>
																															</a>

																	<div class="ternary-children">
										<?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '1' AND `plan` = 'x3' order by id DESC";
											$result = mysqli_query($conn,$query);
											  $row = mysqli_num_rows($result);
											 $total_first_level_member=count($row);
											 $first_array_id_level = mysqli_fetch_array($result);
											 $wallet1= $first_array_id_level['fromWallet'];
											 $transationtype1= $first_array_id_level['transactionType'];
											 
											 
											  $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
											$result = mysqli_query($conn,$query);
											 $from1user = mysqli_fetch_array($result);
											  $first_levelID=$from1user['userId'];
											  ?>
																									<div
																			 <?php 
																			 
																			 if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
																			 else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
																			 else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
																			 else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
																				else { echo 'class="matrix-children__nonactive "'; }
																			 
																			 /*if(!empty($first_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
																	   ?>
																									>
																											<a <?php if(!empty($first_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/1/'.$first_levelID.'/tx='.$userWallet.'"';} ?>></a></div>
											   
											   <div
																			 <?php if($first_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
																	   ?>
																									>
																											<a <?php if($first_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/1/'.$first_levelID1.'/tx='.$userWallet.'"';} ?>></a></div>
																									<div class="matrix-children__nonactive ">
																										</div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>                     <div class="matrix-break"></div>
                        <div class="matrix-info">
															<div class="matrix_partners__count">
                                <span>
                                      <?php 	echo $total_first_level_member;
											

                           ?>                                  </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
								<?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
								
	  $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='1' and l.reinvest='1'";
								$result = mysqli_query($conn,$query);
											 echo $row = mysqli_num_rows($result);
								
								?>                         </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
					
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="3"
                                data-matrix_price="0.1"
                                onclick="buyLevel(1)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                1                            </span>
                            <span class="matrix-price">0.03
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				
                 <?php if(!empty($second_array)){ ?>
					<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/2/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 2                            </span>
   <span class="matrix-price">0.06   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '2' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_second_level_member=count($row);
          $second_array_id_level = mysqli_fetch_array($result);
          $wallet1= $second_array_id_level['fromWallet'];
          $transationtype1= $second_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $second_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($second_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($second_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/2/'.$second_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($second_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($second_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/2/'.$second_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_second_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='2' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div><?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="3"
                                data-matrix_price="0.06"
                                onclick="buyLevel(2)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                2                            </span>
                            <span class="matrix-price">0.06
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				   
				   
				   <?php if(!empty($third_array)){ ?>
			<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/3/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 3                            </span>
   <span class="matrix-price">0.12   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '3' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_third_level_member=count($row);
          $third_array_id_level = mysqli_fetch_array($result);
          $wallet1= $third_array_id_level['fromWallet'];
          $transationtype1= $third_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $third_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($third_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($third_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/3/'.$third_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($third_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($third_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/3/'.$third_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_third_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='3' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>		<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="3"
                                data-matrix_price="0.12"
                                onclick="buyLevel(3)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                3                            </span>
                            <span class="matrix-price">0.12
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($four_array)){ ?>
					<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/4/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 4                            </span>
   <span class="matrix-price">0.24   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '4' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_four_level_member=count($row);
          $four_array_id_level = mysqli_fetch_array($result);
          $wallet1= $four_array_id_level['fromWallet'];
          $transationtype1= $four_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $four_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($four_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($four_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/4/'.$four_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($four_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($four_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/4/'.$four_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_four_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='4' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="3"
                                data-matrix_price="0.24"
                                onclick="buyLevel(4)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                4                         </span>
                            <span class="matrix-price">0.24
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($fiv_array)){ ?>
						<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/5/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 5                            </span>
   <span class="matrix-price">0.48   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '5' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_fiv_level_member=count($row);
          $fiv_array_id_level = mysqli_fetch_array($result);
          $wallet1= $fiv_array_id_level['fromWallet'];
          $transationtype1= $fiv_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $fiv_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($fiv_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($fiv_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/5/'.$fiv_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($fiv_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($fiv_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/5/'.$fiv_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_fiv_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='5' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="5"
                                data-matrix_price="0.48"
                                onclick="buyLevel(5)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                5                         </span>
                            <span class="matrix-price">0.48
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($six_array)){ ?>
						             <div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/6/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 6                            </span>
   <span class="matrix-price">0.96   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '6' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_six_level_member=count($row);
          $six_array_id_level = mysqli_fetch_array($result);
          $wallet1= $six_array_id_level['fromWallet'];
          $transationtype1= $six_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $six_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($six_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($six_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/6/'.$six_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($six_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($six_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/6/'.$six_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_six_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='6' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="6"
                                data-matrix_price="0.96"
                                onclick="buyLevel(6)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                6                         </span>
                            <span class="matrix-price">0.96
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($seven_array)){ ?>
		<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/7/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 7                            </span>
   <span class="matrix-price">1.92   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '7' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_seven_level_member=count($row);
          $seven_array_id_level = mysqli_fetch_array($result);
          $wallet1= $seven_array_id_level['fromWallet'];
          $transationtype1= $seven_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $seven_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($seven_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($seven_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/7/'.$seven_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($seven_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($seven_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/7/'.$seven_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_seven_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='7' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>			
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="6"
                                data-matrix_price="1.92"
                                onclick="buyLevel(7)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                7                         </span>
                            <span class="matrix-price">1.92
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($eight_array)){ ?>
						     <div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/8/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 8                            </span>
   <span class="matrix-price">3.84   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '8' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_eight_level_member=count($row);
          $eight_array_id_level = mysqli_fetch_array($result);
          $wallet1= $eight_array_id_level['fromWallet'];
          $transationtype1= $eight_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $eight_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($eight_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($eight_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/8/'.$eight_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($eight_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($eight_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/8/'.$eight_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_eight_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='8' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="6"
                                data-matrix_price="3.84"
                                onclick="buyLevel(8)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                8                         </span>
                            <span class="matrix-price">3.84
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($nine_array)){ ?>
					<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/9/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 9                            </span>
   <span class="matrix-price">7.68   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '9' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_nine_level_member=count($row);
          $nine_array_id_level = mysqli_fetch_array($result);
          $wallet1= $nine_array_id_level['fromWallet'];
          $transationtype1= $nine_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $nine_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($nine_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($nine_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/9/'.$nine_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($nine_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($nine_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/9/'.$nine_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_nine_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='9' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="9"
                                data-matrix_price="7.68"
                                onclick="buyLevel(9)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                9                        </span>
                            <span class="matrix-price">7.68
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($ten_array)){ ?>
						            <div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/10/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 10                            </span>
   <span class="matrix-price">15.36   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '10' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_ten_level_member=count($row);
          $ten_array_id_level = mysqli_fetch_array($result);
          $wallet1= $ten_array_id_level['fromWallet'];
          $transationtype1= $ten_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $ten_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($ten_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($ten_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/10/'.$ten_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($ten_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($ten_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/10/'.$ten_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_ten_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='10' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="9"
                                data-matrix_price="15.36"
                                onclick="buyLevel(10)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                10                        </span>
                            <span class="matrix-price">15.36
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($eleven_array)){ ?>
				<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/11/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 11                            </span>
   <span class="matrix-price">30.72   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '11' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_eleven_level_member=count($row);
          $eleven_array_id_level = mysqli_fetch_array($result);
          $wallet1= $eleven_array_id_level['fromWallet'];
          $transationtype1= $eleven_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $eleven_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($eleven_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($eleven_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/11/'.$eleven_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($eleven_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($eleven_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/11/'.$eleven_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_eleven_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='11' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>	
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="11"
                                data-matrix_price="30.72"
                                onclick="buyLevel(11)
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                11                        </span>
                            <span class="matrix-price">30.72
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				<?php if(!empty($twelve_array)){ ?>
			<div class="ternary">
   <a href="<?php echo SITE_URL.'dashboard/?page/x3/12/'.$userID;?>" class="ternary-root matrix-root__active ">
   <span class='matrix-level matrix-level__active '> 12                            </span>
   <span class="matrix-price">61.74   </span>
   </a>
   <div class="ternary-children">
      <?php    $query = "SELECT * FROM `forsage_event_transactions` WHERE `receiver` = '".$userWallet."' AND `level` = '12' AND `plan` = 'x3' order by id DESC";
         $result = mysqli_query($conn,$query);
           $row = mysqli_num_rows($result);
          $total_twelve_level_member=count($row);
          $twelve_array_id_level = mysqli_fetch_array($result);
          $wallet1= $twelve_array_id_level['fromWallet'];
          $transationtype1= $twelve_array_id_level['transactionType'];
          
          
           $query = "SELECT userId FROM `forsage_event_reglevel` WHERE `userWallet` = '".$wallet1."' ";
         $result = mysqli_query($conn,$query);
          $from1user = mysqli_fetch_array($result);
           $twelve_levelID=$from1user['userId'];
           ?>
      <div
         <?php 
            if($transationtype1=='1'){ echo 'class=" matrix-children__active "'; }
            else if($transationtype1=='2'){ echo 'class=" matrix-children__overflow "'; }
            else  if($transationtype1=='3'){ echo 'class=" matrix-children__overflow_partner "'; }
            else   if($transationtype1=='4'){ echo 'class=" matrix-children__advance "'; }
            else { echo 'class="matrix-children__nonactive "'; }
            
            /*if(!empty($twelve_array)){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';}*/
            ?>
         >
         <a <?php if(!empty($twelve_array)){ echo 'href="'.SITE_URL.'dashboard/?page/x3/12/'.$twelve_levelID.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div
         <?php if($twelve_levelID1!=''){ echo 'class="matrix-children__overflow "';}else { echo 'class="matrix-children__nonactive "';} 
            ?>
         >
         <a <?php if($twelve_levelID1!=''){ echo 'href="'.SITE_URL.'dashboard/?page/x3/12/'.$twelve_levelID1.'/tx='.$userWallet.'"';} ?>></a>
      </div>
      <div class="matrix-children__nonactive ">
      </div>
   </div>
   <div class="ternary-branchs">
      <div></div>
      <div></div>
      <div></div>
   </div>
   <div class="matrix-break"></div>
   <div class="matrix-info">
      <div class="matrix_partners__count">
         <span>
         <?php 	echo $total_twelve_level_member;
            ?>                                  </span>
         <i class="matrix-icon_users"></i>
      </div>
      <div class="matrix_reinvest">
         <span>
         <?php // $query = "SELECT r.*, l.reinvest, l.amount FROM forsage_event_reglevel r left join forsage_event_levelbuy l on l.buyer=r.userWallet  WHERE r.referrerID  = '" . clean($userID) . "' and l.plan='x3' and l.level='1' and l.reinvest='1' ";
            $query = "select * FROM forsage_event_transactions t  join forsage_event_levelbuy l on l.buyer=t.fromWallet  WHERE t.receiver  = '".$userWallet."' and l.plan='x3' and l.level='12' and l.reinvest='1'";
            					$result = mysqli_query($conn,$query);
            								 echo $row = mysqli_num_rows($result);
            					
            					?>                         </span>
         <i class="matrix-icon_sync"></i>
      </div>
   </div>
</div>		
					<?php }else{ ?>
				  		   <div class="ternary">
                        <a  class="ternary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="1"
                                data-level="11"
                                data-matrix_price="61.74"
                                onclick="buyLevel(12)
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                12                        </span>
                            <span class="matrix-price">61.74
                                                           </span>
                                                                                </a>
                        <div class="ternary-children">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="ternary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>
				  <?php 
						
					  } ?>
				
								   </div><!-- end: ternary-wrapper -->
            </div><!-- end: border-gradient_content -->
        </div><!-- end: border-gradient -->
    </div><!-- end: col -->
</div><!-- end: row -->

<div class="row my-4">
    <div class="col">
        <div class="icon-tips">
            <div class="matrix_currency">
                <strong style="color:#000000;font-weight: bold">eth</strong> <span>THE COST OF SLOTS IN ETH (ETHEREUM)</span>
            </div>
            <div class="matrix_reinvest">
                <i class="matrix-icon_sync"></i> <span>NUMBER OF REINVESTS</span>
            </div>
            <div class="matrix_partners__count">
                <i class="matrix-icon_users"></i> <span>PARTNERS ON THE SLOT</span>
            </div>
        </div>
    </div>
</div>


<?php
   function fetchDownlines_4($userID, $conn, $level=0){

   $query = "SELECT * FROM forsage_event_reglevel where referrerID='".clean($userID)."' and plan='x6' ";
   $result = mysqli_query($conn,$query);
   $row = mysqli_num_rows($result);
   $tempArray = array();
   if($row != NULL && $row > 0){
   	while ($row1 = $result -> fetch_assoc()) {
   		array_push($tempArray,$row1['userID']);


   	}
   }
   return $tempArray;
   }





   //Toal partners - all levels

   $mainArray_1 = array();
   $level1Array_1 = array();

   $first_array_x4=array();
   $second_array_x4=array();
   $third_array_x4=array();
   $four_array_x4=array();
   $fiv_array_x4=array();
   $six_array_x4=array();
   $seven_array_x4=array();
   $eight_array_x4=array();
   $nine_array_x4=array();
   $ten_array_x4=array();
   $eleven_array_x4=array();
   $twelve_array_x4=array();



   //level 1 referrals
   $tempArray2_2 = fetchDownlines_4($userID, $conn, 1);

   if(count($tempArray2_2) > 0){
      	$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);
      	$level1Array_1 = $tempArray2_2;
      	// $firstLevel = count($tempArray2_2);
      	 $first_array_x4=$tempArray2_2;

      	// define('FIRSTLEVEL',$firstLevel);
      		//These are level 1 refs

      		foreach ($tempArray2_2 as $key) {

      			//level 2 referrals
      			$tempArray2_2 = fetchDownlines_4($key, $conn, 2);
      						//print_r($tempArray2_2);
      							for ($i = 0; $i < count($tempArray2_2); $i++) {
      								if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      									operatii($second_array_x4, $tempArray2_2[$i]);
      								} else {
      									array_push($second_array_x4, $tempArray2_2[$i]);
      								}
      							}


      			if(count($tempArray2_2) > 0){

      				$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);

      				//These are level 2 refs
      				foreach ($tempArray2_2 as $key) {

      					//level 2 referrals
      					$tempArray2_2 = fetchDownlines_4($key, $conn, 3);

      					for ($i = 0; $i < count($tempArray2_2); $i++) {
      								if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      									operatii($third_array_x4, $tempArray2_2[$i]);
      								} else {
      									array_push($third_array_x4, $tempArray2_2[$i]);
      								}
      							}




      					//print_r($tempArray2_2);
      					//level 3 referrals
      					if(count($tempArray2_2) > 0){

      						$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);

      							//level 4
      							foreach ($tempArray2_2 as $key) {

      								$tempArray2_2 = fetchDownlines_4($key, $conn, 4);
      								for ($i = 0; $i < count($tempArray2_2); $i++) {
      								if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      									operatii($four_array_x4, $tempArray2_2[$i]);
      								} else {
      									array_push($four_array_x4, $tempArray2_2[$i]);
      								}
      							}
      								//level 4 referrals
      								if(count($tempArray2_2) > 0){

      									$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);


      										//level 5
      										foreach ($tempArray2_2 as $key) {

      										$tempArray2_2 = fetchDownlines_4($key, $conn, 5);
      										for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($fiv_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($fiv_array_x4, $tempArray2_2[$i]);
      											}
      }
      										//level 5 referrals
      										if(count($tempArray2_2) > 0){

      											$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);



      //level 6
      foreach ($tempArray2_2 as $key) {

      $tempArray2_2 = fetchDownlines_4($key, $conn, 6);
      for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($six_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($six_array_x4, $tempArray2_2[$i]);
      											}
      }
      //level 6 referrals
      if(count($tempArray2_2) > 0){

      	$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);

      	//level 7
      	foreach ($tempArray2_2 as $key) {

      	$tempArray2_2 = fetchDownlines_4($key, $conn, 7);
      for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($seven_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($seven_array_x4, $tempArray2_2[$i]);
      											}
      }
      	//level 7 referrals
      	if(count($tempArray2_2) > 0){

      		$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);


      		//level 8
      		foreach ($tempArray2_2 as $key) {

      		$tempArray2_2 = fetchDownlines_4($key, $conn, 8);
      for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($eight_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($eight_array_x4, $tempArray2_2[$i]);
      											}
      }
      		//level 8 referrals
      		if(count($tempArray2_2) > 0){

      			$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);


      			//level 9
      			foreach ($tempArray2_2 as $key) {

      			$tempArray2_2 = fetchDownlines_4($key, $conn, 9);
      for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($nine_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($nine_array_x4, $tempArray2_2[$i]);
      											}
      }
      			//level 9 referrals
      			if(count($tempArray2_2) > 0){

      				$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);


      				//level 10
      				foreach ($tempArray2_2 as $key) {

      				$tempArray2_2 = fetchDownlines_4($key, $conn, 10);
      for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($ten_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($ten_array_x4, $tempArray2_2[$i]);
      											}
      }
      				//level 10 referrals
      				if(count($tempArray2_2) > 0){

      					$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);

      //---------------------------------------------------------------------------------------------------

      //level 11
      				foreach ($tempArray2_2 as $key) {

      				$tempArray2_2 = fetchDownlines_4($key, $conn, 11);
   				for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($eleven_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($eleven_array_x4, $tempArray2_2[$i]);
      											}
   				}
      				//level 11 referrals
      				if(count($tempArray2_2) > 0){

      					$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);

   					 //level 12
      				foreach ($tempArray2_2 as $key) {

      				$tempArray2_2 = fetchDownlines_4($key, $conn, 12);
   				for ($i = 0; $i < count($tempArray2_2); $i++) {
      											if ($tempArray2_2[$i] === "+" || $tempArray2_2[$i] === "-" || $tempArray2_2[$i] === "*" || $tempArray2_2[$i] === "/" ) {
      												operatii($twelve_array_x4, $tempArray2_2[$i]);
      											} else {
      												array_push($twelve_array_x4, $tempArray2_2[$i]);
      											}
   				}
      				//level 12 referrals
      				if(count($tempArray2_2) > 0){

      					$mainArray_1 = array_merge($mainArray_1, $tempArray2_2);


   				}
   				}
   				}
   			}

      //-------------------------------------------------------------------------------------------------------




      				}//level 10 if condition


      				}	//level 10 foreach



      			}//level 9 if condition


      			}	//level 9 foreach



      		}//level 8 if condition


      		}	//level 8 foreach



      	}//level 7 if condition


      	}	//level 7 foreach




      }//level 6 if condition


      }	//level 6 foreach




      										}//level 5 if condition


      									}	//level 5 foreach


      								}//level 4 if condition


      							}	//level 4 foreach


      					}//level 3 if condition


      				}	//level 3 foreach


      			}//level 2 if condition


      		}	//level 2 foreach


      }	// level 1 if condition
      $totalPartners = count($mainArray_1);
      $level1Partners = count($level1Array_1);





      ?>

<div class="row">
    <div class="col">
        <div class="border-gradient">
            <div class="border-gradient_content">
                <div id="x4main" class="logotypeX4">
                    <!-- <img src="assets_s/Decentralized/img/x4.svg" alt=""> -->
                    <h1>ETH BULL X6</h1>
                </div>
                <div class="binary-wrapper">

				 <?php // echo $userID;
                  $fromParent = $userID;

                  $query = "select * from forsage_event_levelbuy where buyer in ( select userWallet from forsage_event_reglevel where userID = ".$fromParent." and plan='x6' ) order by level ASC ";
                  $result = mysqli_query($conn,$query);

                  $row = mysqli_fetch_all($result);
                  $coi = count($row);
                  if(!empty($row)){
                  for($i=0;$i<12;$i++){

                  if($i<$coi){
                  ?>

                                        <div class="binary">
                        <a href="<?php echo SITE_URL.'dashboard/?page/x4/'.$j.'/'.$userID;?>" class="binary-root matrix-root__active ">
                                                        <span class="matrix-level matrix-level__active " <?php
                        if($i+1==1){if(!empty($first_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==2){ if(!empty($second_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==3){ if(!empty($third_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==4){ if(!empty($four_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==5){ if(!empty($fiv_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==6){ if(!empty($six_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==7){ if(!empty($seven_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==8){ if(!empty($eight_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }
                        if($i+1==9){ if(!empty($nine_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";}}
                        if($i+1==10){ if(!empty($ten_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";}}
                        if($i+1==11){ if(!empty($eleven_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";}}
                        if($i+1==12){ if(!empty($twelve_array_x4)){ echo "class='matrix-level matrix-level__active '";}else { echo "class='binary-root matrix-root__nonactive  '";} }

                        ?>>
                                  <?php echo $i+1;?>                              </span>
                            <span class="matrix-price">
                                <?php
                     if($i+1==1){ echo '0.03';}
                      if($i+1==2){ echo '0.06';}
                      if($i+1==3){ echo '0.12';}
                      if($i+1==4){ echo '0.24';}
                      if($i+1==5){ echo '0.48';}
                      if($i+1==6){ echo '0.96';}
                      if($i+1==7){ echo '1.92';}
                      if($i+1==8){ echo '3.84';}
                      if($i+1==9){ echo '7.68';}
                      if($i+1==10){ echo '15.36';}
                      if($i+1==11){ echo '30.72';}
                      if($i+1==12){ echo '61.44';}
                      ?>                            </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__overflow ">
                                                                <a
                                    href=""
                                    title="UID: 139                                ">
                                    &nbsp;
                                </a>
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                        <div class="matrix_partners__count">
                                <span>
                                      <?php
                           if($i+1==1){if(!empty($first_array_x4)){ echo count($first_array_x4);}else { echo '0';} }
                           if($i+1==2){ if(!empty($second_array_x4)){ echo count($second_array_x4);}else { echo '0';} }
                           if($i+1==3){ if(!empty($third_array_x4)){ echo count($third_array_x4);}else { echo '0';} }
                           if($i+1==4){ if(!empty($four_array_x4)){ echo count($four_array_x4);}else { echo '0';} }
                           if($i+1==5){ if(!empty($fiv_array_x4)){ echo count($fiv_array_x4);}else { echo '0';} }
                           if($i+1==6){ if(!empty($six_array_x4)){ echo count($six_array_x4);}else { echo '0';} }
                           if($i+1==7){ if(!empty($seven_array_x4)){ echo count($seven_array_x4);}else { echo '0';} }
                           if($i+1==8){ if(!empty($eight_array_x4)){ echo count($eight_array_x4);}else { echo '0';} }
                           if($i+1==9){ if(!empty($nine_array_x4)){ echo count($nine_array_x4);}else { echo '0';}}
                           if($i+1==10){ if(!empty($ten_array_x4)){ echo count($ten_array_x4);}else { echo '0';}}
                           if($i+1==11){ if(!empty($eleven_array_x4)){ echo count($eleven_array_x4);}else { echo '0';}}
                           if($i+1==12){ if(!empty($twelve_array_x4)){ echo count($twelve_array_x4);}else { echo '0';} }

                           ?>                                 </span>
                                <i class="matrix-icon_users"></i>
                            </div>
                            <div class="matrix_reinvest">
                                <span>
                                    0                                </span>
                                <i class="matrix-icon_sync"></i>
                            </div>
                                                    </div>
                    </div>
					 <?php  }else{ ?>

					    <div class="binary">
                        <a  class="binary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="2"
                                data-level="3"
                                data-matrix_price="0.1"
                                onclick="buyLevel(<?php echo $i+1;?>)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                <?php echo $i+1;?>                           </span>
                            <span class="matrix-price">
                                <?php
                     if($i+1==1){ echo '0.03';}
                      if($i+1==2){ echo '0.06';}
                      if($i+1==3){ echo '0.12';}
                      if($i+1==4){ echo '0.24';}
                      if($i+1==5){ echo '0.48';}
                      if($i+1==6){ echo '0.96';}
                      if($i+1==7){ echo '1.92';}
                      if($i+1==8){ echo '3.84';}
                      if($i+1==9){ echo '7.68';}
                      if($i+1==10){ echo '15.36';}
                      if($i+1==11){ echo '30.72';}
                      if($i+1==12){ echo '61.44';}
                      ?>                                </span>
                                                                                </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>

					 <?php }
                  }
                  }else{ for($i=0;$i<12;$i++){ ?>
				     <div class="binary">
                        <a class="binary-root matrix-root__nonactive ">
                                                        <i
                                class="matrix-icon_cart matrix-icon_cart__big "
                                data-matrix="2"
                                data-level="3"
                                data-matrix_price="0.1"
                                onclick="buyLevel(<?php echo $i+1;?>)"
                                title="Buy"
                            ></i>
                                                        <span class="matrix-level matrix-level__nonactive ">
                                <?php echo $i+1;?>                           </span>
                            <span class="matrix-price">
                                <?php
                     if($i+1==1){ echo '0.03';}
                      if($i+1==2){ echo '0.06';}
                      if($i+1==3){ echo '0.12';}
                      if($i+1==4){ echo '0.24';}
                      if($i+1==5){ echo '0.48';}
                      if($i+1==6){ echo '0.96';}
                      if($i+1==7){ echo '1.92';}
                      if($i+1==8){ echo '3.84';}
                      if($i+1==9){ echo '7.68';}
                      if($i+1==10){ echo '15.36';}
                      if($i+1==11){ echo '30.72';}
                      if($i+1==12){ echo '61.44';}
                      ?>                                                              </a>
                        <div class="binary-children binary-children_level__1">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-children binary-children_level__2">
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                        <div class="matrix-children__nonactive ">
                                                            </div>
                                                    </div>
                        <div class="binary-branchs">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="matrix-break"></div>
                        <div class="matrix-info">
                                                    </div>
                    </div>


				  <?php }
				  } ?>




								  </div><!-- end: ternary-wrapper -->
            </div><!-- end: border-gradient_content -->
        </div><!-- end: border-gradient -->
    </div><!-- end: col -->
</div><!-- end: row -->


<div class="row icon-tips text-left mt-3 margin-bottom-70">
    <div class="col-md-5">
        <div>
            <i class="matrix-single matrix-children__active"></i>
            <span class="icon-tips_text">PARTNER INVITED BY YOU</span>
        </div>
        <div>
            <i class="matrix-single matrix-children__overflow"></i>
            <span class="icon-tips_text">OVERFLOW FROM UP</span>
        </div>
    </div>
    <div class="col-md-6">
        <div>
            <i class="matrix-single matrix-children__overflow_partner"></i>
            <span class="icon-tips_text">BOTTOM OVERFLOW</span>
        </div>
        <div>
            <i class="matrix-single matrix-children__advance"></i>
            <span class="icon-tips_text">PARTNER WHO IS AHEAD OF HIS INVITER</span>
        </div>
    </div>
</div>
        </div>
    </div>
</div>
</div>


<script>
var config = {
    site: {
        domain:   location.hostname,
        protocol: location.protocol + '//',
        hostname: location.hostname,
        //link: 'https://lk.forsage.io/',
        link: '<?php echo SITE_URL;?>',
        course: {
            value: `ETH_USD`,
            symbol: `$`,
        },
    },
    user: {
        refkey: 'vpat19',
        address: '0x948e5f339942f9f6cf417c5fe6de73ef6059bd8b',
        isAuthSecure: false,
        sid: '2b2fd7148b32c82b6c700573550e5ffe',
    },
    lang: {
        /* contract.js */
        buyLevel                 : `Confirm the purchase`,
        notDetectedWallet        : `The Ethereum wallet is Not detected on your browser.`,
        unblockWallet            : `Unlock the wallet for a transaction`,
        notActiveWallet          : `Ethereum wallet is not active`,
        errorSendingTransaction  : `Error sending transaction: `,
        transactionSend          : `The transaction has been sent! Please wait for confirmation of the network.`,
        confirmTransaction       : `Confirm the transaction in your Ethereum wallet`,
        errorReadSmartContract   : `Read error SmartContract`,
        uplineNotRegistered      : `Your upline is not registered`,
        userNotExists            : `The user is not registered`,
        authError                : `Authorization error`,

        /* common.js */
        copied                   : `Copied`,

        // Сокеты события
        'ws-regLevel_0'          : `Joined ID:{user_id}`,
        'ws-regLevel_1'          : `Joined ID:{user_id}. You are on the right way!`,
        'ws-regLevel_2'          : `Meet the new member ID:{user_id}.`,
        'ws-regLevel_3'          : `New user ID:{user_id}. Welcome to Forsage!`,
        'ws-newUserPlace'        : `ID:{user_id} earned {price_level} {crypto_name} (\${currency_usd}) in the {matrix}`,
        'ws-upgrade'             : `ID:{user_id} buy {level} slot in {matrix} from ID:{ref_id}.`,
        'ws-reinvest'            : `ID:{user_id} was auto-reinvested in slot {level} ({matrix})`,
        'ws-missedEthReceive'    : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}). You must perform the upgrade in ({matrix})`,
        'ws-sentExtraEthDividends':`ID:{user_id} received a bonus {price_level} {crypto_name} (\${currency_usd})`,
        'ws-cannotSendMoneyEvent': `ID:{user_id} error getting translation`,
        'ws-leadingPartner'      : `ID:{user_id} missed profit {price_level} {crypto_name} (\${currency_usd}) from (ID:{u_id}) for area # {level} ({matrix})`,
        'ws-leadingPartnerToUpline':`ID:{u_id} overtook its parent ID is:{user_id} in the matrix {matrix} with area # {level}`,
        'ws-leadingPlacePurchase': `ID:{user_id} ahead of your inviter (ID:{up_id}) for area # {level} ({matrix})`,

        // Скрипт с выводом даты отсчета времени
        'elt-years_0'            : `year`,
        'elt-years_1'            : `year`,
        'elt-years_2'            : `years`,
        'elt-months_0'           : `a month`,
        'elt-months_1'           : `months`,
        'elt-months_2'           : `months`,
        'elt-days_0'             : `day`,
        'elt-days_1'             : `day`,
        'elt-days_2'             : `days`,
        'elt-hours_0'            : `hour`,
        'elt-hours_1'            : `hours`,
        'elt-hours_2'            : `hours`,
        'elt-minutes_0'          : `min`,
        'elt-minutes_1'          : `min`,
        'elt-minutes_2'          : `min`,
        'elt-minutes_3'          : `a minute`,
        'elt-seconds_0'          : `second`,
        'elt-seconds_1'          : `seconds`,
        'elt-seconds_2'          : `seconds`,
        'elt-seconds_3'          : `second`,
        'elt-end'                : ` ago`,
        'elt-freshly'            : `just`,
        'elt-deadline'           : `time left`,
        'elt-after'              : `through `,
    },
    locked: {
        buyLevel      : ``,
        authorization : ``,
        registration  : ``,
    },
    permissions: {
        buyLevel      : `0`,
    },
    isFramed: null,
    isMobile: false,
    haveWallet: window.ethereum || window.web3,
};

// Получить основной домен
let arr = config.site.domain.split('.');
if(arr.length > 2) {
    config.site.domain = arr.slice(arr.length - 2).join('.')
}

// Запущен ли сайт в теге iframe
try {
  config.isFramed = window != window.top || document != top.document || self.location != top.location;
} catch (e) {
  config.isFramed = true;
}
</script>
<script src="assets_s/Decentralized/js/jquery.min.js"></script>
<script src="assets_s/Decentralized/js/vue.min.js"></script>
<script src="assets_s/Decentralized/js/socket.io.js"></script>
<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
<script src="assets_s/Decentralized/js/common.js"></script>
<script src="assets_s/Decentralized/js/contract.js"></script>
<script src="assets_s/Decentralized/js/cabinet.js"></script><div class="require-auth">
    Purchase in preview mode is not available! Please please login with your Ethereum wallet.<br>
    <br>
    <div>
                    <button class="btn btn-success" id="reauth">
                Authorization            </button>
            </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(57866482, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        ecommerce:"dataLayer"
   });
</script>
<noscript><div><img src="https://mc.yandex.ru/watch/57866482" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->


<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
<script type="text/javascript">

var web3 = new Web3(Web3.givenProvider || "<?=$infuraAPI; ?>");

var arrayABI = <?=$mainContractABI; ?>;

var mainContractAddress = "<?=$mainContractAddress; ?>";

var myAccountAddress = "<?=$userWallet;?>";

if (typeof web3 !== 'undefined'){

var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
    from: myAccountAddress, // default from address
    });






// fetching user level
fetchRemainingTime(myAccountAddress);
async function fetchRemainingTime(myAccountAddress){

    var remainingDay = await myContract.methods.viewTimestampSinceJoined(myAccountAddress).call({from: myAccountAddress});

    for (var i = 0; i < remainingDay.length; i++) {

    var priceOfLevel = await myContract.methods.priceOfLevel(i+1).call({from: myAccountAddress});
    document.getElementById("buyAmountData"+[i]).textContent = (priceOfLevel / 1000000000000000000)+" ETH";

        if(remainingDay[i] > 0){


            //change ribbon color
            document.getElementById("ribbonColor"+[i]).classList.add('ribbon-success');
            document.getElementById("ribbonColor"+[i]).classList.remove('ribbon-danger');


            //change the ribbon name
            document.getElementById("ribbonName"+[i]).textContent="Active";


            //change $ amount color
            document.getElementById("buyAmountData"+[i]).classList.add('text-success');
            document.getElementById("buyAmountData"+[i]).classList.remove('text-danger');
            document.getElementById("buyAmountData"+[i]).classList.remove('pb-30');





            //remaining days
            document.getElementById("remainingDays"+[i]).textContent="Remain Days: "+ (remainingDay[i] / 86400).toFixed(0);

            //button change
            document.getElementById("levelButton"+[i]).classList.add('btn-success');
            document.getElementById("levelButton"+[i]).classList.remove('btn-danger');
            document.getElementById("levelButton"+[i]).textContent="EXTEND 100 DAYS";

        }
    }
}

}   //web3 check




</script>


<script type="text/javascript">
       $('input[type="checkbox"]').click(function(){
          if($(this).prop("checked") == true){
             console.log("true");
             window.location.href='<?php SITE_URL?>dashboard/';
             // $.cookie("togglechecked", "true");
             localStorage.setItem("checkbox", "true");

          }

          else if($(this).prop("checked") == false){
             window.location.href='<?php SITE_URL?>dashboard/?s_dashboard';
             console.log("false");
          }
      });

</script>





</script>

<?php
//include('information_ethbullx3.php');
?>

</body>
</html>
<?php
include('footer.php');
?>
