<?php
$page = "forsage_dashboard";
include('top_navbar.php');
include('sidebar.php');
include('core/forsage_dashboard.php');


?>

<link rel="stylesheet" href="assets/css/alertify.min.css">

<script type="text/javascript" src="core/js/dashboard.js" crossorigin="anonymous">
	
</script>

  <!-- Page -->
  <div class="page">
    
  </div>
	  
	  
    </div>
  </div>
  <!-- End Page -->


  
<?php
include('footer.php');
?>

<script src="assets/js/alertify.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
<script type="text/javascript">

var web3 = new Web3(Web3.givenProvider || "https://mainnet.infura.io/v3/6f8dc3b58cd345cd9a6589821d2c131c");

var arrayABI = <?=$mainContractABI; ?>;

var mainContractAddress = "<?=$mainContractAddress; ?>";

var myAccountAddress = "<?=$userWallet;?>";

if (typeof web3 !== 'undefined'){

var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
	from: myAccountAddress, // default from address
	});






// fetching user level
fetchRemainingTime(myAccountAddress);
async function fetchRemainingTime(myAccountAddress){

	var remainingDay = await myContract.methods.viewTimestampSinceJoined(myAccountAddress).call({from: myAccountAddress});

	for (var i = 0; i < remainingDay.length; i++) {
		
		if(remainingDay[i] > 0){

			
			//change ribbon color
			document.getElementById("ribbonColor"+[i]).classList.add('ribbon-success');
			document.getElementById("ribbonColor"+[i]).classList.remove('ribbon-danger');	


			//change the ribbon name
			document.getElementById("ribbonName"+[i]).textContent="Active";


			//change $ amount color
			document.getElementById("buyAmountData"+[i]).classList.add('text-success');
			document.getElementById("buyAmountData"+[i]).classList.remove('text-danger');
			document.getElementById("buyAmountData"+[i]).classList.remove('pb-30');


			


			//remaining days
			document.getElementById("remainingDays"+[i]).textContent="Remain Days: "+ (remainingDay[i] / 86400).toFixed(0);

			//button change
			document.getElementById("levelButton"+[i]).classList.add('btn-success');
			document.getElementById("levelButton"+[i]).classList.remove('btn-danger');
			document.getElementById("levelButton"+[i]).textContent="EXTEND 100 DAYS";
			
		}
	}
}

}	//web3 check




</script>


<script type="text/javascript" src="core/js/dashboard.footer.js">

	
</script>
