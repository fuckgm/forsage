<?php
include('config.php');

 if(isset($_GET['user']) && $_GET['user']!=""){
 	$user 	= $_GET['user'];
 	$query 	= "SELECT userID FROM event_reglevelev where userWallet='".clean($user)."' ";
	$result = mysqli_query($conn,$query);
	if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result);
    	$json_result['result']= true;
    	$json_result['userid'] = $row['userID'];
    	http_response_code(200);
    	echo json_encode($json_result);
    	exit();         
    }else{
    	$query 	= "SELECT MAX(userID) as userID FROM event_reglevelev";
		$result = mysqli_query($conn,$query);
		if(mysqli_num_rows($result)>0){
        	$row = mysqli_fetch_array($result);
        	$json_result['result']= true;
    		$json_result['userid'] = $row['userID']+1;
    		http_response_code(200);
    		echo json_encode($json_result);
    		exit();        
        }
    }

 }else{
 		$json_result['result']= false;
 		$json_result['message']= 'invalid user id provided';
     	http_response_code(200);
     	echo json_encode($json_result);
     	exit();         
 }
?>