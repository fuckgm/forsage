<?php
$page = "Uplines";
include('top_navbar.php');
include('sidebar.php');

?>

 

  <!-- Page -->
  <div class="page">
	<div class="page-content container-fluid">
		<div class="row" data-plugin="matchHeight" data-by-row="true">
		<div class="col-xxl-12 col-lg-12 pb-10" style="">
			<!-- TradingView Widget BEGIN -->
				<div class="tradingview-widget-container">
				  <div class="tradingview-widget-container__widget"></div>
				  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
				  {
				  "symbols": [
					{
					  "proName": "BITSTAMP:BTCUSD",
					  "title": "BTC/USD"
					},
					{
					  "proName": "BITSTAMP:ETHUSD",
					  "title": "ETH/USD"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHPAX"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHBTC"
					}
				  ],
				  "colorTheme": "light",
				  "isTransparent": false,
				  "displayMode": "adaptive",
				  "locale": "in"
				}
				  </script>
				</div>
<!-- TradingView Widget END -->
			  
			</div>
		
		<div class="col-xxl-12 col-lg-12 col-sm-12" style="">
		  <div class="panel" id="projects">
            <div class="panel-heading">
              <h3 class="panel-title">Uplines</h3>
            </div>
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <td>Line</td>
                    <td>User ID</td>
                    <td>Wallet Address</td>
                    <td>Buy Level</td>
                  </tr>
                </thead>
                <tbody>


<?php



//find first level upline referrer
$query = "SELECT * FROM event_reglevelev where userID='".clean($userID)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$uplineID;
if($row != NULL && $row > 0){
	$row1 = $result -> fetch_assoc();
	$uplineID = $row1['referrerID'];
}

for($i=0; $i<10; $i++){


$query = "SELECT * FROM event_reglevelev where userID='".$uplineID."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
if($row != NULL && $row > 0){
	$row1 = $result -> fetch_assoc();

//find buy level of upline
$query = "SELECT level FROM event_levelbuyev where buyer='".$row1['userWallet']."' order by level desc limit 0,1 ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$buyLevel=0;
if($row != NULL && $row > 0){
	$row2 = $result -> fetch_assoc();
	$buyLevel = $row2['level'];
}

echo '

						<tr role="row" class="odd">
							<td> '.($i+1).'</td>
							<td>'.$uplineID.'</td>
							<td>
							<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
							</td>
							<td>'.$buyLevel.'</td>	
						</tr>

';

$uplineID = $row1['referrerID'];


}



}
?>

						
		

					</tbody>
              </table>
            </div>
          </div>
		</div>

        </div>
    </div>
	
  </div>
  <!-- End Page -->

<?php
include('footer.php');
?>