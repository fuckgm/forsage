<?php
$page = "Partner";
include('top_navbar.php');
include('sidebar.php');


?>

 

  <!-- Page -->
  <div class="page">
	<div class="page-content container-fluid">
		<div class="row" data-plugin="matchHeight" data-by-row="true">
		<div class="col-xxl-12 col-lg-12 pb-10" style="">
			<!-- TradingView Widget BEGIN -->
				<div class="tradingview-widget-container">
				  <div class="tradingview-widget-container__widget"></div>
				  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
				  {
				  "symbols": [
					{
					  "proName": "BITSTAMP:BTCUSD",
					  "title": "BTC/USD"
					},
					{
					  "proName": "BITSTAMP:ETHUSD",
					  "title": "ETH/USD"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHPAX"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHBTC"
					}
				  ],
				  "colorTheme": "light",
				  "isTransparent": false,
				  "displayMode": "adaptive",
				  "locale": "in"
				}
				  </script>
				</div>
<!-- TradingView Widget END -->
			  
			</div>
		<div class="col-xxl-12 col-lg-6 col-sm-6" style="">
		  <div class="card card-shadow card-completed-options text-white">
			<div class="card-block p-25">
			<div class="panel-heading">
              <h4 class=""><?=$$lang['Your Affiliate Link'];?></h4>
            </div>
			 <div class="row">
				<div class="col-xxl-12 col-lg-9 ">
				  <div class="example-wrap mb-10">
				
					<input id="myRefLink" type="text" class="form-control focus"  value="<?php echo SITE_URL;?>?a=<?=$userID;?>" >
				  </div>
				</div>
				<div class="col-xxl-12 col-lg-3">
					<button onclick="myFunctionCopy()" type="button" class="btn btn-block btn-primary waves-effect waves-classic mb-10"><i class="icon fa-copy" aria-hidden="true"></i> <span id="copyButton">Copy</span></button>
				</div>
			</div>
			</div>
		  </div>
		</div>
		
		<div class="col-xxl-12 col-lg-6 col-sm-6" style="">
		  <div class="card card-shadow card-completed-options text-white">
			<div class="card-block p-25">
			<div class="panel-heading">
              <h4 class=""><?=$$lang['Link for redirect to the Trust Wallet Dapp Browser'];?></h4>
            </div>
			 <div class="row">
				<div class="col-xxl-12 col-lg-9 ">
				  <div class="example-wrap mb-10">
					<input type="text" class="form-control focus" id="trustWalletLinkCopy" value="https://link.trustwallet.com/open_url?coin_id=60&url=https://ethbull.io?a=<?=$userID;?>" >
				  </div>
				</div>
				<div class="col-xxl-12 col-lg-3">
					<button onclick="myFunctionCopy2()" type="button" class="btn btn-block btn-primary waves-effect waves-classic mb-10"><i class="icon fa-copy" aria-hidden="true"></i> <span id="copyButton2">Copy</span> </button>
				</div>
			</div>
			</div>
		  </div>
		</div>
		
	

        </div>
	<div class="panel">
	<header class="panel-heading">
		<div class="panel-actions"></div>
		<h3 class="panel-title">Your Downline Partners</h3>
	</header>
	<div class="panel-body">
	<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
			<div class="row">
				<div class="col-sm-12">
					<table class="table table-hover dataTable table-striped w-full dtr-inline" data-plugin="dataTable" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="width: 1014px;">
						<thead>
							<tr role="row">
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 73.992px;" aria-label="Salary: activate to sort column ascending">User ID</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-label="Position: activate to sort column ascending">Level</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 184.992px;" aria-label="Office: activate to sort column ascending">Wallet Address</th>
								<th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Date Joined</th>

												
							</tr>
						</thead>
						<tbody>



<?php

function fetchDownlines($userID, $conn, $level=0){

$query = "SELECT * FROM event_reglevelev where referrerID='".clean($userID)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);
$tempArray = array();
if($row != NULL && $row > 0){
	while ($row1 = $result -> fetch_assoc()) {
		array_push($tempArray,$row1['userID']);


echo'

							<tr role="row" class="odd">
								
								<td>'.$row1['userID'].'</td>
								<td>'.$level.'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row1['userWallet'].'" target="new"> '.$row1['userWallet'].' </a>
								</td>
								<td>'.date('m/d/Y', $row1['timestamp']).'</td>
								
								
							</tr>

';


	}
}
return $tempArray;
}





//Toal partners - all levels

$mainArray = array();
$level1Array = array();

//level 1 referrals
$tempArray2 = fetchDownlines($userID, $conn, 1);

if(count($tempArray2) > 0){
	$mainArray = array_merge($mainArray, $tempArray2);
	$level1Array = $tempArray2;

		//These are level 1 refs
		foreach ($tempArray2 as $key) {

			//level 2 referrals
			$tempArray2 = fetchDownlines($key, $conn, 2);

			if(count($tempArray2) > 0){

				$mainArray = array_merge($mainArray, $tempArray2);
				//These are level 2 refs
				foreach ($tempArray2 as $key) {

					//level 2 referrals
					$tempArray2 = fetchDownlines($key, $conn, 3);

					//level 3 referrals
					if(count($tempArray2) > 0){
						
						$mainArray = array_merge($mainArray, $tempArray2);

							//level 4
							foreach ($tempArray2 as $key) {

								$tempArray2 = fetchDownlines($key, $conn, 4);
								
								//level 4 referrals
								if(count($tempArray2) > 0){
									
									$mainArray = array_merge($mainArray, $tempArray2);


										//level 5
										foreach ($tempArray2 as $key) {

										$tempArray2 = fetchDownlines($key, $conn, 5);
										
										//level 5 referrals
										if(count($tempArray2) > 0){
											
											$mainArray = array_merge($mainArray, $tempArray2);



//level 6
foreach ($tempArray2 as $key) {

$tempArray2 = fetchDownlines($key, $conn, 6);

//level 6 referrals
if(count($tempArray2) > 0){
	
	$mainArray = array_merge($mainArray, $tempArray2);

	//level 7
	foreach ($tempArray2 as $key) {

	$tempArray2 = fetchDownlines($key, $conn, 7);

	//level 7 referrals
	if(count($tempArray2) > 0){
		
		$mainArray = array_merge($mainArray, $tempArray2);


		//level 8
		foreach ($tempArray2 as $key) {

		$tempArray2 = fetchDownlines($key, $conn, 8);

		//level 8 referrals
		if(count($tempArray2) > 0){
			
			$mainArray = array_merge($mainArray, $tempArray2);


			//level 9
			foreach ($tempArray2 as $key) {

			$tempArray2 = fetchDownlines($key, $conn, 9);

			//level 9 referrals
			if(count($tempArray2) > 0){
				
				$mainArray = array_merge($mainArray, $tempArray2);


				//level 10
				foreach ($tempArray2 as $key) {

				$tempArray2 = fetchDownlines($key, $conn, 10);

				//level 10 referrals
				if(count($tempArray2) > 0){
					
					$mainArray = array_merge($mainArray, $tempArray2);






				}//level 10 if condition


				}	//level 10 foreach



			}//level 9 if condition


			}	//level 9 foreach



		}//level 8 if condition


		}	//level 8 foreach



	}//level 7 if condition


	}	//level 7 foreach




}//level 6 if condition


}	//level 6 foreach




										}//level 5 if condition


									}	//level 5 foreach


								}//level 4 if condition


							}	//level 4 foreach


					}//level 3 if condition


				}	//level 3 foreach


			}//level 2 if condition


		}	//level 2 foreach



}	// level 1 if condition
$totalPartners = count($mainArray);
$level1Partners = count($level1Array);


?>




							

							
						</tbody>
					</table>
				</div>
			</div>
		
	</div>
	
	
	
		
		
	</div>
</div>



	<div class="panel">
	<header class="panel-heading">
		<div class="panel-actions"></div>
		<h3 class="panel-title">Commission Received</h3>
	</header>
	<div class="panel-body">
	<div id="DataTables_Table_0_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
			<div class="row">
				<div class="col-sm-12">
					<table class="table table-hover dataTable table-striped w-full dtr-inline" data-plugin="dataTable" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info" style="width: 1014px;">
						<thead>
							<tr role="row">
								<th class="sorting_asc" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Date</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 73.992px;" aria-label="Salary: activate to sort column ascending">User ID</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 184.992px;" aria-label="Office: activate to sort column ascending">From whom</th>
								<th class="sorting" tabindex="0" aria-controls="DataTables_Table_0" rowspan="1" colspan="1" style="width: 211.992px;" aria-label="Position: activate to sort column ascending">ETH Received</th>
								
								
							</tr>
						</thead>
						<tbody>


<?php
$query = "SELECT * FROM event_paidforlevelev where referrer='".clean($userWallet)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_num_rows($result);

if($row != NULL && $row > 0){
$row1 = $result -> fetch_all();

	foreach($row1 as $row2) {

		//find user id of this user
		$query = "SELECT * FROM event_reglevelev where userWallet='".$row2[1]."' ";
		$result = mysqli_query($conn,$query);
		$referralID = $result -> fetch_assoc();



echo '
							<tr role="row" class="odd">
								<td>'.date('m/d/Y', $row2[5]).'</td>
								<td>'.$referralID['userID'].'</td>
								<td>
								<a href="https://etherscan.io/address/'.$row2[1].'" target="new"> '.$row2[1].' </a>
								</td>
								<td>'.($row2[4] / 1000000000000000000).'</td>
								
								
								
								
							</tr>
';
}
}


?>							
						</tbody>
					</table>
				</div>
			</div>
		
	</div>
	
	
	
		
		
	</div>
</div>




    </div>
	
  </div>
  <!-- End Page -->



<script type="text/javascript">
	function myFunctionCopy() {
		var copyText = document.getElementById("myRefLink");
		  copyText.select();
		  copyText.setSelectionRange(0, 99999)
		  document.execCommand("copy");
		  document.getElementById("copyButton").textContent="Copied";

      }
      function myFunctionCopy2() {
		var copyText = document.getElementById("trustWalletLinkCopy");
		  copyText.select();
		  copyText.setSelectionRange(0, 99999)
		  document.execCommand("copy");
		  document.getElementById("copyButton2").textContent="Copied";

      }


      
</script>


<?php
include('footer.php');
?>


