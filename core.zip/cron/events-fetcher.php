<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect('localhost','ethbullio', 'ethbull.io$$','ethbullio');

$mysqli = $conn;

$ch = curl_init();  
 
    curl_setopt($ch,CURLOPT_URL,"http://localhost:8080");
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
//  curl_setopt($ch,CURLOPT_HEADER, false); 
 
    $output=curl_exec($ch);
 
    curl_close($ch);

    $output = json_decode($output);

//echo "tyyy";
//var_dump($output);

$query = "select `blockNumber` from `event_blocks_synced`  ORDER BY `blockNumber` DESC limit 0,1";
$q = mysqli_query( $mysqli, $query ) or die(mysqli_error($mysqli));
$x = mysqli_fetch_row($q);
$lastBlock = 0;
if($x!=null){
    $lastBlock = $x[0];
}

//print "Last Block..".$lastBlock."<br/>";


$tracker=true;
foreach ($output as $raw) {
//print $raw->blockNumber."<br/>";
if($raw->blockNumber > $lastBlock){


//it also updates the ether's USD price in database. It should run only once
if($tracker){

//ether's USD price
$handle = curl_init();
$url = "https://api.etherscan.io/api?module=stats&action=ethprice";
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true); 
$output = curl_exec($handle);
curl_close($handle);
$ethPrice = json_decode($output)->result->ethusd;
//updating the admin setting table
$query = "UPDATE adminsetting SET ethPiceInUsd=".$ethPrice;
mysqli_query( $mysqli, $query ) or die(mysqli_error($mysqli));


//updating gas price from ethgasstation.info
$handle = curl_init();
$url = "https://ethgasstation.info/json/ethgasAPI.json";
// Set the url
curl_setopt($handle, CURLOPT_URL, $url);
// Set the result output to be a string.
curl_setopt($handle, CURLOPT_RETURNTRANSFER, true); 
$output = curl_exec($handle);
curl_close($handle);
$gasPriceAverage = json_decode($output)->average / 10;
$gasPriceFastest = json_decode($output)->fastest / 10;
//updating the admin setting table
$query = "UPDATE adminsetting SET gasPriceAverage=".$gasPriceAverage.", gasPriceFast=".$gasPriceFastest;
mysqli_query( $mysqli, $query ) or die(mysqli_error($mysqli));


//tracker so this does not run in other loop iteration
$tracker=false;
}








$query = "INSERT INTO `event_blocks_synced` (blockNumber) VALUES ('".$raw->blockNumber."');";
mysqli_query( $mysqli, $query ) or die(mysqli_error($mysqli));
//var_dump($raw);

    if($raw->event == 'levelBuyEv'){

        $query = "INSERT INTO `event_levelbuyev` (buyer, level, amount, timestamp)";
        $query .= " VALUES ('".$raw->returnValues->_user."','".$raw->returnValues->_level."','".$raw->returnValues->_amount."','".$raw->returnValues->_time."');";
        //print $query."<br/>";
        mysqli_query( $mysqli, $query ) or die("ErroR..".mysqli_error($mysqli));

    }
    elseif($raw->event == 'lostForLevelEv'){

        $query = "INSERT INTO `event_lostforlevelev` (referrer, buyer, level, amount, timestamp)";
        $query .= " VALUES ('".$raw->returnValues->_user."', '".$raw->returnValues->_referral."', '".$raw->returnValues->_level."','".$raw->returnValues->_amount."','".$raw->returnValues->_time."');";
        //print $query."<br/>";
        mysqli_query( $mysqli, $query ) or die("ERRoor...".mysqli_error($mysqli));

    }

    elseif($raw->event == 'paidForLevelEv'){

        $query = "INSERT INTO `event_paidforlevelev` (referrer, buyer, level, amount, timestamp)";
        $query .= " VALUES ('".$raw->returnValues->_user."', '".$raw->returnValues->_referral."', '".$raw->returnValues->_level."','".$raw->returnValues->_amount."','".$raw->returnValues->_time."');";
        //print $query."<br/>";
        mysqli_query( $mysqli, $query ) or die("ERROOr..".mysqli_error($mysqli));

    }

 
    elseif($raw->event == 'regLevelEv'){

        $query = "INSERT INTO `event_reglevelev` (userID,  userWallet, referrerID, originalReferrer, timestamp)";
        $query .= " VALUES ('".$raw->returnValues->_userID."','".$raw->returnValues->_userWallet."', '".$raw->returnValues->_referrerID."','".$raw->returnValues->_originalReferrer."','".$raw->returnValues->_time."');";
        //print $query."<br/>";
        mysqli_query( $mysqli, $query ) or die(mysqli_error($mysqli));

    }



}
}