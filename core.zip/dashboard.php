<?php
$page = "Dashboard";
include('top_navbar.php');
include('sidebar.php');
include('core/e_dashboard_curl.php');


?>

<link rel="stylesheet" href="assets/css/alertify.min.css">

<script type="text/javascript" src="core/js/dashboard.js" crossorigin="anonymous">
	
</script>

  <!-- Page -->
  <div class="page">
    <div class="page-content container-fluid">
		<div class="row" data-plugin="matchHeight" data-by-row="true">
			<div class="col-xl-12 col-lg-12 col-sm-12 pb-10" style="">
			<!-- TradingView Widget BEGIN -->
				<div class="tradingview-widget-container">
				  <div class="tradingview-widget-container__widget"></div>
				  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
				  {
				  "symbols": [
					{
					  "proName": "BITSTAMP:BTCUSD",
					  "title": "BTC/USD"
					},
					{
					  "proName": "BITSTAMP:ETHUSD",
					  "title": "ETH/USD"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHPAX"
					},
					{
					  "description": "",
					  "proName": "BINANCE:ETHBTC"
					}
				  ],
				  "colorTheme": "light",
				  "isTransparent": false,
				  "displayMode": "adaptive",
				  "locale": "in"
				}
				  </script>
				</div>
<!-- TradingView Widget END -->
			  
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-white">
				<div class="card-block p-25 card-bg-2 ">
				  <div class="row">
					<div class="col-7 pr-0">
					  <div class="counter text-left">
						<div class="font-size-18 mt-5"><?=$$lang['Level Profits']; ?>
						</div>
						<div class="font-size-24 mt-5"> <?php echo $levelProfit; ?> ETH
						</div>
					  </div>
					</div>
					<div class="col-5 pr-0">
						<a class="float-right" href="">
						<img class="card-img"src="global/img/team.png" alt="">
						</a>
					</div>
				  </div>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-white">
				<div class="card-block p-25 card-bg-1 ">
				  <div class="row">
					<div class="col-7 pr-0">
					  <div class="counter text-left">
						<div class="font-size-18 mt-5"><?=$$lang['Total Earned']; ?>
						</div>
						<div class="font-size-24 mt-5">$ <?php echo number_format((float)($totalEarned*$ethPrice), 2, '.', ''); ?>
						</div>
					  </div>
					</div>
					<div class="col-5 pr-0">
						<a class="float-right" href="">
						<img class="card-img"src="global/img/hand.png" alt="">
						</a>
					</div>
				  </div>
				</div>
			  </div>
			</div>
			
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-white">
				<div class="card-block p-25 card-bg-6 ">
				  <div class="row">
					<div class="col-7 pr-0 ">
					  <div class="counter text-left">
						<div class="font-size-18 mt-5"><?=$$lang['Uni Level']; ?>
						</div>
						<div class="font-size-24 mt-5"> <?php echo $totalPartners; ?>
						</div>
					  </div>
					</div>
					<div class="col-5 pr-0">
						<a class="float-right" href="">
						<img class="card-img"src="global/img/support.png" alt="">
						</a>
					</div>
				  </div>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-white">
				<div class="card-block p-25 card-bg-3 ">
				  <div class="row">
					<div class="col-7 pr-0 ">
					  <div class="counter text-left">
						<div class="font-size-18 mt-5"><?=$$lang['Pools Profits']; ?>
						</div>
						<div class="font-size-24 mt-5"> <?php echo $totalEarned; ?> ETH
						</div>
					  </div>
					</div>
					<div class="col-5 pr-0">
						<a class="float-right" href="">
						<img class="card-img"src="global/img/pools.svg" alt="">
						</a>
					</div>
				  </div>
				</div>
			  </div>
			</div>
		</div>
		<div class="row" data-plugin="matchHeight" data-by-row="true">
			<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
				<div class="row" data-plugin="matchHeight" data-by-row="true">
					
					<!-- <div class="col-xxl-12 col-lg-12">
					  <div class="card card-shadow card-completed-options text-white">
						<div class="card-block p-25 bg-blue-500 ">
						  <div class="row">
							<div class="col-7">
							  <div class="row counter text-left mx-3">
								<div class="font-size-18 mt-3"><?=$$lang['Available Fund']; ?>:
								</div>
								<div class="font-size-24 px-20 float-right">  $ <span id="availableFundAmount"> 0</span>
								</div>
								<div class="input-group">
									
									<span class="input-group-btn">
									  <button onclick="pulloutFund()" type="button" class="btn btn-primary waves-effect waves-classic">Pullout Fund</button>
									</span>
								  </div>
							  </div>
							</div>
							<div class="col-5">
								<a class="float-right" href="">
								<img class="card-img"src="global/img/cash.svg" alt="">
								</a>
							</div>
						  </div>
						</div>
					  </div>
					</div> -->
					<div class="col-xl-12 col-lg-12">
					  <!-- Widget Current Chart -->
					  <div class="card card-shadow" id="widgetCurrentChart">
						<!-- <div class="px-30 py-20 white card-bg-8 ">
						  <div class="font-size-20 mb-10"><?=$$lang['The growth of structure']; ?></div>
						  <div class="ct-chart ct-perfect-fourth h-200">
						  </div>
						</div> -->
						<div class="bg-white p-10 font-size-14">
						  <!-- TradingView Widget BEGIN -->
								<div class="tradingview-widget-container">
								  <div class="tradingview-widget-container__widget"></div>
								  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js" async>
								  {
								  "symbol": "BINANCE:ETHUSD",
								  "width": "100%",
								  "height": "100%",
								  "locale": "in",
								  "dateRange": "3m",
								  "colorTheme": "light",
								  "trendLineColor": "#37a6ef",
								  "underLineColor": "#e3f2fd",
								  "isTransparent": false,
								  "autosize": true,
								  "largeChartUrl": ""
								}
								  </script>
								</div>
						</div>
					  </div>
					  <!-- End Widget Current Chart -->
					</div>
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
				<div class="row" data-plugin="matchHeight" data-by-row="true">
					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 card-col" style="">
					  <div class="card card-shadow card-completed-options text-center text-white">
						<div class="card-block pb-0 bg-white ">
							<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor0">
							<span class="ribbon-inner" id="ribbonName0">Inactive</span>
							</div>
							  <div class="font-size-20 py-5 font-weight-800">LEVEL 1</div>
							  <div class="font-size-26 py-5 font-weight-800 text-danger pb-30" id="buyAmountData0">0.07 ETH </div>
							  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount0">Auto Pool : $200</div>
							  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays0">100 Days</div>
							  <div type="button" class="btn btn-block btn-danger waves-effect waves-classic " id="levelButton0" onclick="buyLevel(1)"  >BUY LEVEL
							  </div>
							  <p class="blue-grey-400 font-weight-100 pt-3">Active Purchases: <?php echo $totalPaidForLevels[1] + $totalLostForLevels[1]; ?></p>
						</div>
					  </div>
					</div>
					<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 card-col" style="">
					  <div class="card card-shadow card-completed-options text-center text-white">
						<div class="card-block pb-0 bg-white ">
							<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor1">
							<span class="ribbon-inner" id="ribbonName1">Inactive</span>
							</div>
							  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 2</div>
							  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData1">0.1 ETH </div>
							  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount1">Auto Pool : $200</div>
							  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays1">100 Days</div>
							  <div id="levelButton1" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(2)"> BUY LEVEL</div>
							  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[2] + $totalLostForLevels[2]; ?></p>
						</div>
					  </div>
					</div>
				</div>
			</div>
			
		</div>
		<div class="row" data-plugin="matchHeight" data-by-row="true">
				
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor2">
					<span class="ribbon-inner" id="ribbonName2">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 3</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData2"> 0.2 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount2">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays2">100 Days</div>
					  <div id="levelButton2" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(3)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[3] + $totalLostForLevels[3]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor3">
					<span class="ribbon-inner" id="ribbonName3">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 4</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData3">0.4 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount3">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays3">100 Days</div>
					  <div id="levelButton3" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(4)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[4] + $totalLostForLevels[4]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor4">
					<span class="ribbon-inner" id="ribbonName4">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 5</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData4">1 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount4">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays4">100 Days</div>
					  <div id="levelButton4" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(5)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[5] + $totalLostForLevels[5]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor5">
					<span class="ribbon-inner" id="ribbonName5">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 6</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData5">2.5 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount5">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays5">100 Days</div>
					  <div id="levelButton5" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(6)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[6] + $totalLostForLevels[6]; ?></p>
				</div>
			  </div>
			</div>
		</div>
		<div class="row" data-plugin="matchHeight" data-by-row="true">
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor6">
					<span class="ribbon-inner" id="ribbonName6">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 7</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData6">5 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount6">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays6">100 Days</div>
					  <div id="levelButton6" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(7)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[7] + $totalLostForLevels[7]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor7">
					<span class="ribbon-inner" id="ribbonName7">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 8</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData7">10 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount7">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays7">100 Days</div>
					  <div id="levelButton7" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(8)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[8] + $totalLostForLevels[8]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor8">
					<span class="ribbon-inner" id="ribbonName8">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 9</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData8">20 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount8">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays8">100 Days</div>
					  <div id="levelButton8" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(9)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[9] + $totalLostForLevels[9]; ?></p>
				</div>
			  </div>
			</div>
			<div class="col-xl-3 col-lg-3 col-md-6 col-sm-12" style="">
			  <div class="card card-shadow card-completed-options text-center text-white">
				<div class="card-block pb-0 bg-white ">
					<div class="ribbon ribbon-badge ribbon-danger" id="ribbonColor9">
					<span class="ribbon-inner" id="ribbonName9">Inactive</span>
					</div>
					  <div class="font-size-20 py-5 bp-1 font-weight-800">LEVEL 10</div>
					  <div class="font-size-26 py-5 pb-30 font-weight-800 text-danger" id="buyAmountData9">40 ETH </div>
					  <div class="font-size-20 font-weight-600 text-primary" style="display: none;" id="autoPoolAmount9">Auto Pool : $200</div>
					  <div class="font-size-16 font-weight-400 mb-1" id="remainingDays9">100 Days</div>
					  <div id="levelButton9" type="button" class="btn btn-block btn-danger waves-effect waves-classic " onclick="buyLevel(10)"> BUY LEVEL</div>
					  <p class="blue-grey-400 font-weight-100 pt-2 ">Active Purchases: <?php echo $totalPaidForLevels[10] + $totalLostForLevels[10]; ?></p>
				</div>
			  </div>
			</div>
		</div>
	</div>
	  
	  
    </div>
  </div>
  <!-- End Page -->


  
<?php
include('footer.php');
?>

<script src="assets/js/alertify.min.js" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/gh/ethereum/web3.js@1.0.0-beta.34/dist/web3.js"></script>
<script type="text/javascript">

var web3 = new Web3(Web3.givenProvider || "https://mainnet.infura.io/v3/6f8dc3b58cd345cd9a6589821d2c131c");

var arrayABI = <?=$mainContractABI; ?>;

var mainContractAddress = "<?=$mainContractAddress; ?>";

var myAccountAddress = "<?=$userWallet;?>";

if (typeof web3 !== 'undefined'){

var myContract = new web3.eth.Contract(arrayABI, mainContractAddress, {
	from: myAccountAddress, // default from address
	});






// fetching user level
fetchRemainingTime(myAccountAddress);
async function fetchRemainingTime(myAccountAddress){

	var remainingDay = await myContract.methods.viewTimestampSinceJoined(myAccountAddress).call({from: myAccountAddress});

	for (var i = 0; i < remainingDay.length; i++) {
		
		if(remainingDay[i] > 0){

			
			//change ribbon color
			document.getElementById("ribbonColor"+[i]).classList.add('ribbon-success');
			document.getElementById("ribbonColor"+[i]).classList.remove('ribbon-danger');	


			//change the ribbon name
			document.getElementById("ribbonName"+[i]).textContent="Active";


			//change $ amount color
			document.getElementById("buyAmountData"+[i]).classList.add('text-success');
			document.getElementById("buyAmountData"+[i]).classList.remove('text-danger');
			document.getElementById("buyAmountData"+[i]).classList.remove('pb-30');


			


			//remaining days
			document.getElementById("remainingDays"+[i]).textContent="Remain Days: "+ (remainingDay[i] / 86400).toFixed(0);

			//button change
			document.getElementById("levelButton"+[i]).classList.add('btn-success');
			document.getElementById("levelButton"+[i]).classList.remove('btn-danger');
			document.getElementById("levelButton"+[i]).textContent="EXTEND 100 DAYS";
			
		}
	}
}

}	//web3 check




</script>


<script type="text/javascript" src="core/js/dashboard.footer.js">

	
</script>
