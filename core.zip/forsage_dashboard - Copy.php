<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
    <meta charset="utf-8">
    <script src="assets_s_/Decentralized/js/Qz1JI3jKPnt9NwuKnYPNmoYn8JE.js"></script>
    <link rel="stylesheet" href="assets_s/Decentralized/css/all.min.css" />
    <link rel="stylesheet" href="assets_s/Decentralized/css/bootstrap.min.css" />
	<link rel="stylesheet" href="assets_s/Decentralized/css/jquery.fancybox.min.css" />
	<link rel="stylesheet" href="assets_s/Decentralized/css/common.css" />
	<link rel="stylesheet" href="assets_s/Decentralized/css/main.css" />
	<link rel="stylesheet" href="assets_s/Decentralized/css/style.css" />   
 	<link rel="apple-touch-icon" sizes="180x180" href="assets_s/Decentralized/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets_s/Decentralized/img/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets_s/Decentralized/img/favicon-16x16.png">
    <link rel="manifest" href="assets_s/Decentralized/img/site.webmanifest">
    <link rel="mask-icon" href="assets_s/Decentralized/img/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="assets_s/Decentralized/img/favicon.ico">
    <link rel="stylesheet" type="text/css" href="assets_s/Decentralized/css/style2.css">

    <link rel="stylesheet" href="global/fonts/material-design/material-design.minfd53.css?v4.0.1">
	<link rel="stylesheet" href="global/fonts/brand-icons/brand-icons.minfd53.css?v4.0.1">
	<link rel='stylesheet' href="https://fonts.googleapis.com/css?family=Roboto:400,400italic,700">
	<link rel="stylesheet" href="global/fonts/font-awesome/font-awesome.minfd53.css?v4.0.1">
	<script src="https://kit.fontawesome.com/ee18e7efa7.js" crossorigin="anonymous"></script>
    <meta name="apple-mobile-web-app-title" content="Forsage">
    <meta name="application-name" content="Forsage">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="assets_s/Decentralized/img/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
	<script type="text/javascript" src="core/js/dashboard.js" crossorigin="anonymous"></script>

</head>
<body>
	<nav class="navbar navbar-expand-lg site-navbar">
	  <a class="navbar-brand" href="#" style="width: 171px;"><img src="assets_s/Decentralized/img/logo-03.svg" alt="" style="width: 100%;"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav mr-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="#">
	        	<i class="fa fa-bars"></i>
            </a>
	      </li>
	    </ul>
	    <ul class="navbar-nav">
    		  <li class="nav-item pl-5 navbar">
	            <span class="text-white px-2 mr-3">Ethbull</span>
	            <label class="switch mb-0">
	              <input type="checkbox">
	              <span class="slider switch_dashboard round"></span>
	            </label>
	            <span class="text-white px-2 ml-3">Forsage</span>
	          </li>  
	          <li class="nav-item pl-5 navbar">
	                      
	            <div class="dropdown">
	              <a class="dropbtn">Dashboard</a>

	              <div class="dropdown-content">
	                <a href="http://localhost/ethbull-forsage/dashboard/" class=" waves-effect waves-light waves-round">Ethbull.io</a>
	                <a href="http://localhost/ethbull-forsage/dashboard/?s_dashboard" class=" waves-effect waves-light waves-round">Forsage.io</a>
	              </div>
	            </div>
	          </li>
			   <li class="nav-item pl-5" style="float: right;">
	            <a class="nav-link waves-effect waves-light waves-round" href="#" aria-expanded="false" data-animation="fade" role="button"><i class="icon fa-user-circle-o font-size-22" aria-hidden="true"> </i>  USER ID: 2 </a>
	          </li>
	    </ul>
	  </div>
	</nav>
	<section class="main-dashboard">
		<div class="container-fluid">
			<div class="row">
				<div class="col-xl-2 col-lg-2 col-md-2 pl-0">
					<ul class="nav flex-column">
					  <li class="nav-item">
					    <a class="nav-link active" href="#"><i class="site-menu-icon md-home" aria-hidden="true"></i>Dashbord</a>
					  </li>
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class="site-menu-icon icon fa-handshake-o" aria-hidden="true"></i>Partner</a>
					  </li>
					   <li class="nav-item">
					    <a class="nav-link" href="#"><i class="site-menu-icon icon fa-frown-o" aria-hidden="true"></i>Statistics</a>
					  </li>
					   <li class="nav-item">
					    <a class="nav-link" href="#"><i class="site-menu-icon icon fa-address-book-o" aria-hidden="true"></i>Uplines</a>
					  </li>
					   <li class="nav-item">
					    <a class="nav-link" href="#"><i class="site-menu-icon icon fa-thumbs-o-up" aria-hidden="true"></i>Goal</a>
					  </li>
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class=" site-menu-icon icon fa-handshake-o" aria-hidden="true"></i>Information</a>
					  </li>
					  <li class="nav-item">
					    <a class="nav-link" href="#"><i class="site-menu-icon icon fa-power-off" aria-hidden="true"></i>Logout</a>
					  </li>
					</ul>
				</div>
				<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 pl-0 pt-3">
					<div class="row">
						<div class="col-lg-3">
							<h1>ID 2</h1>
						</div>
						<div class="col-lg-3">
							 <span style="font-size: 2.5rem;vertical-align: bottom;">18</span>
                             <img src="assets_s/Decentralized/img/partners_light.svg" alt="" style="width: 14%;">	
						</div>
						<div class="col-lg-3">
							<h1>$27.67</h1>
						</div>
						<div class="col-lg-3">
							<button class="btn btn-danger btn-block bg-pink">0.12eth</button>
						</div>
					</div>
					<div class="row">
						<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
							<div class="card">
								<div class="card-header">
									<img src="assets_s/Decentralized/img/x3.svg">
								</div>
								<div class="card-body">
									<span>$0</span>
								</div>
							</div>
						</div>
						<div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
							<div class="card">
								<div class="card-header">
									<img src="assets_s/Decentralized/img/x3.svg">
								</div>
								<div class="card-body">
									<span>$0</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="assets_s/Decentralized/js/jquery.min.js"></script>
	<script src="assets_s/Decentralized/js/vue.min.js"></script>
	<script src="assets_s/Decentralized/js/socket.io.js"></script>
	<script src="assets_s/Decentralized/js/jquery.fancybox.min.js"></script>
	<script src="assets_s/Decentralized/js/common.js"></script>
	<script src="assets_s/Decentralized/js/contract.js"></script>
	<script src="assets_s/Decentralized/js/cabinet.js"></script>

	<script type="text/javascript" src="core/js/dashboard.footer.js">
</body>
</html>