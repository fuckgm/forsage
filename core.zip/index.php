<?php

include('config.php');
//application level defaults



if(isset($_COOKIE['userID']) && $_COOKIE['userID'] != ''){

$userID = $_COOKIE['userID'];

$query = "SELECT * FROM event_reglevelev where userID='".clean($userID)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

if($row != NULL){
	loadPages($userID, $row['userWallet'], $conn);
}
else{
	$errorMsg = 'login-unsuccessful';
	include('auth.php');	//login page with error message
}

}
elseif (isset($_COOKIE['userWallet']) && $_COOKIE['userWallet'] != '')  {

$userWallet = $_COOKIE['userWallet'];

$query = "SELECT * FROM event_reglevelev where userWallet='".clean($userWallet)."' ";
$result = mysqli_query($conn,$query);
$row = mysqli_fetch_array($result);

if($row != NULL){
	loadPages($row['userID'], $userWallet, $conn);
}
else{
	$errorMsg = 'login-unsuccessful';
	include('auth.php');	//login page with error message
}



} else {
    include('auth.php');
}



//$r=basename($url,".php");
//$k=explode("?",$r);
function loadPages($userID, $userWallet, $conn){

$protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
 $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$e=explode("/?",$url);
if(isset($e[1])){
$k=explode("/",$e[1]);
}else{
	$k='';
}
	if(isset($_GET['lost'])){
		include('lost.php');
	}
	elseif(isset($_GET['partner'])){
		include('partner.php');
	}
	elseif(isset($_GET['promo'])){
		include('promo.php');
	}
	elseif(isset($_GET['uplines'])){
		include('uplines.php');
	}
	elseif(isset($_GET['swap'])){
		include('swap.php');
	}
	elseif(isset($_GET['logout'])){
		include('logout.php');
	}

	elseif(isset($_GET['logout'])){
		include('logout.php');
	}
	elseif(isset($_GET['s_dashboard'])){
		include('s_dashboard.php');
	}

	elseif(isset($_GET['statistics'])){
		include('statistics.php');
	}

	elseif(isset($_GET['information'])){
		include('information.php');
	}
	elseif(isset($_GET['s_partners'])){
		include('s_partners.php');
	}
	elseif(isset($_GET['s_uplines'])){
		include('s_upline.php');
	}
	elseif(!empty($k[0])=='page'){
		include('page.php');
	}
	else{
		include('dashboard.php');
	}

}





?>
